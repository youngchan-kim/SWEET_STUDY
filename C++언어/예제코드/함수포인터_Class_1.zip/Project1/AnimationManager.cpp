#include "AnimationManager.h"
#include"Character.h"


void AnimationManager::Play(std::function<void(Character&, int)> callbackFunc, Character *player)
{
	int oldClock = clock();
	cout << "���ϸ��̼� ������..." << endl;
	while (clock() - oldClock < 1000);
	callbackFunc(*player,100);
}
void AnimationManager::Play(std::function<void(Character&)> callbackFunc, Character* player)
{
	int oldClock = clock();
	cout << "���ϸ��̼� ������..." << endl;
	while (clock() - oldClock < 1000);
	callbackFunc(*player);
}