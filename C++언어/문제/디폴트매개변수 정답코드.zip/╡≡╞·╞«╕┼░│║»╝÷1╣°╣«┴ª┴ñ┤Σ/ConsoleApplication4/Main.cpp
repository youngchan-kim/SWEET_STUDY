#include"Work.h"

void main()
{
	Work work1,work2;
	work1.SetVelue(15, 10, 10000);
	work1.ShowVelue();
	work2.SetVelue(20);
	work2.ShowVelue();
}
