#pragma once
#include "Play_FireRing.h"
#include "Play_Cash.h"
class Play_Little_Firering : public Play_FireRing
{
private:
	//ĳ�� �ɹ� ����
	Play_Cash cash;
	//BitMap* cash;
	//BitMap** bmring;
	/*int width, height;
	float dont_move_point;*/

	/*int animation_left, animation_right;
	float ani_time;*/
	/*
	float score_x, score_y, score_width, score_height;

	bool Intersect_check, score_check;

	bool win;
	*/
	//RECT ring_Rect, score_Rect;
public:
	Play_Little_Firering() {}
	~Play_Little_Firering() {}
	//�����Լ�
	virtual void Init(int width, int height, float dont_move_point, int num);
	virtual void Draw(HDC backDC);
	virtual void Update(float deltatime, int speed, float distance, bool win);
	virtual int Play_ScoreUp(RECT player_Rect);

};

