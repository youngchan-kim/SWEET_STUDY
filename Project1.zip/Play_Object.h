#pragma once
#include "BitMapManager.h"
#define GOAL_X 1000
#define GOAL_WIDTH 150
#define GOAL_HEIGHT 150
class Play_Object
{
private:
	BitMap** bmobject;
public:
	Play_Object();
	~Play_Object();
	void Init();
	void Goal(HDC backDC);
};

