#pragma once
#include "Monster.h"
#include <vector>

class MonsterManager:public Monster
{
private:
	vector<Monster> monsterlist;
public:
	MonsterManager();

	void SetMonster();
	void MonsterList();
	void MonsterSelect();
	~MonsterManager();
};

