#pragma once
#include "WoodMan.h"

class EnterWoodCutting : public State
{
private:
	EnterWoodCutting() {}
	EnterWoodCutting(const EnterWoodCutting&);
	EnterWoodCutting& operator =(const EnterWoodCutting&);

public:
	static EnterWoodCutting* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};

class VisitMarket : public State
{
private:
	VisitMarket() {}
	VisitMarket(const VisitMarket&);
	VisitMarket& operator=(const VisitMarket&);

public:
	static VisitMarket* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};


class VisitBankAndDepositGold : public State
{
private:
	VisitBankAndDepositGold() {}
	VisitBankAndDepositGold(const VisitBankAndDepositGold&);
	VisitBankAndDepositGold& operator=(const VisitBankAndDepositGold&);

public:
	static VisitBankAndDepositGold* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};

class GoHomeAndSleepTilRested : public State
{
private:
	GoHomeAndSleepTilRested() {}
	GoHomeAndSleepTilRested(const GoHomeAndSleepTilRested&);
	GoHomeAndSleepTilRested& operator=(const GoHomeAndSleepTilRested&);

public:
	static GoHomeAndSleepTilRested* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};

class Hungry//���⼭ ���� �ڵ�
