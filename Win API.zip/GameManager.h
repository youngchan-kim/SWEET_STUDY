#pragma once
#include <iostream>

class Win_API;

class GameManager
{

private:
	static GameManager* m_pInstance;
private:
	GameManager() {}
public:
	~GameManager() {}

	//�̱���
	static GameManager* get_instance()
	{
		if (NULL == m_pInstance)m_pInstance = new GameManager;
		return m_pInstance;
	}

	void MenuPage();
};



#define GameMgr GameManager::get_instance()

//