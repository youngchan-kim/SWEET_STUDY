#pragma once
#include "../DXGameObject.h"
enum class ProjectionType{ Perspective, Orthographic };
class DXCamera : public BaseComponent
{
};

