#include "GameManager.h"

GameManager* GameManager::m_pInstance = NULL;


void GameManager::Init(HWND hWnd)
{
	BMMger->Init(hWnd);
    //Player = BMMger->GetBACK(BACK_3)->BITMAPIMAGE();
    //Player.init();
    //Background = (HBITMAP)LoadImage(NULL, L"back_1.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
   
}

void GameManager::Draw(HWND hWnd, HDC hdc)
{
    RECT windowRect;
    GetWindowRect(hWnd, &windowRect);

    HBITMAP backBitmap = CreateDIBSectionRe(hdc, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top);
    HDC backDC = CreateCompatibleDC(hdc);
    SelectObject(backDC, backBitmap);

    //BMMger->GetBACK(BACK_3)->Draw(backDC, 0,0, 1, 1);
    

    BitBlt(hdc, 0, 0, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, backDC, 0, 0, SRCCOPY);
    DeleteDC(backDC);
    DeleteObject(backBitmap);
}

//���� ���۸��� ���� ���ο� DIBSection�� ������ش�. Winȭ��� ���� ȭ���� ����� ��
HBITMAP GameManager::CreateDIBSectionRe(HDC hdc, int width, int height)
{
    BITMAPINFO bm_info;
    ZeroMemory(&bm_info.bmiHeader, sizeof(BITMAPINFOHEADER));
    bm_info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bm_info.bmiHeader.biBitCount = 24;
    bm_info.bmiHeader.biWidth = width;
    bm_info.bmiHeader.biHeight = height;
    bm_info.bmiHeader.biPlanes = 1;

    LPVOID pBits;
    return CreateDIBSection(hdc, &bm_info, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
}
