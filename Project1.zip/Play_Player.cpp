#include "Play_Player.h"

Play_Player::Play_Player()
{
	bmplayer = new BitMap * [PLAYER_6];
}

Play_Player::~Play_Player()
{
	if (bmplayer != NULL) { delete[] bmplayer; bmplayer = NULL; }
}

void Play_Player::Init()
{
	for (int i = 0; i < PLAYER_6; i++)  bmplayer[i] = BMMger->GetPlayer((PLAYER)(i));
	player_x = 0;
	player_y = 500;
}

void Play_Player::Player(HDC backDC)
{
	bmplayer[0]->Draw(backDC, player_x, player_y, PLAYER_WIDTH, PLAYER_HEIGHT);
}
