#pragma once
#include "BitMapManager.h"


class Play_Object
{
private:
	BitMap** bmobject;
	int width, height;
	float m_fGoal_Width, m_fGoal_height;
	float m_fGoal_x, m_fGoal_y, m_startGoal_x;
	float dont_move_point, end_x;

public:
	Play_Object();
	~Play_Object();
	void Init(int width, int height, float dont_move_point);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed, float distance, int saveindex);
};


