#include "Car.h"

Car::Car()
{
	m_icarwidth = 6;
	m_icarheight = 3;
	m_istart_x = 10;
	m_istart_y = 10;
}

void Car::SpeedBool()
{
	if (speedup == true)
		speedup = false;
	else
		speedup =true;
}

void Car::CarPositionInput()
{
	carposition.i_mcarx = m_istart_x;
	carposition.i_mcary = m_istart_y;
}

void Car::EraseCar()
{
	MapDraw::CarErase(carposition.i_mcarx, carposition.i_mcary, m_icarwidth, m_icarheight);
}

void Car::DrawCar()
{
	MapDraw::CarDraw(carposition.i_mcarx, carposition.i_mcary, m_icarwidth, m_icarheight);
}

void Car::CreateCar()
{
	carclock = clock();
	speedup = false;
	CarPositionInput();
	DrawCar();
}

void Car::MoveCheck(int m_moveclock)
{
	if (speedup == false && m_moveclock - carclock > 1000)
		MoveCar(m_moveclock);
	else if (speedup == true && m_moveclock - carclock > 500)
		MoveCar(m_moveclock);
}
void Car::MoveCar(int m_moveclock)
{
	EraseCar();
	carposition.i_mcarx += 4;
	DrawCar();
	carclock = m_moveclock;
}
Car::~Car() {}