#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>


//���� �׸��� ���� �߽� ��

class Circle
{
private:
	//������
	float radius = 0;
	//����
	float volume;
	//����
	float mass;
	float invMass;
	//�ӷ�
	Vector2 velocity;
	Vector2 position;
public:
	void Init(float x, float y, float radius, float d, float tmp);
	void Update(const FLOAT& deltaTime);
	void Draw(HDC hdc);
	float GetVolume() { return volume; }
	float GetMass() { return mass; }
	float GetInvMass() { return invMass; }
	float GetRadius() { return radius; }
	Vector2 GetPosition() { return position; }
	Vector2 GetVelocity() { return velocity; }
	void Add_Gravity(Vector2 gravityvelocity) { velocity += gravityvelocity; }
	void Add_Velocity(Vector2 addvelocity) { velocity += addvelocity; }
	//void Add_Gravity() { this->velocity = }
};

