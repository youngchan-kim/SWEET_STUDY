#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Weapon.h"
#include <map>
#include <vector>

class Shop
{
private:
	MapDraw mapdraw;
	vector<Weapon*> weaponlist;
public:
	Shop();
	void ShopMenu();

	void ShopLsit(int x ,int y);
	void SetWeapon();
	~Shop();
};

