#include "BitMapManager.h"

BitMapManager* BitMapManager::p_mBMMInstance = NULL;

BitMapManager::BitMapManager()
{
	m_pBMTitle = new BitMap[TITLE_4];
	m_pBMMenu = new BitMap[MENU_5];
	m_pBMGameInterface = new BitMap[INTERFACE_3];
	m_pBMPlayer = new BitMap[PLAYER_6];
	m_pBMRing = new BitMap[RING_4];
	m_pBMFire = new BitMap[FIRE_2];
	m_pBMBack = new BitMap[BACK_4];
	m_pBMObject = new BitMap[OTHEROBJECT_4];
}

void BitMapManager::Init(HWND hWnd)
{
	int i = 1;
	HDC hdc = GetDC(hWnd);
	while (i <= PLAYER_6)
	{
		char buf[256];
		if (i <= TITLE_4) { sprintf_s(buf,"title_//%d.bmp",i); m_pBMTitle->Init(hdc, buf); }
	
		if (i <= MENU_5) { sprintf_s(buf, "menu_//%d.bmp", i); m_pBMMenu->Init(hdc, buf); }
	
		if (i <= INTERFACE_3) { sprintf_s(buf, "interface_//%d.bmp", i); m_pBMGameInterface->Init(hdc, buf); }

		if (i <= PLAYER_6) { sprintf_s(buf, "player_//%d.bmp", i); m_pBMPlayer->Init(hdc, buf); }
	
		if (i <= RING_4) { sprintf_s(buf, "ring_//%d.bmp", i); m_pBMRing->Init(hdc, buf);}
		
		if (i <= FIRE_2) { sprintf_s(buf, "fire_//%d.bmp", i); m_pBMFire->Init(hdc, buf); }
	
		if (i <= BACK_4) { sprintf_s(buf, "back_//%d.bmp", i); m_pBMBack->Init(hdc, buf); }
	
		
		i++;
	}
//{ sprintf_s(buf, "point"); m_pBMObject->Init(hdc, buf); }
//	else if (i == 2) { sprintf_s(buf, "goal"); m_pBMObject->Init(hdc, buf); }
//	else if (i == 3) { sprintf_s(buf, "cash"); m_pBMObject->Init(hdc, buf); }
//	else if (i == 4) { sprintf_s(buf, "black"); m_pBMObject->Init(hdc, buf); }
	ReleaseDC(hWnd, hdc);
}

void BitMapManager::BackGround(HDC hdc)
{
	m_pBMBack[BACK_3].Draw(hdc, 0, 200, 200, 200);
	m_pBMBack[BACK_3].Draw(hdc, 200, 200, 200, 200);
	m_pBMBack[BACK_2].Draw(hdc, 400, 200, 200, 200);
	m_pBMBack[BACK_3].Draw(hdc, 600, 200, 200, 200);
	m_pBMBack[BACK_3].Draw(hdc, 800, 200, 200, 200);
}

BitMapManager::~BitMapManager()
{
	if (m_pBMTitle != NULL)
	{
		delete[] m_pBMTitle;
		delete[] m_pBMMenu;
		delete[] m_pBMGameInterface;
		delete[] m_pBMPlayer;
		delete[] m_pBMRing;
		delete[] m_pBMFire;
		delete[] m_pBMBack;

		m_pBMTitle = NULL;
		m_pBMMenu = NULL;
		m_pBMGameInterface = NULL;
		m_pBMPlayer = NULL;
		m_pBMRing = NULL;
		m_pBMFire = NULL;
		m_pBMBack = NULL;
	}
}