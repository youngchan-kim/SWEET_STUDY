#include "Play.h"

void main()
{
	Play p;
	//p.MainMenu();
	//p.Story_Name();
	//p.Story_Name();
	p.GamePlay();
}