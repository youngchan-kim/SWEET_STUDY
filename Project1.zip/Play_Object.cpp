#include "Play_Object.h"

Play_Object::Play_Object()
{
	bmobject = new BitMap * [OTHEROBJECT_4];
}

Play_Object::~Play_Object()
{
	if (bmobject != NULL) { delete[] bmobject; bmobject = NULL; }
}

void Play_Object::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	for (int i = 0; i < OTHEROBJECT_4; i++)  bmobject[i] = BMMger->GetOtherObject((OTHEROBJECT)(i));

	m_fGoal_Width = width * 0.1f;
	m_fGoal_height = height * 0.2f;
	m_fGoal_x = 700.0f;
	m_fGoal_y = height * 0.58f;
}

void Play_Object::Draw(HDC backDC)
{
	bmobject[1]->Draw(backDC, m_fGoal_x, m_fGoal_y, m_fGoal_Width, m_fGoal_height);
}

void Play_Object::Update(float deltatime,float speed)
{

}
