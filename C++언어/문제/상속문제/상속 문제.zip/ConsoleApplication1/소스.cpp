#include "Computer.h"

void main()
{
	int i;
	Computer com;
	com.main();
	com.display();
}