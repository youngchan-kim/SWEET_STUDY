#pragma once
#include "Interface.h"


class Play
{
private:
	Interface mapdraw;
public:
	Play();
	void Clearmap();
	void MainMenu();

	~Play();
};

