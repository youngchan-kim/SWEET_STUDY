#pragma once
class Bomb_effect
{
};

