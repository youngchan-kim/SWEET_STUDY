#pragma once

#include "EngineMecro.h"
#include "Components/LRInput.h"
#include "UIManager.h"
#include "DemoScene.h"
#ifndef END_MENU_SCENE_H
#define END_MENU_SCENE_H

using namespace ENGINE;

class EndMenuScene : public Scene
{
	BOOL isStart;

	Bitmap* background = nullptr;

	std::string board_name;
	//UIButton* retryBtn;
	UIImage* EndWindow;
	UILabel* board;
	UIButton* quitBtn, * playBtn;
	UILabel* scoretitle;
	HFONT font;
	//�ʺ�
	float bounds;
	//��ư�� ����
	float btn_height;
public:
	// Scene��(��) ���� ��ӵ�
	virtual VOID Initialize() override;
	virtual VOID Release() override;
	virtual VOID Update(const FLOAT& deltaTime) override;
	//void GetScore(int getscore);
	virtual VOID Draw() override;

	VOID PlayBtnClickHandler();
	VOID QuitBtnClickHandler();
};

#endif
//�ʿ��� �� �������� ���� 