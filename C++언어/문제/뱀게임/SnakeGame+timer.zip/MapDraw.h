#pragma once
#include"Mecro.h"

class MapDraw
{
public:
	static void DrawMap(int Start_x, int Start_y, int Width, int Height)
	{
		for (int y = 0; y < Height; y++)
		{
			gotoxy(Start_x, Start_y + y);
			if (y == 0)
			{
				std::cout << "��";
				for (int x = 1; x < Width - 1; x++)
					std::cout << "��";
				std::cout << "��";
			}
			else if (y == Height - 1)
			{
				std::cout << "��";
				for (int x = 1; x < Width - 1; x++)
					std::cout << "��";
				std::cout << "��";
			}
			else
			{
				std::cout << "��";
				for (int x = 1; x < Width - 1; x++)
					std::cout << "  ";
				std::cout << "��";
			}
		}
		return;
	}
	
	static void DrawPoint(std::string str, int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << str;
		gotoxy(-1, -1);
		return;
	}
	static void DrawMidText(std::string str, int x, int y)
	{
		if (x > str.size() / 2)
			x -= str.size() / 2;
		gotoxy(x, y);
		std::cout << str;
		return;
	}	
	static void ErasePoint(int x, int y)
	{
		gotoxy(x * 2, y);
		std::cout << "  ";
		gotoxy(-1, -1);
		return;
	}
	MapDraw() {}
	static inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~MapDraw() {}
};