#include "EngineMecro.h"
#include "Components/SpriteRenderer.h"
#include "Components/SpriteAnimation.h"
#include "Components/LRInput.h"
#include "UIManager.h"
//#include "Player.h"
//#include "Dropitem.h"
//#include "Bomb_effect.h"
//#include "EndMenuScene.h"
#include "Circle.h"
#ifndef DEMO_SCENE_H
#define DEMO_SCENE_H

using namespace ENGINE;

enum OBJECT {
	Circle1,
	Circle2,
	Circle3,
};

class DemoScene : public Scene
{
public:
	Circle circle[Circle3];
	
private:
	float penetration;
	Vector2 normal;

public:
	// Scene��(��) ���� ��ӵ�
	virtual VOID Initialize() override;
	VOID Release();
	virtual VOID Update(const FLOAT& deltaTime) override;
	virtual VOID Draw() override;

	bool CirclevsCircle(Circle* lhs, Circle* rhs);


};

#endif // !DEMO_SCENE_H