#include "Play_Player.h"

Play_Player::Play_Player()
{
	bmplayer = new BitMap * [PLAYER_6];
}

Play_Player::~Play_Player()
{
	if (bmplayer != NULL) { delete[] bmplayer; bmplayer = NULL; }
}

void Play_Player::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	for (int i = 0; i < PLAYER_6; i++)  bmplayer[i] = BMMger->GetPlayer((PLAYER)(i));
	//�ʱ� �÷��̾��� ��ġ
	Player_StartPoint = width * 0.1f;
	player_x = Player_StartPoint;
	player_y = height*0.64f;
	Player_Width = width * 0.07f;
	Player_Height = height * 0.14f;
	//�÷��̾�� ����� �����̴� �ӵ�
	speed = 200;

	//�÷��̾��� ����
	direction = PLAYER_DONT_MOVE;
	ani_time = 0;
	ani_index = 0;
	distance = 0;
}

void Play_Player::Draw(HDC backDC)
{
	bmplayer[ani_index]->Draw(backDC, player_x, player_y, Player_Width, Player_Height);
}

void Play_Player::Update(float deltatime)
{
	distance += Speed() * deltatime;
	ani_time += deltatime;

	if (distance < 0)
	{
		if (distance < 0)
		{
			distance = 0;
		}		
		player_x = Player_StartPoint;
	}
	else
	{
		player_x = Player_StartPoint + distance - 90;
	}

	if (ani_time > 0.1f)
	{
		ani_time = 0;
		switch (direction)
		{
		case PLAYER_DONT_MOVE:
			ani_index = 0;
			break;

		case PLAYER_RIGHT:
			ani_index += 2;
			if (ani_index > 2)ani_index = 0;
			break;

		case PLAYER_LEFT:
			ani_index += 1;
			if (ani_index > 1)ani_index = 0;
			break;
		}
	}
	
	//if (isJump)
	//{
	//
	//	return;
	//}

	//��ǥ���� �ٲٴ� �� �ƴ϶� � Ű�� ���������� �˰�
	if (GetAsyncKeyState(VK_SPACE))
	{
	}
	else if (GetAsyncKeyState(VK_LEFT))
	{
		direction = PLAYER_LEFT;
	}
	else if (GetAsyncKeyState(VK_RIGHT))
	{
		direction = PLAYER_RIGHT;
	}
	else
	{
		direction = PLAYER_DONT_MOVE;
	}

	/*return Speed();*/
}
