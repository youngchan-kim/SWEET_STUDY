#pragma once
#include "Student.h"
class Std_manager {
	Student* std[30];

private:
	void setStudent();
	void showStudent();
	void findNumber();
	void findname();
	void findClass();

	static Std_manager* m_pInstance;

private:
	Std_manager();

public:
	~Std_manager()
	{
		for (int i = 0; i < 30; i++)
		{
			delete std[i];
		}
	}
	static Std_manager* get_instance()
	{
		if (NULL == m_pInstance) m_pInstance = new Std_manager;
		return m_pInstance;
	}

	void display();
};



