#include "Word.h"
Word::Word() {};
Word::~Word() {};

//void Word::Drop()
//{
//	
//}
//void Word::Die()
//{
//
//}
//void Word::SetWord(int x, int itemType)
//{
//
//}