#pragma once
#include "Mecro.h"
#include "MapDraw.h"

#define MOSTEREXP 0

class Character
{
protected:
	string m_strname;
	int m_idamage;
	int m_imaxhealth;
	int m_imaxexp;
	int m_igetexp;
	int m_iLv;
	int m_igold;
	int m_iexp;
	int m_icurhealth;
	int monsterlist;
	MapDraw mapdraw;

public:
	virtual void Load(ifstream& load, string name="") = 0;
	virtual void Infomation(int x, int y) = 0;

	Character();
	virtual ~Character();
};

