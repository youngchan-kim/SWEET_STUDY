#include "Play_Player.h"

Play_Player::Play_Player()
{
	bmplayer = new BitMap * [PLAYER_6];
}

Play_Player::~Play_Player()
{
	if (bmplayer != NULL) { delete[] bmplayer; bmplayer = NULL; }
}

void Play_Player::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	for (int i = 0; i < PLAYER_6; i++)  bmplayer[i] = BMMger->GetPlayer((PLAYER)(i));
	player_x = 0;
	player_y = 500;
}

void Play_Player::Draw(HDC backDC)
{
	bmplayer[0]->Draw(backDC, player_x, player_y, PLAYER_WIDTH, PLAYER_HEIGHT);
}

void Play_Player::Update(float deltatime)
{
	if (GetAsyncKeyState(VK_LEFT))
	{
		//background_x += 10;

		//if (background_x >= 0) { background_x = 0; }
	}

	else if (GetAsyncKeyState(VK_RIGHT))
	{
		//background_x -= 10;
		//goal_x += 10;
		//if (total_x >= 1000) { total_x = 1000;}
	}
	else if (GetAsyncKeyState(VK_SPACE))
	{
		//player_y;
	}

	//if (total_x <= 9000) { background_x -= 10; }
	//else { player_x = (total_x - 9000); }
}
