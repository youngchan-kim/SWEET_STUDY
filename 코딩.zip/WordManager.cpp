#include "WordManager.h"
WordManager::WordManager() {}
WordManager::~WordManager() {}

void WordManager::Load()
{
	int num;
	std::ifstream load;
	load.open("Word.txt");
	if (load.is_open())
	{
		std::string str;
		load >> num;
		wordnum = num;
		while (!load.eof())
		{
			getline(load, str);
			word_list.push_back(Word(str));
		}
		load.close();
	}
}
// ����� ���� ����Ʈ�� �������� 76����
// 0��°�� str�� ���� ����


void WordManager::MakeWord()
{
	int i = rand() % word_list.size();
	int x = (rand() % (MAX_X - 4)) + 2;
	if(word_list[i].IsDead())
		word_list[i].SetWord(x, 0);
}
//void WordManager::WordTypeEffect(int wordtype)
//{
//
//}

int WordManager::CheckWord(std::string wordcheck, int& iScore)
{
	for (int i = 0; word_list.size() > i; i++)
	{
		if (word_list[i].GetWord() == wordcheck)
		{
			if (!word_list[i].IsDead())
			{
				word_list[i].takeIsDead(true);
				//WordTypeEffect(word_list[i].GetWordType())

				return iScore += word_list[i].GetWordSize();
			}
			else if (word_list[i].IsDead())
			{
				//5�ʰ� �Է� �Ұ� ���� 
			}
		}
	}
}

void WordManager::Draw()
{
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

void WordManager::Drop()
{

	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Drop();
		}
	}

}
