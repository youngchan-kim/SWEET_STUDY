#pragma once
#include "Mecro.h"
#include "Interface.h"
//�ܾ �����ϴ°�,�ܾ �׸���, ����Ʈ����, �����

//__interface WordInterface
//{
//	void Draw();
//	void Drop();
//	void Die();
//};

class Word// : public WordInterface
{
private:
	Interface mapdraw;

	int x;
	int y;
	std::string str;
	int wordtype;
	bool isDead;

	Word();
public:
	Word(std::string str) : str(str), isDead(true) {}
	~Word();

	bool IsDead() const { return isDead; };
	void SetWord(int x, int itemType)
	{
		y = 1;
		this->x = x;
		isDead = false;
	}
	void Erase() { mapdraw.EraseText(str, x, y); }
	void Draw()  { mapdraw.TextDraw(str, x, y); }//����� �߰�
	int Drop();
	void Die()  { isDead = true; Erase();}
	std::string GetWord() { return str; }
	int GetWordType() { return wordtype; }
	int GetWordSize() { return str.length(); }
};

