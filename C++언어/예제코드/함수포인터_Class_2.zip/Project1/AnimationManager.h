#pragma once
#include<iostream>
#include<functional>
#include<time.h>
using namespace std;

class Character;
class AnimationManager
{

public:
	void IntParameterPlay(std::function<void(int)> callbackFunc);
	void NonParameterPlay(std::function<void()> callbackFunc);
};

