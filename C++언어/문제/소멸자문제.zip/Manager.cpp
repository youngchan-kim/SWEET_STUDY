#include "Manager.h"


Manager::Manager()
{
	string str;
	int barnum1, barnum2;
	while (1)
	{
		cout << "��ȭ��ȣ �Է� : ";
		cin >> str;
		name = new char[str.length() + 3];
		if (str[1] == '1' && str.length() == 11)
		{
			strcpy(name, str.c_str());
			Swap(name, str, 3, 8);
			Print(name, str);
			return;
		}
		if (str[1] == '2' && str.length() == 9)
		{
			strcpy(name, str.c_str());
			Swap(name, str, 2, 6);
			Print(name, str);
			return;
		}
		if (str[1] >= '3' && str[1] <= '6' && str.length() == 10)
		{
			strcpy(name, str.c_str());
			Swap(name, str, 3, 7);
			Print(name, str);
			return;
		}
		else
			cout << "��ȣ�� �߸� �Է��ϼ̽��ϴ�." << endl;
	}
}
void Manager::Print(char name[], string str)
{
	cout << "�ϼ��� ��ȣ : ";
	for (int i=0; i < str.length() + 2; i++)
		cout << name[i];
}
void Manager::Swap(char name[], string str ,int barnum1, int barnum2)
{
	char tmp1, tmp2, tmp3;

	for (int i = 0; i < str.length() + 2; i++)
	{
		if (i == barnum1)
		{
			tmp1 = name[i];
			name[i] = '-';
		}
		else if (i > barnum1 && i < barnum2)
		{
			tmp2 = name[i];
			name[i] = tmp1;
			tmp1 = tmp2;
		}
		else if (i == barnum2)
		{
			tmp2 = name[i];
			name[i] = '-';
		}
		else if (i > barnum2)
		{
			tmp3 = name[i];
			name[i] = tmp1;
			tmp1 = tmp2;
			tmp2 = tmp3;
		}
	}
}

Manager::~Manager()
{
	delete[] name;
}
	