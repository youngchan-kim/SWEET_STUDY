#include "Manager.h"



void Manager::Sum(int num01, int num02)
{
	for (int i = num01; i <= num02; i++)
		m_isum += i;

	cout << num02 << " ~ " << num01 << "������ �� : " << m_isum << endl;
}

Manager::Manager()
{
	for (int i = 1; i <= 10; i++)
	{
		m_isum += i;
	}
	cout << "1 ~ 10������ �� : " << m_isum<< endl;
}
Manager::Manager(int num02)
{
	int num01 = 1;
	Sum(num01, num02);
}
Manager::Manager(int num01, int num02)
{
	if (num01 <= num02)
		Sum(num01, num02);
	else
		Sum(num02, num01);
}

Manager::~Manager()
{

}