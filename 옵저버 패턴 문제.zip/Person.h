#pragma once
#include "Observer.h"
class Person : public Observer
{
private:
	std::string strName;
	std::string preNews;

	std::string day;
public:
	Person();
	~Person();
	
	virtual void Update(std::string curnews);
	virtual void OutPut();


};

