#pragma once
#include "BitMapManager.h"

class Play_Fire
{
private:
	BitMap* bmfire[FIRE_2];
	int width, height;
	float move_change_point;

	int distance_unit;
	int animation;
	float ani_time;
	float fire_start_x, fire_x, fire_y, fire_width, fire_height;
	float end_x;

	bool Intersect_check, score_check;

	RECT fire_Rect, score_Rect;
public:
	Play_Fire();
	~Play_Fire();
	void Init(int width, int height, float move_change_point, int num);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed, float distance, int num);
	//�÷��̾ ���� ���
	// ���� ��ġ�� ����ȭ�鿡���� ������ �ʴ´�.
	void Dead(float distance);
	bool Play_DeadIntersect(RECT player_Rect);

	int Play_ScoreUp(RECT player_Rect);

};

