#pragma once
#include"Mecro.h"
#include "BlockClass.h"
#include "SnackClass.h"
#include"Timer.h"

#define MAXWALLBLOCK 20
#define MAXITEMBLOCK 9
#define MAXWIDTH_MAXHEIGHT 30
#define SPACE_BAR 32


class GameClass
{
private:
	
	Timer timer;
	BLOCK_TYPE type;

	BlockClass wallshape;
	BlockClass itemshape;
	BlockClass  barricadeshape;

	std::list<BlockClass> itemlist;
	std::vector<BlockClass> walllist;
	std::vector<BlockClass> barricadelist;
	SnackClass snack;
	
	Position m_cursor;
	
	int m_iStart_x;
	int m_iStart_y;
	int m_iWidth;
	int m_iHeight;


	int m_iitemcout;

	//int m_imaintime;
	//int m_iitemtime;
	char m_ch;
	int num;
	std::string strscore;
	std::string score;
	static GameClass* gameclass;//�ڱ��ڽ��� ������ȭ�Ѱ��ΰ�
public:
	int RandomPosition();
	bool BarricadeCrash(Position cursor);
	void SetBarricade(BLOCK_TYPE type);
	void BarricadeList();
	bool WallCrash(Position cursor);
	void SetWall(BLOCK_TYPE type);
	void WallList();
	bool ItemSearch(Position cursor);
	std::list<BlockClass>::iterator ItemSearch();
	void ItemReMove();
	void SetItem();
	void SetItemtTme();
	void ItemTimeCheck();

	void Map_Interface();
	void GameEnd();
	void Game();
	void Menu();

	GameClass();
	~GameClass();
};

