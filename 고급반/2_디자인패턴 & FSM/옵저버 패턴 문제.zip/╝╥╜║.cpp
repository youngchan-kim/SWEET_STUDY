#include "News.h"

void main()
{
	News::get_instance()->Main();
}