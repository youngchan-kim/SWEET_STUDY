#include "Play.h"

void main()
{
	Play p;
	p.MainMenu();
}