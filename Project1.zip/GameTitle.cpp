#include "GameTitle.h"

GameTitle::GameTitle()
{
	bmtitle = new BitMap[TITLE_4];
	bmmenu = new BitMap[TITLE_4];
}

GameTitle::~GameTitle()
{
}

void GameTitle::Init(HDC hdc)
{
	for (int i = TITLE_1; i <= TITLE_4; i++) bmtitle[i] = *BMMger->GetTitle((TITLE)i);
	for (int i = MENU_1; i <= MENU_5; i++)  bmmenu[i] = *BMMger->GetMENU((MENU)i);
}

void GameTitle::Draw()
{
	bmtitle->Draw()
}

void GameTitle::Update()
{
}