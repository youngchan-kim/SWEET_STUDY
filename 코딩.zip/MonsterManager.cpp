#include "MonsterManager.h"

MonsterManager::MonsterManager() {}
void MonsterManager::SetMonster()
{
	Monster monster;
	int listnum;
	ifstream load;
	load.open("DefaultMonster.txt");
	if (load.is_open())
	{
		load >> listnum;
		for (int i = 0; i < listnum; i++)
		{
			monster.Load(load);
			monsterlist.push_back(monster);
		}
		load.close();
	}
}
void MonsterManager::MonsterList()
{
	int x = 30;
	int y = 3;
	vector<Monster>::iterator iter = monsterlist.begin();
	while(iter != monsterlist.end())
	{
		iter->Infomation(x, y);
		y += 4;
		iter++;
		// �����ؼ� ���͸� ����Ұ�
	}
}
void MonsterManager::DongeonList(int x, int y)
{

	int dongeonnum = 1;
	string line;
	mapdraw.DrawMidText("=====���� �Ա�=====", x, y);
	y = 8;
	vector<Monster>::iterator iter = monsterlist.begin();
	while (iter != monsterlist.end())
	{
		y += 2;
		line = to_string(dongeonnum) + "������ : [" + iter->Monstername() + "]";
		dongeonnum++;
		iter++;
		mapdraw.DrawMidText(line, x, y);
		// �����ؼ� ���͸� ����Ұ�
	}
}
void MonsterManager::MonsterSelect(int dongeonnum, int x, int y)
{
	selectMon = monsterlist[dongeonnum-1];
	selectMon.Infomation(x, y);
}
void MonsterManager::MonsterCurhealth(int tookdamage)
{
	selectMon.Curhealth(selectMon.Gethealth() - tookdamage);
}
void MonsterManager::Relese()
{
}
MonsterManager::~MonsterManager() {}