#pragma once
#include"AnimationManager.h"
//���ҽ��� ���� 
class Character
{	
private:
	int m_iHP;
	int m_iDamage;
	AnimationManager m_animationManager;
public:
	Character();
	~Character();
	void Hitby(int Damage);
	void Buff();
	void Attack();

	void AttackAnimation();
	void BuffAnimation();
	void HitbyAnimation();
};

