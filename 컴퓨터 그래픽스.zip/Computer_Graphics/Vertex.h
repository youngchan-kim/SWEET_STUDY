#pragma once
#include <DirectXMath.h>
using namespace DirectX;
//���� : ����� ���� ������ ���
struct Vertex
{
	XMFLOAT3 pos;
	//3���� ������ ���
	Vertex() : pos(0.0f, 0.0f, 0.0f) {}
	Vertex(float x, float y, float z) : pos(x, y, z) {}
};

//������ ���� ���?
struct VertexColor : Vertex
{
	XMFLOAT4 color;

	VertexColor() : color(1.0f, 1.0f, 1.0f, 1.0f) {}
	VertexColor(float x, float y, float z, float r, float g, float b, float a) : Vertex(x, y, z), color(r, g, b, a) {}
	VertexColor(float x, float y, float z, float r, float g, float b) : VertexColor(x, y, z, r, g, b, 1.0f) {}
};

struct VertexTexture : VertexColor
{
	XMFLOAT2 texCoord;
	VertexTexture() : texCoord(0.0f, 0.0f) {}
	VertexTexture(float x, float y, float z, float r, float g, float b, float a, float u, float v) : VertexColor(x, y, z, r, g, b, a), texCoord(u, v) {}
	VertexTexture(float x, float y, float z, float r, float g, float b, float u, float v) : VertexTexture(x, y, z, r, g, b, 1.0f, u, v) {}
	VertexTexture(float x, float y, float z, float u, float v) : VertexTexture(x, y, z, 1.0f, 1.0f, 1.0f, 1.0f, u, v) {}
};