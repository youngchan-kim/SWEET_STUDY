#include "Weapon.h"

Weapon::Weapon() {}

void Weapon::Load(ifstream& load)
{
	load >> m_strname;
	load >> m_idamage;
	load >> m_iprice;
}

Weapon::~Weapon() {}