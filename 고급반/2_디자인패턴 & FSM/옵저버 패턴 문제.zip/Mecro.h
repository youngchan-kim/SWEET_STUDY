#pragma once
#include<iostream>
#include<time.h>
#include<vector>
#include<Windows.h>
#define INTNULL 0
#define	CHARNULL ""

//struct Person_info
//{
//	std::string strName;
//	std::string strNew;
//	int day;
//};