#pragma once
#include <iostream>
#include <Windows.h>

#define TRUE 1

using namespace std;

class Computer
{
private:

	string atrname;
	string stronoff;
	string strgtx;
	string strcpu;
	string strmemory;

	int i_mlist;

public:
	void State();
	void Skill();
	void List();
	void Computer_Exit();
	Computer();
	~Computer();
};