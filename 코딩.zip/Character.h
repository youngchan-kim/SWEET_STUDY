#pragma once
#include "Mecro.h"
#include "MapDraw.h"

#define MOSTEREXP 0

class Character
{
protected:
	string m_strname;
	int m_idamage;
	int m_imaxhealth;
	int m_imaxexp;
	int m_igetexp;
	int m_iLv;
	int m_igold;
	int m_iexp;
	int m_icurhealth;
	MapDraw mapdraw;

public:
	virtual void Load(ifstream& load, string name="") = 0;
	virtual void Infomation(int x, int y) = 0;

	virtual int Getexp() { return m_igetexp; }
	virtual int Gold() { return m_igold; }
	virtual int Atteck() { return m_idamage; }
	virtual int CurrentHealth() { return m_icurhealth; }
	virtual void Damaged(int monsterdamage)
	{
		m_icurhealth -= monsterdamage;
	}
	virtual string GetName() { return m_strname; }

	Character();
	virtual ~Character();
};

