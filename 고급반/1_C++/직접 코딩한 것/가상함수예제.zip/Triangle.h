#pragma once
#include"Figure.h"

class Triangle : public Figure
{
public:
	void Draw() override;
	void SetSize() override;
	Triangle();
	~Triangle();

};

