#pragma once
#include "BitMapManager.h"

class Play_Fire
{
private:
	BitMap** bmfire;
	int width, height;
	float background_max_distance;

	int distance_unit;
	int animation;
	float ani_time;
	float fire_start_x, fire_x, fire_y, fire_width, fire_height;

public:
	Play_Fire();
	~Play_Fire();
	void Init(int width, int height, float background_max_distance);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed, float distance);
};

