#include "Word.h"
Word::Word() {};
Word::~Word() {};

//void Word::Drop()
//{
//	
//}
//void Word::Die()
//{
//
//}
