#include "MinerOwnedStates.h"
#include "EntityNames.h"
#include "ConsoleUtils.h"

// EnterMineAndDigForNugget ------------------------------------
EnterMineAndDigForNugget* EnterMineAndDigForNugget::Instance()
{
	static EnterMineAndDigForNugget instance;
	return &instance;
}

void EnterMineAndDigForNugget::Enter(Miner* pMiner)
{
	if (pMiner->Location() != Location_Type::gold_mine)
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":Going to mining." << std::endl;

		pMiner->ChangeLocation(Location_Type::gold_mine);
	}
}

void EnterMineAndDigForNugget::Excute(Miner* pMiner)
{
	pMiner->AddToGoldCarried(1);

	pMiner->IncreaseFatigue();

	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ":Got 1 gold." << std::endl;

	// if money pocket is full,
	if (pMiner->PocketsFull())
	{
		// going to bank to deposit
		pMiner->ChangeState(VisitBankAndDepositGold::Instance());
	}

	// if thristy,
	if (pMiner->Thirsty())
	{
		// act to solve thristyness
		pMiner->ChangeState(QuenchThirst::Instance());
	}
}

void EnterMineAndDigForNugget::Exit(Miner* pMiner)
{
	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ": with Gold " << pMiner->GoldCarried() << ", leaving the mining" << std::endl;
}
// -------------------------------------------------------------

// VisitBankAndDepositGold ------------------------------------
VisitBankAndDepositGold* VisitBankAndDepositGold::Instance()
{
	static VisitBankAndDepositGold instance;
	return &instance;
}

void VisitBankAndDepositGold::Enter(Miner* pMiner)
{
	if (pMiner->Location() != Location_Type::bank)
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":heading to bank" << std::endl;

		pMiner->ChangeLocation(Location_Type::bank);
	}
}

void VisitBankAndDepositGold::Excute(Miner* pMiner)
{
	pMiner->AddToWealth(pMiner->GoldCarried());

	pMiner->SetGoldCarried(0);

	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ":deposit gold\n\ncurrent balance:" << pMiner->Wealth() << std::endl << std::endl;

	// check how much is saved,
	if (pMiner->Wealth() >= COMFORT_LEVEL)
	{
		// saved until saticified.
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":\"woah! I am rich now. I'm going back home.\"" << std::endl;

		pMiner->ChangeState(GoHomeAndSleepTilRested::Instance());
	}
	else
	{
		// not enough money. going back to mining.
		pMiner->ChangeState(EnterMineAndDigForNugget::Instance());
	}
}

void VisitBankAndDepositGold::Exit(Miner* pMiner)
{
	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ":leaves bank" << std::endl;
}
// -------------------------------------------------------------

// GoHomeAndSleepTilRested -------------------------------------
GoHomeAndSleepTilRested* GoHomeAndSleepTilRested::Instance()
{
	static GoHomeAndSleepTilRested instance;
	return &instance;
}

void GoHomeAndSleepTilRested::Enter(Miner* pMiner)
{
	if (pMiner->Location() != Location_Type::shack)
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":heading back home" << std::endl;

		pMiner->ChangeLocation(Location_Type::shack);
	}
}

void GoHomeAndSleepTilRested::Excute(Miner* pMiner)
{
	// check how tired.
	if (!pMiner->Fatigued())
	{
		// when not tired, go back to mining.
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":\"Took a long nap! need to go back to gold mining. \"" << std::endl;

		pMiner->ChangeState(EnterMineAndDigForNugget::Instance());
	}
	else
	{
		// tired== taking a nap.
		pMiner->DecreaseFatigue();

		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":...zZ" << std::endl;
	}
}

void GoHomeAndSleepTilRested::Exit(Miner* pMiner)
{
	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ":leaves home" << std::endl;
}
// -------------------------------------------------------------

// QuenchThirst ------------------------------------------------
QuenchThirst* QuenchThirst::Instance()
{
	static QuenchThirst instance;
	return &instance;
}

void QuenchThirst::Enter(Miner* pMiner)
{
	if (pMiner->Location() != Location_Type::saloon)
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":\"thirsty!\"" << std::endl;
		std::cout << GetNameOfEntity(pMiner->ID()) << ":going to a bar" << std::endl;

		pMiner->ChangeLocation(Location_Type::saloon);
	}
}

void QuenchThirst::Excute(Miner* pMiner)
{
	// if thristy,
	if (pMiner->Thirsty())
	{
		// because i am thirsty, let me drink beer.
		pMiner->BuyAndDrinkAWhiskey();

		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pMiner->ID()) << ":drinks beer" << std::endl;

		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << "\ncurrent balance:" << pMiner->Wealth() << std::endl << std::endl;

		pMiner->ChangeState(EnterMineAndDigForNugget::Instance());
	}
	else
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << "\nError!\nError!!\nError!!!" << std::endl;
	}
}

void QuenchThirst::Exit(Miner* pMiner)
{
	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pMiner->ID()) << ":leaves bar" << std::endl;
}
// -------------------------------------------------------------