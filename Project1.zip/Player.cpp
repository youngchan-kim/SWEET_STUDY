#include "Player.h"

Player::Player() {}

void Player::NewPlayer(string m_strname)
{
	Info::Infomation(m_strname);
}



Player::~Player() {}