#pragma once
#include<iostream>
using namespace std;

class Quiz02
{
public:
	void Quiz2(string str01);
	void Quiz2(string str01, string str02);
	Quiz02();
	~Quiz02();
};

