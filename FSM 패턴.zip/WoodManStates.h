#pragma once
#include "WoodMan.h"

class EnterWoodCutting : public State
{
private:
	EnterWoodCutting() {}
	EnterWoodCutting(const EnterWoodCutting&);
	EnterWoodCutting& operator =(const EnterWoodCutting&);

public:
	static EnterWoodCutting* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};

class VisitMarket : public State
{
private:
	VisitMarket() {}
	VisitMarket(const VisitMarket&);
	VisitMarket& operator=(const VisitMarket&);

public:
	static VisitMarket* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};
/*
//�ɰ���	�ڵ�	����	������Ʈ	����	��	��ǥ�� ����(Suppression) ����
//����	LNK2005	"public: static class VisitBankAndDepositGold * __cdecl VisitBankAndDepositGold::Instance(void)" (? Instance@VisitBankAndDepositGold@@SAPEAV1@XZ)��(��) WoodManStates.obj�� �̹� ���ǵǾ� �ֽ��ϴ�.CODING	C : \Users\A - 03\Desktop\�迵��\FSM ����\MinerOwnedStates.obj	1
class VisitBankAndDepositGold : public State
{
private:
	VisitBankAndDepositGold() {}
	VisitBankAndDepositGold(const VisitBankAndDepositGold&);
	VisitBankAndDepositGold& operator=(const VisitBankAndDepositGold&);

public:
	static VisitBankAndDepositGold* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};
*/
class VisitBank : public State
{
private:
	VisitBank() {}
	VisitBank(const VisitBank&);
	VisitBank& operator=(const VisitBank&);

public:
	static VisitBank* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};
/*
//�ɰ���	�ڵ�	����	������Ʈ	����	��	��ǥ�� ����(Suppression) ����
//����	LNK2005	"public: static class GoHomeAndSleepTilRested * __cdecl GoHomeAndSleepTilRested::Instance(void)" (? Instance@GoHomeAndSleepTilRested@@SAPEAV1@XZ)��(��) WoodManStates.obj�� �̹� ���ǵǾ� �ֽ��ϴ�.CODING	C : \Users\A - 03\Desktop\�迵��\FSM ����\MinerOwnedStates.obj	1
class GoHomeAndSleepTilRested : public State
{
private:
	GoHomeAndSleepTilRested() {}
	GoHomeAndSleepTilRested(const GoHomeAndSleepTilRested&);
	GoHomeAndSleepTilRested& operator=(const GoHomeAndSleepTilRested&);

public:
	static GoHomeAndSleepTilRested* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};
*/
class GoHome : public State
{
private:
	GoHome() {}
	GoHome(const GoHome&);
	GoHome& operator=(const GoHome&);

public:
	static GoHome* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};
class Hungry : public State//���⼭ ���� �ڵ�
{
private:
	Hungry() {}
	Hungry(const Hungry&);
	Hungry& operator = (const Hungry&);
public:
	static Hungry* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};

class Fatigue : public State//���⼭ ���� �ڵ�
{
private:
	Fatigue() {}
	Fatigue(const Fatigue&);
	Fatigue& operator = (const Fatigue&);
public:
	static Fatigue* Instance();

	virtual void Enter(WoodMan*);
	virtual void Excute(WoodMan*);
	virtual void Exit(WoodMan*);
};