#pragma once
#include "Mecro.h"
#include "Interface.h"
//�ܾ �����ϴ°�,�ܾ �׸���, ����Ʈ����, �����

//__interface WordInterface
//{
//	void Draw();
//	void Drop();
//	void Die();
//};

class Word// : public WordInterface
{
private:
	Interface mapdraw;

	int x;
	int y;
	std::string strString;
	bool isDead;

	Word();
public:
	Word(std::string str) : strString(str){}
	~Word();

	bool IsDead() const { return isDead; };
	void SetWord(int x, int itemType) { y = 0; this->x = x; isDead = false;
	}

	void Draw()  { mapdraw.TextDraw(strString, x, y); mapdraw.ErasePoint() }//����� �߰�
	void Drop() { y--; }
	void Die()  { isDead = true; }
};

