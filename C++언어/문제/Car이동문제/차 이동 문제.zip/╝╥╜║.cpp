#include"Mecro.h"
#include"MapDraw.h"
#include"Manager.h"

void main()
{
	Manager manager;
	manager.CarDriver();
}

