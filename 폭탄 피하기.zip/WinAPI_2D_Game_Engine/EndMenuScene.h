#pragma once

#include "EngineMecro.h"
#include "Components/LRInput.h"
#include "UIManager.h"
#include "DemoScene.h"
#ifndef END_MENU_SCENE_H
#define END_MENU_SCENE_H

using namespace ENGINE;

class EndMenuScene : public Scene
{
	Bitmap* background = nullptr;

	std::string board_name;
	//UIButton* retryBtn;
	UIImage* EndWindow;
	UILabel* board;

	HFONT font;

	float bounds;
public:
	// Scene��(��) ���� ��ӵ�
	virtual VOID Initialize() override;
	virtual VOID Release() override;
	virtual VOID Update(const FLOAT& deltaTime) override;
	virtual VOID Draw() override;

	VOID ContinueBtnClickHandler();
	VOID QuitBtnClickHandler();
};

#endif
//�ʿ��� �� �������� ���� 