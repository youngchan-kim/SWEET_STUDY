#pragma once
#include "Character.h"
#include "Weapon.h"
#define UPATTACKSTAT 4

class Player : public Character
{
private:
	Weapon* weapon;
public:
	Player();
	inline int Atteck() { return m_idamage + ((NULL != weapon) ? weapon->Damage() : 0); }; //���׿����� 
	inline int Gold() { return m_igold; };
	inline int PlayerHP() { return m_icurhealth; };
	inline void Curhealth(int monsterdamage) { m_icurhealth =-monsterdamage; };


	void Load(ifstream& load, string name = "") override;
	void Save(ofstream& save);
	void Infomation(int x, int y) override;
	void Levelup();
	void GetWinner(int exp, int gold);
	void WeaponBuy(Weapon* weaponwear);
	~Player();
};

