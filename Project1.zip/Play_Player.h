#pragma once
#include "BitMapManager.h"

#define PLAYER_WIDTH 100
#define PLAYER_HEIGHT 100

class Play_Player
{
private:
	BitMap** bmplayer;
	int player_x, player_y;
	int width, height;
public:
	Play_Player();
	~Play_Player();
	void Init(int width, int height);
	void Draw(HDC backDC);
	void Update(float deltatime);
};

