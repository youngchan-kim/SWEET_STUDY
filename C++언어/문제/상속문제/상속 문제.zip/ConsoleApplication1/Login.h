#pragma once
#include<iostream>
#include<string>
#include<Windows.h>

using namespace std;

#define TURE 1
#define IDLEN 3
#define PASSWORDLEN 8
#define IDMAX 10

struct ID
{
	string Id;
	string Password;
	string Name;
	int Age;
	string PhonNumber;
	int Mileage;
};

class Login
{
private:
	int i_mId_Count = 0;
	ID Id_List[IDMAX];
	int i_mSelect;

protected:
	int iloginindex;
public:

	void Menu();

	bool StringCheck(char Start, char End, char Check);

	void Join();

	void SimpleShowID(ID* id);

	void ShowID(int i);

	void Setstring(ID* id, string tmp);

	void Setint(ID* id, string tmp);

	void SetID(int i);

	void main();

	Login();
	~Login();
};