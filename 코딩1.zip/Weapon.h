#pragma once
#include "Mecro.h";
class Weapon
{
private:
	string m_strweapon;
	string m_strname;
	int m_idamage;
	int m_iprice;

public:

	void Load(ifstream& load);
	void WeaponInfo(int x, int y);
	void Critical();
	inline int Price() {return m_iprice;};
	inline int Damage() {return m_idamage;};

	Weapon();
	~Weapon();

};

