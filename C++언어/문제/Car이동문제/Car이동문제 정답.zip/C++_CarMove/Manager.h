#pragma once
#include "Mecro.h"
#include "CarClass.h"
#include "TimerClass.h"

class Manager
{
private:
	std::list<CarClass> CarList;
	TimerClass Time_Create_NewCar;
public:
	Manager();
	void PlayLoop();
	void CarMoveController();
	void CreateCar();
	void Input();
};
