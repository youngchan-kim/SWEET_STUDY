#pragma once
#include"Student.h"


#define STUDENT_MAX 10
#define NULL 0
class StudentManager
{
private:
	int m_iStudentCount = 0;
	Student m_StudentList;
	list<Student> studentlist;
public:
	void AddStudent();
	inline int GetStudentCount()
	{
		return m_iStudentCount;
	}
	void ShowStudentList();
	void ShowStudentClassList();
	void FindStudentName(); 
	void FindStudentClass(); 
	void StudentListLastDelete(); 
	void StudentAllDelete();
	StudentManager();
	~StudentManager();
};