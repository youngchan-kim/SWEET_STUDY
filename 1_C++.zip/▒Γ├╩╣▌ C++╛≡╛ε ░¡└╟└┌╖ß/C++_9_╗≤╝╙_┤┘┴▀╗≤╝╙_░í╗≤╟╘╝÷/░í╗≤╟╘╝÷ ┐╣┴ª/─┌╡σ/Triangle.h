#pragma once
#include"Figure.h"
class Triangle : public Figure
{
public:
	void Draw();
	void SetSize();
	Triangle();
	~Triangle();
};

