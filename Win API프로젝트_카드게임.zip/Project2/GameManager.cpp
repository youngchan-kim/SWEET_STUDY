#include "GameManager.h"
GameManager* GameManager::m_pInstance = NULL;



void GameManager::Create_Game(HWND hWnd, STAGE& stage)
{
	BitmapMgr->Init(hWnd);
	stage = MAIN;
}

////�����ϰ� 0���� 9���� �����ϰ� 2���� ��Ȯ�� ���;���
//int GameManager::Random_Card()
//{
//	int one[IMAGE_BLACK], two[IMAGE_BLACK];
//	while(1)
//	{
//		int random = rand() % 10;
//		for (int i = 0; i == 10; i++)
//		{
//
//		}
//
//	}
//
//	return 0;
//}


void GameManager::Stage(HDC hdc, STAGE stage)
{

	if (stage == MAIN)
	{
		std::wstring str = L"[���� ����]";
		Rectangle(hdc, 250, 300, 350, 350);
		Start_rect = { 250, 320, 350, 400 };
		DrawText(hdc, str.c_str(), -1, &Start_rect, DT_VCENTER | DT_CENTER);
	}
	else if (stage == GAMING)
	{
		card.BackGround(hdc);
		int x = 80, y = 120;

		for (int i = IMAGE_DOG; i < IMAGE_BLACK; i++)
		{
			if (i >= 4 && i % 5 == 0) { x = 80;	y += 130; }
			card.Init((IMAGE)i, x, y);
			card.Draw(hdc);
			x += 90;
			
		}
		
	}
	
	
}

void GameManager::ColliderCheck(HWND hWnd, POINT point , STAGE &stage)
{
	STAGE tmp_stage = StageCheck(stage);
	if (tmp_stage == MAIN)
		if (PtInRect(&Start_rect, point))
		{
			stage = GAMING;
			InvalidateRect(hWnd, NULL, true);
		}
	else if (tmp_stage == GAMING)
		if (card.ColliderCheck(point))
			InvalidateRect(hWnd, NULL, true);
	//����ġȭ
}

STAGE GameManager::StageCheck(STAGE& stage)
{
	if (stage == MAIN) return MAIN;
	else return GAMING;
}

