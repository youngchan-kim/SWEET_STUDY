#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Weapon.h"
#include <map>
#include <vector>
#include <cmath>



class Player;
class Shop
{
private:
	MapDraw mapdraw;
	map<string, vector<Weapon*>> weaponmap;	

	//�ʰ� ���͸� ���� �� ��
public:
	Shop();
	void ShopMenu(int x, Player* player);
	void Load();
	void SelectWeaponlist(int select, int x, int y, Player* player);
	void SetWeapon(Weapon* weapon, Player* player);
	~Shop();
};

