// TimeManager.cpp
#include "TimeManager.h"

namespace ENGINE
{
	VOID TimeManager::Initialize(UNIT32 FPS)
	{

	}
}