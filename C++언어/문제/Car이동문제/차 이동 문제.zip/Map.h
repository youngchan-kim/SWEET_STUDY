#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include "Character.h"
class Map
{
private:
	int m_ix;
	int m_iy;
	int m_iWidth;
	int m_iHeight;

	Character character;
public:
	void MapDraw();
	Map();
	~Map();
};

