#include "Character.h"

Character::Character() {
	
}

void Character::Infomation()
{
	int m_iWidth = 30;
	int m_iHeight = 34;
	string line1, line2, line3, line4;
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	mapdraw.DrawMidText(line1 , m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.55f);
	mapdraw.DrawMidText(line3, m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText(line4, m_iWidth, m_iHeight * 0.65f);

}

void Character::NewPlayer(string name)
{
	m_strname = name;
	ifstream load;
	load.open("DefaultPlayer.txt");
	if (!load.eof()) // �ϼ�
	{
		load >> m_idamage;
		load >> m_imaxhealth;
		load >> m_imaxexp;
		load >> m_igetexp;
		load >> m_iLv;
		load >> m_igold;
	}
	load.close();				
	Infomation();
}
void Character::LoadPlayer()
{
	ifstream load;
	load.open("DefaultPlayer.txt");
	if (!load.eof()) // �ϼ�
	{
		load >> m_idamage;
		load >> m_imaxhealth;
		load >> m_imaxexp;
		load >> m_igetexp;
		load >> m_iLv;
		load >> m_igold;
	}
	load.close();
	Infomation();
}

void Character::Monster()
{
	int monsterlist = 0;
	ifstream load;
	load.open("DefaultMonster.txt");
	if (!load.eof()) // �ϼ�
	{
		load >> monsterlist;
		for (int i = 0; i < monsterlist; i++)
		{
			load >> m_strname;
			load >> m_idamage;
			load >> m_imaxhealth;
			load >> m_imaxexp;
			load >> m_igetexp;
			load >> m_iLv;
			load >> m_igold;
		}
	}
	load.close();
	Infomation();
}


Character::~Character() {}