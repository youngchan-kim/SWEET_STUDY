#include"Sum.h"

void main()
{
	Sum sum1;
	sum1.SetSum(100);
	sum1.ShowSum();
	sum1.SetSum();
	sum1.ShowSum();
}