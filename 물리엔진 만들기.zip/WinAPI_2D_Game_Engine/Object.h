#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>

class Object
{
public:

	//����
	float mass;
	float invMass;
	//�ӷ�
	Vector2 velocity;
	Vector2 position;
	bool fix;

public:
	void Update();
	
	float GetMass() { return mass; }
	float GetInvMass()
	{
		return invMass;
	}
	Vector2 GetPosition() { return position; }
	Vector2 GetVelocity() { return velocity; }
	void Add_Gravity(Vector2 gravityvelocity) { if (!fix)velocity += gravityvelocity; }
	//��ü�� ���� ������ �ӵ�
	void Add_Velocity(Vector2 addvelocity) { if (!fix)velocity += addvelocity; }
	//void Add_Gravity() { this->velocity = }
};

