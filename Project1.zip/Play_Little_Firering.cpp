#include "Play_Little_Firering.h"
#include <wtypes.h>


void Play_Little_Firering::Init(int width, int height, float dont_move_point, float distance_unit)
{
	Play_FireRing::Init(width, height, dont_move_point, distance_unit);
	ring_height = height * 0.3f;
	speed = 170;
	score = 0;

	cash.Init(width, height, dont_move_point, speed, distance_unit);

}

void Play_Little_Firering::L_Draw(HDC backDC)
{
	Play_FireRing::L_Draw(backDC);
	cash.Draw(backDC);
}

void Play_Little_Firering::R_Draw(HDC backDC)
{
	Play_FireRing::R_Draw(backDC);
}

void Play_Little_Firering::Update(float deltatime, int speed, float distance, bool win)
{
	score = 0;
	Play_FireRing::Update(deltatime, speed, distance, win);
	cash.Update(deltatime, speed, distance, win);
}

int Play_Little_Firering::Play_ScoreUp(RECT player_Rect)
{
	score+=Play_FireRing::Play_ScoreUp(player_Rect);
	score+=cash.Play_ScoreUp(player_Rect);
	return score;

}

void Play_Little_Firering::Gameset()
{
	Play_FireRing::Gameset();
	cash.Gameset();
}

void Play_Little_Firering::Dead()
{
	Play_FireRing::Dead();
	cash.Dead();
}

bool Play_Little_Firering::Play_DeadIntersect(RECT player_Rect)
{
	if (Play_FireRing::Play_DeadIntersect(player_Rect))
		return true;
	return false;
}
