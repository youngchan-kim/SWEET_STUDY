#pragma once
#include "Mecro.h"

enum TIMER_TYPE
{
	TIMER_TYPE_ONCE,
	TIMER_TYPE_LOOP,
	TIMER_TYPE_COUNT
};

class Timer
{
private:
	int m_iOldTime;
	int m_iSecond;
	bool m_bLive;
	TIMER_TYPE Timer_Type;
	int m_iMaxCount;
	int m_iCurCount;
	std::function<void()> m_callbackFunc;

public:
	Timer();
	~Timer();
	inline void SetTimer(int iSecond) { m_iSecond = iSecond; }
	void SetTimer(TIMER_TYPE Type, int iSecond, std::function<void()> _callbackFunc, int iMaxCount = -1);
	bool CheckTimer();

};

