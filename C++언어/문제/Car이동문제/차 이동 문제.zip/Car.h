#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include <list>

struct Position
{
	int i_mcarx;
	int i_mcary;
};

class Car
{
private:
	int m_istart_x;
	int m_istart_y;
	int m_icarwidth;
	int m_icarheight;
	Position carposition;
	int carclock;
	bool speedup;

	int moveclock;
public:
	//inline bool Speed() { return speedup;};
	inline int X_Position(){return carposition.i_mcarx;};
	void SpeedBool();
	void CarPositionInput();
	void EraseCar();
	void DrawCar();
	void CreateCar();
	void MoveCheck(int m_moveclock);
	void MoveCar(int m_moveclock);
	Car();
	~Car();

};
