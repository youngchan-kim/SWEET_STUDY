#include"Computer.h"

void main()
{
	Computer computer;
}