// WinApiEngine.cpp
#include "WinApiEngine.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

namespace ENGINE
{

	WinApiEngine::WinApiEngine(HINSTANCE hInstance, std::wstring title, INT32 per_x, INT32 per_y, UINT32 width, UINT32 height)
		: isInit(FALSE), title(title), x(0), y(0), width(width), height(height)
	{
		WNDCLASSEXW wcex = 
		{
			sizeof(WNDCLASSEX), //�� ����ü�� ũ��.
			CS_HREDRAW | CS_VREDRAW,
		}
	}
}