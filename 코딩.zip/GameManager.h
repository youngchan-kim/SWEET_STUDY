#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Player.h"
#include "Monster.h"


class GameManager
{
private:
	int m_iWidth;
	int m_iHeight;
	int Start_x;
	int Start_y;
	MapDraw mapdraw;
	Player player;
	Monster monster;
public:
	void MainMenu();
	void GameMenu();

	void Start();
	void Playing();

	void Dongeon();
	void Player_Info();
	void Monster_Info();
	void Weapon_Shop();
	void Save();
	GameManager();
	~GameManager();
};

