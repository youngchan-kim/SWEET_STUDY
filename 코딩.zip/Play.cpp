#include "Play.h"
Play::Play() {}

void Play::Clearmap()
{
	BLUE_GREEN
	system("cls");
	mapdraw.BoxDraw(START_X, START_Y, MAX_X, MAX_Y);
	ORIGINAL
}

void Play::MainMenu()
{
	Clearmap();
	BLUE_GREEN
	mapdraw.DrawMidText("�� �� �� �� ġ �� �� ��", MAX_X, MIDDLE_Y / 2);

	ORIGINAL
}

Play::~Play() {}