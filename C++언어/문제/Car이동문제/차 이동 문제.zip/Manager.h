#pragma once
#include"MapDraw.h"
#include"Car.h"
#define SPACEBAR 32
class Manager
{
private:

	Car car;
	int m_imainclock;
	int m_isetcarclock;
	int m_moveclock;
	list<Car> m_carlist;
public:
	void SetCar();
	void SpeedSwap();
	void ReMove();
	void MoveCar();
	void CarDriver();
	Manager();
	~Manager();
};

