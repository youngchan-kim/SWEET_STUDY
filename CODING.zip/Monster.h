#pragma once
class Monster
{
};

