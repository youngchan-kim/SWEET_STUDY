#include "Quiz02.h"


Quiz02::Quiz02()
{
}

void Quiz02::Quiz2(string str01)
{
	char tmp;
	str01.length();
	cout << str01 << " -> ";
	for(int i =0; i < str01.size()-1; i++)
	{
		for (int j = i; j < str01.size(); j++)
		{
			if (str01[i] != str01[j])
			{
				tmp = str01[j];
				str01[j] = str01[i];
				str01[i] = tmp;
			}
		}
	}
	cout << str01 << endl;
}

void Quiz02::Quiz2(string str01, string str02)
{
	cout << str01 << " + " << str02 << " : " << str01 + str02 << endl;
}
Quiz02::~Quiz02()
{
}