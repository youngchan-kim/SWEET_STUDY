#pragma once
#include "BitMapManager.h"


class Play_Interface
{
private:
	BitMap** bminterface;
public:
	Play_Interface();
	~Play_Interface();
	void Init();
	void Draw(HDC backDC);
	void Update(float deltatime);
};

