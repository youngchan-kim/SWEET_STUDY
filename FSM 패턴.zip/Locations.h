#pragma once


enum class Location_Type
{
	shack,
	gold_mine,	
	bank,		
	saloon		// bar
};

enum class MyLocationType {
	shack,
	forest,
	market,
	bank,
	home
};