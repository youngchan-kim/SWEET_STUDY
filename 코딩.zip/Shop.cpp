#include "Shop.h"

string weaponTypes[] = { "Dagger", "Gun", "Sword", "Wand", "Bow", "Hammer" };
Shop::Shop()
{
}
void Shop::ShopMenu(int x)
{
	int i = 0, height = 8;
	mapdraw.DrawMidText("�� �� S H O P �� ��", x, height);
 for(i = 0; i < Max_Weapon_Num; i++)
 	mapdraw.DrawMidText(weaponTypes[i], x, (height += 2));
 mapdraw.DrawMidText("���ư���", x, (height += 2));

}
void Shop::Load()
{
	Weapon* weapon = NULL;
	ifstream load;
	load.open("WeaponList.txt");
	string weapontype;
	if (load.is_open())
	{
		while (!load.eof())
		{
			load >> weapontype;
			if ("Bow" == weapontype)
				weapon = new Bow;
			else if("Dagger" == weapontype)
				weapon = new Dagger;
			else if ("Gun" == weapontype)
				weapon = new Gun;
			else if ("Sword" == weapontype)
				weapon = new Sword;
			else if ("Wand" == weapontype)
				weapon = new Wand;
			else if ("Hammer" == weapontype)
				weapon = new Hammer;

			if (NULL != weapon)
			{
				weapon->Load(load);
				weaponmap[weapontype].push_back(weapon);
				//��ĳ���� �ڽ��� �Լ��� �θ������� ��ȯ�Ѵ�.
				//��� Ÿ�� ���� ��ĳ���� �ǵ���
			}
		}
		load.close();
	}
}
void Shop::SelectWeaponlist(int select, int x ,int y)
{
	string weaponType = weaponTypes[select - 1];
	vector<Weapon*> weaponList = weaponmap[weaponType];
	const int maxPage = (float)weaponList.size() / (float)Max_Weapon_Count;// �ø� ó�� �ʿ�.

	int page = 1;
	int count = 0;
	Weapon* weapon = NULL;
	while (true)
	{
		count = min(weaponList.size(), Max_Weapon_Count * page); //min()�Լ��� ���� ã�ƺ� ��
		for (int i = (page - 1) * Max_Weapon_Count; count > i; i++)
		{
			weapon = weaponList[i];
			weapon->WeaponInfo(x, y + i * (1));
		}

		//page++;
		//if (page > maxPage) page = maxPage;
	}
	
}

void Shop::SetWeapon()
{
	/*Weapon* weapon;
	ifstream load;
	load.open("WeaponList.txt");
	if (load.is_open())
	{
		while (!load.eof())
		{
			load >> m_strweapon;
			if ("Bow" == m_strweapon)
			{
				weapon = new Bow(m_strweapon);
			}

			weapon->Load(load);
			weaponlist.push_back(weapon);
		}
		load.close();
	}*/
}
Shop::~Shop() {}