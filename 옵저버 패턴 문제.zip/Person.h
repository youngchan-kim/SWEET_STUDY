#pragma once
#include "Observer.h"
class Person : public Observer
{
private:
	std::string strName;
	std::string strNew;
	int day;
public:
	Person();
	~Person();
	virtual void Update();
	virtual void OutPut();
	std::string Get_Name() { return strName; }
};

