#include "Player.h"
Player::Player() {}

void Player::Load(ifstream& load, string name)
{
	bool isLoad;
	isLoad = ("" == name);
	if (isLoad) load >> m_strname;
	else if (!isLoad) m_strname = name;
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	if (isLoad)
	{
		load >> m_iexp;
		load >> m_icurhealth;
		//load >> weapon;
	}
}

void Player::Infomation()
{
	int m_iWidth = 30;
	int m_iHeight = 30;
	string line1, line2, line3, line4;
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.55f);
	mapdraw.DrawMidText(line3, m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText(line4, m_iWidth, m_iHeight * 0.65f);
}

Player::~Player() {}