#include "EngineMecro.h"
#include "Components/SpriteRenderer.h"
#include "Components/SpriteAnimation.h"
#include "Components/LRInput.h"
#include "UIManager.h"
//#include "Player.h"
//#include "Dropitem.h"
//#include "Bomb_effect.h"
//#include "EndMenuScene.h"
#include "Circle.h"
#include "Box.h"
#ifndef DEMO_SCENE_H
#define DEMO_SCENE_H

using namespace ENGINE;

enum OBJECT_Circle {
	Circle1,
	Circle2,
	//Circle3,
	total_Circle,
};
enum OBJECT_Box {
	Box1,
	Box2,
	total_Box,
};

class DemoScene : public Scene
{
public:
	Circle* circle[total_Circle];

	Box* box[total_Box];
	
private:
	/*float e = 0.02f;*/
	float e = 2.0f;
	float penetration;
	bool crash;
	Vector2 normal;
	Vector2 RelativeVelocity;
	Vector2 g;
public:
	// Scene��(��) ���� ��ӵ�
	virtual VOID Initialize() override;
	VOID Release();
	virtual VOID Update(const FLOAT& deltaTime) override;
	virtual VOID Draw(HDC hdc) override;

	//bool AABBvsAABB(Box* lhs, Box* rhs);


	bool CirclevsCircle(Circle* lhs, Circle* rhs);

	void Crash(Circle* lhs, Circle* rhs);

	Vector2 Add_Gravity(const FLOAT& deltaTime);
};

#endif // !DEMO_SCENE_H