#pragma once
#include"Mecro.h"
#include "BlockClass.h"


enum ARROW
{
	UP = 119,
	DOWN = 115,
	RIGHT = 100,
	LEFT = 97
};


class SnackClass
{
private:

	BlockClass head;
	std::vector<BlockClass> teillist; //vector�� ����
	Position m_tmpposition;

	char ch_mmove;
	int m_ilife;
	int m_isnackmaintime;
	int m_ispeed;

public:
	inline int Score() {return m_ilife;};
	inline Position SnackPosition() { return head.PositionXY(); };
	bool HeadTeilCrush();

	bool HeadPositionCheck(Position cursor);
	bool TeilPositionCheck(Position cursor);
	
	void SetHead(Position cursor);
	void Add_Teil();
		
	void Teil_Move();
	void Move(int x, int y);
	void Head_MoveArray(char ch);
	void Head_Move();

	void END();

	SnackClass();
	~SnackClass();
};