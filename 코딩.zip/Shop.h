#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Weapon.h"
#include <map>
#include <vector>

enum Size
{
	Max_Weapon_Count = 5,
	Max_Weapon_Num = 6
};

class Player;
class Shop
{
private:
	MapDraw mapdraw;
	map<string, vector<Weapon*>> weaponmap;	

	//�ʰ� ���͸� ���� �� ��
public:
	Shop();
	void ShopMenu(int x, Player* player);
	void Load();
	void SelectWeaponlist(int select, int x, int y, Player* player);
	void SetWeapon(vector<Weapon*> weaponList, int select, int page, Player* player);
	~Shop();
};

