#pragma once
#include<iostream>
using namespace std;

class Quiz1
{
private:
	int x;
	int y;
public:
	Quiz1();
	Quiz1(int a, int b);
	void Print();
	friend Quiz1 operator/(Quiz1 quiz1, Quiz1 quiz2);
	~Quiz1();
};
