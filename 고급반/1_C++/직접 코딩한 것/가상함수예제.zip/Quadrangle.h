#pragma once
#include "Figure.h"

class Quadrangle : public Figure
{
public:
	void Draw();
	Quadrangle();
	~Quadrangle();
};

