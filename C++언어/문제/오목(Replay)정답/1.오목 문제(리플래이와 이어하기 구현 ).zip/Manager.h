#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include "Player.h"
#define TRUE 1
#define NULL 0

#define NOMALLSIZE 20
#define NOMALLUNDO 5
#define NULL 0
#define STARTTURN 1
class Manager
{
private:
	ofstream save;
	ifstream load;
	int start_x;
	int start_y;
	int m_iwidth;
	int m_iheight;
	int m_iundo;

	string m_strcursurblack;
	string m_strcursurwhite;
	string m_strstoneblack;
	string m_strstonewhite;

	Player Player1;
	Player Player2;
	int m_igameturn;
	Position Cursor;
	string state;
	bool win;
	bool savefile;
	
public:
	void PlayerBacking(Position Cursor, Player *me, Player *opponent);
	void OMokSave();
	void OMokLoad();
	void RePlaySave();
	void RePlayLoad();
	bool GamePlayer(Player *me, Player *opponent);
	void FirstPage();
	void OptionMapSizeSet();
	void OptionSetCursor();
	void OptionSetStone();
	void OptionSetUndo();
	void Option();
	void GameSet();
	void GameState();
	void GameTurn();
	void RePlayTurn(int replayturn);
	Manager();
	~Manager();
};

