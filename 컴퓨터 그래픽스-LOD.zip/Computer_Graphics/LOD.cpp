#include "LOD.h"

bool LOD::Initialize(DXCamera* camera, int maxLevel)
{
    if (!camera) return false;

    cameraTransform = camera->GetGameObject()->GetTransform();
    ratio = maxLevel / camera->GetDepth();

    return true;
}

int LOD::GetInvLevel(XMFLOAT3 v)
{
    XMVECTOR vector = XMVectorSet(v.x, v.y, v.z, 1.0f);
    float distance = XMVectorGetX(XMVector3Length(cameraTransform->GetPosition() - vector));

    int invLevel = std::ceil(distance * ratio);

    return ((1>invLevel)? 1: invLevel);
}
