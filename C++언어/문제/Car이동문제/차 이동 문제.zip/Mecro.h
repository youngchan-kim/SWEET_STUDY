#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<iomanip>
#include<Windows.h>
#include<time.h>
using namespace std;