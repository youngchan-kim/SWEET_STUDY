#pragma once
#include "Character.h"
class Player : public Character
{
private:
public:
	Player();
	inline int Atteck() { return m_idamage; };
	inline int Gold() { return m_igold; };
	inline int Gethealth() { return m_icurhealth; };
	void Load(ifstream& load, string name = "") override;
	void Save(int slot);
	void Infomation(int x, int y) override;
	void Curhealth(int tookdamage);
	void GetWinner(int exp, int gold);
	~Player();
};

