#include "Play_FireRing.h"
#include <wtypes.h>
Play_FireRing::Play_FireRing()
{
	bmring = new BitMap * [RING_4];
}

Play_FireRing::~Play_FireRing()
{
	if (bmring != NULL) { delete[] bmring; bmring = NULL; }
}

void Play_FireRing::Init(int width, int height, float background_max_distance)
{
	this->width = width;
	this->height = height;
	this->background_max_distance = background_max_distance;
	for (int i = 0; i < RING_4; i++)  bmring[i] = BMMger->GetRing((RING)(i));
	distance_unit = width;
	animation_left = 1, animation_right = 2;
	ring_start_x = width * 0.73f;
	ring_x = ring_start_x;
	ring_y = height * 0.3f;
	ring_width = width * 0.07f;
	ring_height = height * 0.14f;
}
//float Play_FireRing::Rand_Distance()
//{
//	return distance_unit = (width *0.5f)%rand() +(width*0.1f);
//
//}
void Play_FireRing::Draw(HDC backDC)
{
	for (int i = 0; i < 10; i++)//10M���� �ϳ��� ���� ���� 
	{
		bmring[animation_left]->Draw(backDC, /*ring_x + (i * distance_unit)*/ 700, ring_y, ring_width, ring_height);
		bmring[animation_right]->Draw(backDC, /*ring_x + (i * distance_unit)*/700, ring_y, ring_width, ring_height);
	}

}

void Play_FireRing::Update(float deltatime, int speed, float distance)
{
	//���� �̵�
	ring_x -= speed * deltatime;

	//�ִϸ��̼� ���� �ð�
	ani_time += deltatime;
	//0.2�� �����ϰ� ���� �ִϸ��̼����� ��ȯ�Ѵ�.
	if (ani_time > 0.2f) { animation_left+=2; animation_right+=2; }
	if (animation_left > 3 && animation_right > 4) { animation_left = 1, animation_right = 2; }

}

