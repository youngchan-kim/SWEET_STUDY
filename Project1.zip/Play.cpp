#include "Play.h"

void Play::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	background.Init(width, height);
	player.Init(width, height);
	object.Init(width, height);
	play_interface.Init(width, height);

}

void Play::Draw(HDC backDC)
{
	background.Draw(backDC);
	player.Draw(backDC);
	//object.Draw(backDC);
}


void Play::Update(float deltatime)
{
	speed = player.Update(deltatime);
	distance = player.Distance();
	background.Update(deltatime, speed);
	object.Update(deltatime, speed);
}



