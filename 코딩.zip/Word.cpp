#include "Word.h"
Word::Word() {};
Word::~Word() {};

int Word::Drop() 
{ 
	Erase(); 
	y++; 
	Draw(); 
	if (y == 28)
	{
		Die();
		return 1;
	}
	return 0;
}
