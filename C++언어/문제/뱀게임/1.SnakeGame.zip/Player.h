#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include "Stone.h"

#define ESC 27



class Player
{
private:

	ofstream save;
	ifstream load;
	string m_strName;
	list<Stone> m_StoneList;
	Position iCursor;
	Position iStoneposition;
	int m_iUndoCount;
	string m_player_cursor;
	string m_player_stone;
	int m_iomokcount;
	bool m_bstonecheck;
	int stonecount;

public:
	inline string PlayerName()
	{
		return m_strName;
	}
	inline int Player::PlayerUndoCount()
	{
		return m_iUndoCount;
	}


	void PlayerSave(string playersavefile);
	void PlayerLoad(string playersavefile);
	void PlayerNameSave(string name);
	void PlayerCursor(string pattern);
	void PlayerStone(string pattern);
	void PlayerReset();
	void PlayerUndoCountDown();
	bool PlayerUndo(Position Cursor);


	void SetPlayerCuser(Position Cursor, int m_iundo);
	void SetPlayer();

	bool StoneListPlayer(int x, int y);

	void OrignStoneDraw(Position iCursor);
	void allStoneDraw();
	void RePlayStoneDraw(int order);
	void StoneDraw(Position Cursor);
	void CursorDraw();

	void ReDraw(int iwidth, int iheight);


	void OMokCountCheck(list<Stone>::iterator iter, int x, int y);
	bool Widthline(int x, int y);
	bool Heightline(int x, int y);
	bool Diagonalline(int x, int y);
	bool OppositeDiagonal(int x, int y);
	string OMok(string win);

	bool GameRole(int m_iwidth, int m_iheight);
	void GameBacking(int m_iwidth, int m_iheight);
	
	Position CursorReTurn();
	string PlayerMove(char ch ,int m_iwidth, int m_iheight);
	

	
	Player();
	~Player();
};

