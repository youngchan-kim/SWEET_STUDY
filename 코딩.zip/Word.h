#pragma once
#include "Mecro.h"
#include "Interface.h"
//�ܾ �����ϴ°�,�ܾ �׸���, ����Ʈ����, �����

//__interface WordInterface
//{
//	void Draw();
//	void Drop();
//	void Die();
//};

class Word// : public WordInterface
{
private:
	Interface mapdraw;

	int x;
	int y;
	std::string str;
	int iWordType;
	bool isDead;


	Word();
public:
	Word(std::string str) : str(str), isDead(true) {}
	~Word();

	bool IsDead() const { return isDead; };
	void SetWord(int x, int iItemType)
	{
		y = 1;
		this->x = x;
		iWordType = iItemType;
		isDead = false;
	}
	void Erase() { mapdraw.EraseText(str, x, y); }
	void Draw();
	int Drop(bool bBlind);
	void Die()  { isDead = true; Erase();}
	std::string GetWord() { return str; }
	void BlindWord() { mapdraw.blandText(str, x, y); }
	int GetWordType() { return iWordType; }
	int GetWordSize() { return str.length(); }
	


};

