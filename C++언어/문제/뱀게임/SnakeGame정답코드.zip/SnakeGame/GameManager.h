#pragma once
#include"ColliderManager.h"
#include"Snake.h"

class GameManager
{
private:
	Snake m_Snake;
public:
	void MainLoop();
	void PlayGame();

	GameManager();
	~GameManager();
};

