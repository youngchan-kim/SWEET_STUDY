#include "Manager.h"


Manager::Manager()
{
	Time_Create_NewCar.SetTimer(TIMER_TYPE_LOOP, TIME_CREATE_NEWCAR);
}
void Manager::PlayLoop()
{
	CarClass NewCar;
	CarList.push_back(NewCar);
	while (true)
	{
		Input();
		CreateCar();
		CarMoveController();
	}
}

void Manager::Input()
{
	if (kbhit()) // �ӵ� ����
	{
		if (getch() == MOVE_FASTMODE)
		{
			for (std::list<CarClass>::iterator iter = CarList.begin(); iter != CarList.end(); iter++)
				(iter)->Set_ModeChange();
		}
	}
}

void Manager::CreateCar()
{
	// ����(list �߰�)
	if (Time_Create_NewCar.CheckTimer()) // ����
	{
		CarClass NewCar;
		CarList.push_back(NewCar);
	}
}


void Manager::CarMoveController()
{
	// �̵�
	std::list<CarClass>::iterator deleteIter = CarList.end();
	for (std::list<CarClass>::iterator iter = CarList.begin(); iter != CarList.end(); iter++)
	{
		if ((iter)->Move_Car() == false)
			deleteIter = iter;
	}
	if(deleteIter != CarList.end())
		CarList.erase(deleteIter);
}