#include "Template.h"
//#include "Template.cpp"
Template::Template() {};



Template::~Template() {};