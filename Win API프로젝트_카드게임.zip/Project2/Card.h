#pragma once
#include"BitMap.h"
#include"BitMapManager.h"
enum CARD
{
	CARD_FRONT,
	CARD_REAR,
	CARD_END,
};

class Card
{
private:
	CARD m_eCardState;
	
	BitMap* m_pBitMap[CARD_END];
	int m_ix;
	int m_iy;
	bool m_bcheck;
	RECT m_BitMapRect;
	IMAGE IMG_index;
public:
	Card();
	void Init(IMAGE Index, int x, int y);
	void Draw(HDC hdc);
	bool ColliderCheck(POINT point);
	void Rear_Card();
	void Input_Check();
	bool Get_Check() { return m_bcheck; }
	IMAGE Get_Imageindex() { return IMG_index; }
	~Card();
};

