#include "Character.h"

Character::Character() {}

void Character::Infomation()
{
	cout << "======" << m_strname << "(" << m_iLv << "Lv)" << "======";
	cout << "���ݷ� = " << m_idamage;
	cout << "������ = " << m_icurhealth << "/" << m_imaxhealth;
	cout << "����ġ = " << m_iexp << "/" << m_imaxexp;
	cout << "GetEXP : " << m_igetexp;
	cout << "Gold = " << m_igold;
}

void Character::NewPlayer(string name)
{
	m_strname = name;
	ifstream load;
	load.open("DefaultPlayer.txt");
	if (!load.eof()) // �ϼ�
	{
		load >> m_idamage;
		load >> m_imaxhealth;
		load >> m_imaxexp;
		load >> m_igetexp;
		load >> m_iLv;
		load >> m_igold;
	}
	load.close();				
	Infomation();
}



Character::~Character() {}