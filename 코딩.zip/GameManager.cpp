#include "GameManager.h"

GameManager::GameManager()
{
	monstermanager.SetMonster();
	shop.Load();
}
void GameManager::OutLine()
{
	system("cls");
	mapdraw.BoxDraw(START_X, START_Y, WIDTH, HEIGHT);
}
void GameManager::MainMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� DonGeonRPG �ڡ�", WIDTH, HEIGHT * 0.4f);
	mapdraw.DrawMidText("New Game", WIDTH, HEIGHT * 0.5f);
	mapdraw.DrawMidText("Load Game", WIDTH, HEIGHT * 0.6f);
	mapdraw.DrawMidText("Game Exit", WIDTH, HEIGHT * 0.7f);

}
void GameManager::GameMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� Menu �ڡ�", WIDTH, HEIGHT * 0.2f);
	mapdraw.DrawMidText("Dongeon", WIDTH, HEIGHT * 0.3f);
	mapdraw.DrawMidText("Player Info", WIDTH, HEIGHT * 0.4f);
	mapdraw.DrawMidText("Monster Info", WIDTH, HEIGHT * 0.5f);
	mapdraw.DrawMidText("Weapon Shop", WIDTH, HEIGHT * 0.6f);
	mapdraw.DrawMidText("Save", WIDTH, HEIGHT * 0.7f);
	mapdraw.DrawMidText("Exit", WIDTH, HEIGHT * 0.8f);

}
void GameManager::DongeonMenu()
{
	OutLine();
	monstermanager.DongeonList(WIDTH, 6);
	mapdraw.DrawMidText("���ư���", WIDTH, 22);
}

void GameManager::PVE(int dongeonnum)
{
	int player_y = 2, monster_y = 24, player_rsp_y = 8;

	string Rock = "Rock" , Paper = "Paper", Scissor = "Scissor";
	string Monsterstate;
	Monster monster = monstermanager.MonsterSelect(dongeonnum, WIDTH, monster_y);
	srand((unsigned)time(NULL));

	while (TRUE)
	{

		player.Infomation(WIDTH, player_y);
		mapdraw.DrawMidText("1.����   2.����   3.��", WIDTH, player_rsp_y);
		mapdraw.DrawMidText("--------------------------vs--------------------------", WIDTH, HEIGHT * 0.5f);
		monster.Infomation(WIDTH, monster_y);

		// 1. ��ư ���� �� ���� ������ ������������ �缳���Ǿߵ� 
		int icom = (rand() % 3) + 1;
		int iselect = _getch() - 48;
		int iresult = iselect - icom;
		
		if (monster.CurrentHealth() <= 0)
		{
			OutLine();
			mapdraw.DrawMidText(player.GetName() + " �¸�!!", WIDTH, HEIGHT_MIDDLE);
			player.GetWinner(monster.Getexp(), monster.Gold());
			mapdraw.DrawMidText(player.GetName() + " �� ����ġ " + to_string(monster.Getexp()) + " ��", WIDTH, HEIGHT_MIDDLE+1);
			mapdraw.DrawMidText(to_string(monster.Gold()) + " Gold�� ������ϴ�.", WIDTH, HEIGHT_MIDDLE + 2);
			_getch();
			return;
		}
		if (player.CurrentHealth() <= 0)
		{
			OutLine();
			mapdraw.DrawMidText(monster.GetName() + " �¸�!!", WIDTH, HEIGHT_MIDDLE);
			mapdraw.DrawMidText(monster.GetName() + "�� ����ġ " + to_string(player.Getexp()) + "�� ������ϴ�.", WIDTH, HEIGHT_MIDDLE + 2);
			_getch();
			return;
		}

		if (0 == iresult)
		{
			string str_allreslut = GetTextRSP(iselect) + "(���º�!!)";
			DrawBattleResult(str_allreslut, str_allreslut);
		}
		else if (iresult == -1 || iresult == 2)
		{

			DrawBattleResult(GetTextRSP(iselect) + "(�¸�!!)  ", GetTextRSP(icom) + "(�й�!!)  ");
			mapdraw.DrawMidText("Damage : " + player.Atteck(), WIDTH, 12);
			monster.Damaged(player.Atteck());
			
			// ����� ���� // ũ��Ƽ�� ����
			
		}
		else
		{
			DrawBattleResult(GetTextRSP(iselect) + "(�й�!!)  ", GetTextRSP(icom) + "(�¸�!!)  ");
			player.Damaged(monster.Atteck());
		}
	}

}
void GameManager::DrawBattleResult(string player, string monster)
{
	int monster_rsp_y = 20, result_rsp_y = 10;
	mapdraw.DrawMidText(player, WIDTH, result_rsp_y);
	mapdraw.DrawMidText(monster, WIDTH, monster_rsp_y);
}


void GameManager::Dongeon()
{
	while (TRUE)
	{
		if (player.CurrentHealth() > 0)
		{
			DongeonMenu();
			int select = mapdraw.MenuSelectCursor(7, 2, WIDTH * 0.2f, 10);
			switch (select)
			{
			default:
				OutLine();
				PVE(select);
			case 7:
				return;
			}
		}
		else
			return;
	}
}
void GameManager::Player_Info()
{
	player.Infomation(WIDTH, HEIGHT *0.5f);
}
void GameManager::Monster_Info()
{
	monstermanager.MonsterList();
}

void GameManager::Weapon_Shop()
{
	shop.ShopMenu(WIDTH, &player); //���� Ÿ���� �ҷ���
}

void GameManager::Save()
{
	while (TRUE)
	{
		OutLine();
		string line[10] = {};
		bool OX;
		int i = 0;
		mapdraw.DrawMidText("SAVE", WIDTH, SUBTITLE_START_Y + (i++ * LIST_SPACE));
		for (i; i <= 10; i++)
		{
			ifstream load;
			OX = false;
			char is_true;
			string playerlist = "SavePlayer" + to_string(i) + ".txt";
			load.open(playerlist);
			if (load.is_open())
			{
				OX = true;
				load.close();
			}
			if (OX == true)
				is_true = 'O';
			else
				is_true = 'X';
			line[i-1] = to_string(i) + "������ : (���Ͽ��� : " + is_true + ")";

			mapdraw.DrawMidText(line[i-1], WIDTH, SUBTITLE_START_Y+(i * LIST_SPACE));
		}
		mapdraw.DrawMidText("11.���ư���", WIDTH, SUBTITLE_START_Y+(i * LIST_SPACE));

		int select = mapdraw.MenuSelectCursor(11, 2, WIDTH * 0.1f, SUBTITLE_START_Y + (LIST_SPACE));
		if (select < 11)
		{
			ofstream save;
			string playerlist = "SavePlayer" + to_string(select) + ".txt";
			save.open(playerlist);
			if (save.is_open())
			{
				player.Save(save);

				save.close();
			}
			OutLine();
			mapdraw.DrawMidText("Save �Ϸ�", WIDTH, HEIGHT * 0.5f);
			_getch();
		}
		else if (select == 11)
			return;
	}
}

void GameManager::Playing()
{
	while (player.CurrentHealth() > 0)
	{
		GameMenu();
		switch (mapdraw.MenuSelectCursor(6, 3, WIDTH * 0.35f, HEIGHT * 0.3f))
		{
		case 1:
			Dongeon();
			break;
		case 2:
			OutLine();
			Player_Info();
			_getch();
			break;
		case 3:
			OutLine();
			Monster_Info();
			_getch();
			break;
		case 4:
			OutLine();
			Weapon_Shop();
			break;
		case 5:
			Save();
			break;
		case 6:
			return;
		}
	}
}

// ����
void GameManager::LoadSlot()
{
	string line[10] = {};
	bool OX;
	int i = 0;

	mapdraw.DrawMidText("LOAD", WIDTH, SUBTITLE_START_Y + (i++ * LIST_SPACE));
	for (i; i <= 10; i++)
	{
		ifstream load;
		OX = false;
		char is_true;
		string playerlist = "SavePlayer" + to_string(i) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			OX = true;
			load.close();
		}
		if (OX == true)
			is_true = 'O';
		else
			is_true = 'X';
		line[i - 1] = to_string(i) + "������ : (���Ͽ��� : " + is_true + ")";

		mapdraw.DrawMidText(line[i - 1], WIDTH, SUBTITLE_START_Y + (i * LIST_SPACE));
	}
	mapdraw.DrawMidText("11.���ư���", WIDTH, SUBTITLE_START_Y + (i * LIST_SPACE));
	
	int select = mapdraw.MenuSelectCursor(11, 2, WIDTH * 0.1f, SUBTITLE_START_Y + (LIST_SPACE));
	if (select < 11)
	{
		ifstream load;
		string playerlist = "SavePlayer" + to_string(select) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			player.Load(load);
			load.close();
		}
		else
		{
			mapdraw.DrawMidText("�ش� ������ �����ϴ�.", WIDTH, HEIGHT * 0.5f);
			system("pause");
		}
	}

}

void GameManager::Start()
{
	string name;
	ifstream load;
	while (TRUE)
	{
		MainMenu();
		int playing = mapdraw.MenuSelectCursor(3, 3, WIDTH * 0.35f, HEIGHT * 0.5f);
		switch (playing)
		{
		case 1:
			OutLine();
			mapdraw.DrawMidText("Player �̸� �Է� : ", WIDTH, HEIGHT * 0.5f);
			cin >> name;
			load.open("DefaultPlayer.txt");
			if (load.is_open())
			{
				player.Load(load, name);
				load.close();
			}
			Playing();
			break;
		case 2:
			OutLine();
			LoadSlot();
			Playing();
			break;
		case 3:
			return;
		default:
			break;
		}
	}
}
GameManager::~GameManager() {}