#include "EndMenuScene.h"
#include "ResourceManager.h"
#include "SceneManager.h"

VOID EndMenuScene::Initialize()
{
	ResourceMgr->Load("background.bmp");
	ResourceMgr->Load("play_normal.bmp");
	ResourceMgr->Load("play_pressed.bmp");
	ResourceMgr->Load("quit_normal.bmp");
	ResourceMgr->Load("quit_pressed.bmp");

	//����(���� �ʺ�)
	bounds = SceneMgr->GetWidth();

	background = ResourceMgr->GetBitmap("background.bmp");
	background->SetDrawSize(bounds, SceneMgr->GetHeight());
	EndWindow=UIMgr->AddUI<UIImage>("EndWindow Canvas");
	EndWindow->Initialize("base_panel.bmp");

	UIButton* playBtn = UIMgr->AddUI<UIButton>("Continue Btn", EndWindow);
	playBtn->Initialize("continue_normal.bmp", "continue_pressed.bmp", "", "", DrawType::Transparent);
	playBtn->SetLocalPosition(EndWindow->GetSize().cx * 0.5f, EndWindow->GetSize().cy * 0.5f - 100, true);
	playBtn->SetListener(std::bind(&DemoScene::ContinueBtnClickHandler, this));

	UIButton* quitBtn = UIMgr->AddUI<UIButton>("Quit Btn", EndWindow);
	quitBtn->Initialize("quit_normal.bmp", "quit_pressed.bmp", "", "", DrawType::Transparent);
	quitBtn->SetLocalPosition(EndWindow->GetSize().cx * 0.5f, EndWindow->GetSize().cy * 0.5f + 50, true);
	quitBtn->SetListener(std::bind(&DemoScene::QuitBtnClickHandler, this));
}

//�÷��� �϶��� �ٲ�����
VOID EndMenuScene::ContinueBtnClickHandler()
{
	pauseWindow->SetEnable(FALSE);
	pauseBtn->SetInteracterble(TRUE);
	isPause = FALSE;
}
//����
VOID EndMenuScene::QuitBtnClickHandler()
{
	//ReSet();
	ENGINE::SceneMgr->LoadScene("MainMenu");
}
VOID EndMenuScene::Release()
{
	return VOID();
}

VOID EndMenuScene::Update(const FLOAT& deltaTime)
{
	return VOID();
}

VOID EndMenuScene::Draw()
{
	return VOID();
}
