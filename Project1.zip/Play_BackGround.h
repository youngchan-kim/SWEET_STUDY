#pragma once
#include "BitMapManager.h"

//BACKGROUND_WIDTH�� ����
//�ʺ�
#define BACKGROUND_WIDTH width
#define GS_WIDTH BACKGROUND_WIDTH*0.125


//����
#define BACKGROUND_HEIGHT height
#define GS_HEIGHT BACKGROUND_HEIGHT*0.1
#define GS_Y BACKGROUND_HEIGHT*0.3
#define T_Y GS_HEIGHT+GS_Y



class Play_BackGround
{
private:
	BitMap** bmback;
	int width, height;
	int x;
public:
	Play_BackGround();
	~Play_BackGround();
	void Init(int width, int height);
	void Draw(HDC backDC);
	void Update(float deltatime);
};

