#include"GuGuDan.h"

void main()
{
	GuGuDan gugudan;
	gugudan.SetGuGuDan(7,8);
	gugudan.ShowGuGuDan();
	gugudan.SetGuGuDan();
	gugudan.ShowGuGuDan();
}