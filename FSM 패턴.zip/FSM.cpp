﻿#include <iostream>
#include "ConsoleUtils.h"
#include "EntityNames.h"
#include "WoodMan.h"

/*
kill enemy by lowering their HP and update EXP then update level.
after level up, go get new weapon.
before HP is 0, go back and get HP back up.
*/

int main()
{
	//Miner miner(ent_Miner_Bob);
	WoodMan wm(ent_Elsa);
	//for (int i = 0; 20 > i; i++)
	//{
	//	miner.Update();

	//	Sleep(1000);
	//}
	for (int i = 0; 20 > i; i++)
	{
		wm.Update();

		Sleep(1000);
	}

	PressAnyKeyToContinue();
}

//유한 상태 기계