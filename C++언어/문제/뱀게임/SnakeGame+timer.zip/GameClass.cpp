#include "GameClass.h"

GameClass::GameClass()
{
	m_iStart_x = 0;
	m_iStart_y = 0;
	m_iWidth = MAXWIDTH_MAXHEIGHT;
	m_iHeight = MAXWIDTH_MAXHEIGHT;
	srand((unsigned)time(NULL));
	m_ch = NULL;
	num = 0;
}

int GameClass::RandomPosition()
{
	int position = (rand() % (MAXWIDTH_MAXHEIGHT-2)) + 1;
	return position;
}

bool GameClass::BarricadeCrash(Position cursor)
{
	for (std::vector<BlockClass>::iterator iter = barricadelist.begin(); iter != barricadelist.end(); iter++)
	{
		if (iter->PositionCheck(cursor) == true)
			return true;
	}
	return false;
}

void GameClass::SetBarricade(BLOCK_TYPE type)
{
	barricadeshape.Shape(type, m_cursor);
	barricadelist.push_back(barricadeshape);
	barricadeshape.ShapeDraw(type, m_cursor);
}

void GameClass::BarricadeList()
{
	for (m_cursor.m_iy = 0; m_cursor.m_iy < m_iHeight; m_cursor.m_iy++)
	{
		m_cursor.m_ix = 0;;
		if (m_cursor.m_iy == 0)
		{
			SetBarricade(BARRICADE);
			for (m_cursor.m_ix = 1; m_cursor.m_ix < m_iWidth - 1; m_cursor.m_ix++)
				SetBarricade(BARRICADE);
			SetBarricade(BARRICADE);

		}
		else if (m_cursor.m_iy == m_iHeight - 1)
		{

			SetBarricade(BARRICADE);
			for (m_cursor.m_ix = 1; m_cursor.m_ix < m_iWidth - 1; m_cursor.m_ix++)
				SetBarricade(BARRICADE);
			SetBarricade(BARRICADE);
		}
		else
		{
			SetBarricade(BARRICADE);
			m_cursor.m_ix = m_iWidth - 1;
			SetBarricade(BARRICADE);
		}
	}
}

bool GameClass::WallCrash(Position cursor)
{
	for (std::vector<BlockClass>::iterator iter = walllist.begin(); iter != walllist.end(); iter++)
	{
		if (iter->PositionCheck(cursor) == true)
			return true;
	}
	return false;
}

void GameClass::SetWall(BLOCK_TYPE type)
{
	wallshape.Shape(type, m_cursor);
	walllist.push_back(wallshape);
	wallshape.ShapeDraw(type, m_cursor);
}

void GameClass::WallList()
{
	for (int i = 0; i < MAXWALLBLOCK; i++)
	{
		bool stop;
		do
		{
			stop = true;
			m_cursor.m_ix = RandomPosition();
			m_cursor.m_iy = RandomPosition();


				if (WallCrash(m_cursor) == true)
				{
					stop = false;
					break;
				}
				if (snack.HeadPositionCheck(m_cursor) == true)
				{
					stop = false;
					break;
				}
		} while (stop == false);
		SetWall(WALL);
	}
}

bool GameClass::ItemSearch(Position cursor)
{
	for (std::list<BlockClass>::iterator iter = itemlist.begin(); iter != itemlist.end(); iter++)
	{
		if (iter->PositionCheck(cursor) == true)
		return true;
	}
	return false;
}

std::list<BlockClass>::iterator GameClass::ItemSearch()
{
	for (std::list<BlockClass>::iterator iter = itemlist.begin(); iter != itemlist.end(); iter++)
	{
		if (iter->PositionCheck(snack.SnackPosition()) == true)
				return iter;
	}
	return itemlist.end();
}
//�̷���� �����ε��� �Ҳ�

void GameClass::ItemReMove()
{
	std::list<BlockClass>::iterator itemiter = ItemSearch();
	if (itemiter != itemlist.end())
	{
		itemlist.erase(itemiter);
		m_iitemcout--;
	}
}

void GameClass::SetItem()
{
	if (m_iitemcout < MAXITEMBLOCK)
	{
		bool stop;
		do
		{
			stop = true;
			m_cursor.m_ix = RandomPosition();
			m_cursor.m_iy = RandomPosition();

			if (BarricadeCrash(m_cursor) == true || WallCrash(m_cursor) == true || ItemSearch(m_cursor) == true || snack.HeadPositionCheck(m_cursor) == true || snack.TeilPositionCheck(m_cursor) == true)
			{
				stop = false;
			}
		} while (stop == false);
		itemshape.Shape(ITEM, m_cursor);
		itemlist.push_back(itemshape);
		itemshape.ShapeDraw(ITEM, m_cursor);
		m_iitemcout++;
	}
}

void GameClass::SetItemtTme()
{
	//timer.SetTimer(TIMER_TYPE::TIMER_TYPE_LOOP, ITEMTIME, bind(&GameClass::SetItem, this)); // std::bind�� ���� ���� namespace�� ���� ����
	timer.SetTimer(TIMER_TYPE::TIMER_TYPE_LOOP, ITEMTIME, std::bind(&GameClass::SetItem, this));
}
void GameClass::ItemTimeCheck()
{
	timer.CheckTimer();
}


void GameClass::Map_Interface()
{
	score = "Score : " + std::to_string(snack.Score());
	MapDraw::DrawMidText(score, m_iWidth, m_iHeight + 1);
}

void GameClass::GameEnd()
{
	system("cls");
	char space_bar = NULL;
	Map_Interface();
	BarricadeList();
	MapDraw::DrawMidText("�� �� �� Game Over �� �� ��", m_iWidth, m_iHeight * 0.4f);
	MapDraw::DrawMidText("Continue : Space Bar", m_iWidth, m_iHeight * 0.6f);
	snack.END();
	itemlist.clear();
	walllist.clear();
	while(TRUE)
	{
		space_bar = getch();
		if (space_bar == SPACE_BAR)
			return;
	}
}

void GameClass::Game()
{
	system("cls");
	Map_Interface();
	bool add;
	m_ch = NULL;
	m_iitemcout = 0;
	m_cursor.m_ix = MAXWIDTH_MAXHEIGHT * 0.5f;
	m_cursor.m_iy = MAXWIDTH_MAXHEIGHT * 0.5f;
	snack.SetHead(m_cursor);
	BarricadeList();
	WallList();
	SetItemtTme();
	snack.SetSnackTime();
	while (TRUE)
	{
		//m_iitemtime = clock();

		ItemTimeCheck();

		if (BarricadeCrash(snack.SnackPosition()) == true || WallCrash(snack.SnackPosition()) == true || snack.HeadTeilCrush() == true)
		{
 			GameEnd();
			return;
		}
		if (ItemSearch(snack.SnackPosition()) == true)
		{
 			ItemReMove();
			snack.Add_Teil();
			Map_Interface();
		}
		if (kbhit())
		{
			m_ch = getch();
			snack.Head_MoveArray(m_ch);
		}
		snack.SnackTimeCheck();
	}
}

void GameClass::Menu()
{
	while (TRUE)
	{
		system("cls");
		int select;
		Map_Interface();
		BarricadeList();
		MapDraw::DrawMidText("�� �� �� Snake Game �� �� ��", m_iWidth, m_iHeight * 0.3f);
		MapDraw::DrawMidText("1.���� ����", m_iWidth, m_iHeight * 0.4f);
		MapDraw::DrawMidText("2.���� ����", m_iWidth, m_iHeight * 0.5f);
		MapDraw::DrawMidText("���� : ", m_iWidth, m_iHeight * 0.6f);

		std::cin >> select;
		switch (select)
		{
		case 1:
			Game();
			break;
		case 2:
			return;
		default:
			break;
		}
	}
}

GameClass::~GameClass()
{
}