#include"Manager.h"

void main()
{
	Manager manager;
	manager.List();
}