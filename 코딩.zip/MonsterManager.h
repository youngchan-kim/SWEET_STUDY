#pragma once
#include "Monster.h"
#include <vector>

class MonsterManager:public Monster
{
private:
	vector<Monster> monsterlist;
	Monster* selectMon;
public:
	MonsterManager();
	inline int Atteck() { return selectMon->Atteck(); };
	void SetMonster();
	void MonsterList();
	void DongeonList(int x, int y);
	void MonsterSelect(int dongeonnum, int x, int y);
	void Curhealth(int tookdamage);
	void Relese();
	~MonsterManager();
};

