#pragma once
#include<iostream>
using namespace std;
#define MAX 5

class Quiz03
{
public:
	void Print(int iarr[], int len);
	void CharPrint(int iarr[], int len);
	void Swap(int iarr[], int low, int high);
	void Asce(int iarr[], int left, int right);
	void Desc(int iarr[], int left, int right);
	void Quiz3(int num01, int num02, int num03, int num04, int num05);
	void Quiz3(char char01, char char02, char char03, char char04, char char05);
	Quiz03();
	~Quiz03();
};

