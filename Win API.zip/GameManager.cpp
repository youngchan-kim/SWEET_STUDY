#include "GameManager.h"

GameManager* GameManager::m_pInstance = NULL;


void GameManager::MenuPage()
{
}

