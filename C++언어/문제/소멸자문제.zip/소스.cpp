#include"Manager.h"

void main()
{
	Manager Manager;
}

