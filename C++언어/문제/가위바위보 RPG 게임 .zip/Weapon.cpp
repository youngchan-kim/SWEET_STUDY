#include "Weapon.h"

Weapon::Weapon(){}

void Weapon::Load(ifstream& load)
{
	load >> m_strname; // ���� ������?
	load >> m_idamage;
	load >> m_iprice;
}

void Weapon::Save(ofstream& save)
{
	save << m_strweapontype << " ";
	save << m_strname << " ";
	save << m_idamage << " ";
	save << m_iprice << endl;
}

Weapon::~Weapon() {}


Bow::Bow() { m_strweapontype = "Bow"; }
float Bow::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 11)
	{
		all_damage = (playerdamage + m_idamage) * 10;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;
	return all_damage;
}
void Bow::Critical(int playerdamage, int x, int y)
{
	string line1 = "��弦!!(Damage : " + to_string((playerdamage + m_idamage) * 10) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Bow::~Bow() {}


Dagger::Dagger() { m_strweapontype = "Dagger"; }
float Dagger::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (1/*Chance < 21*/)
	{
		all_damage = (playerdamage + m_idamage) * 5 * 2;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;
	return all_damage;
}
void Dagger::Critical(int playerdamage, int x, int y)
{
	string line1 = "ũ��Ƽ�ü�!!(Damage : " + to_string((playerdamage + m_idamage) * 5) + ") x 2ȸ ���� (�� ������ : " + to_string((playerdamage + m_idamage) * 5 * 2) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Dagger::~Dagger() {}


Gun::Gun() { m_strweapontype = "Gun"; }
float Gun::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 51)
	{
		all_damage = (playerdamage + m_idamage) * 2;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;
	return all_damage;
}
void Gun::Critical(int playerdamage, int x, int y)
{
	string line1 = "��弦!!(Damage : " + to_string((playerdamage + m_idamage) * 2) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Gun::~Gun() {}


Sword::Sword() { m_strweapontype = "Sword"; }
float Sword::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 31)
	{
		all_damage = (playerdamage + m_idamage) * 1.5 * 3;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;
	return all_damage;
}
void Sword::Critical(int playerdamage, int x, int y)
{
	string line1 = "�˱�!!(Damage : " + to_string((playerdamage + m_idamage) * 1.5) + ") x 3ȸ ���� (�� ������ : " + to_string((playerdamage + m_idamage) * 1.5 * 3) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Sword::~Sword() {}


Wand::Wand() { m_strweapontype = "Wand"; }
float Wand::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 6)
	{
		all_damage = (playerdamage + m_idamage) * 1000;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;

	return all_damage;
}
void Wand::Critical(int playerdamage, int x, int y)
{
	string line1 = "��弦!!(Damage : " + to_string((playerdamage + m_idamage) * 1000) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Wand::~Wand() {}


Hammer::Hammer() { m_strweapontype = "Hammer"; }
float Hammer::Atteck(float playerdamage, int x, int y)
{
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance > 51)
	{
		all_damage = (playerdamage + m_idamage) * 1.2;
		Critical(playerdamage, x, y);
	}
	else
		all_damage = playerdamage + m_idamage;

	return all_damage;
}
void Hammer::Critical(int playerdamage, int x, int y)
{
	string line1 = "��弦!!(Damage : " + to_string((playerdamage + m_idamage) * 1.2) + ")";
	mapdraw.DrawMidText(line1, x, y);
}
Hammer::~Hammer() {}
