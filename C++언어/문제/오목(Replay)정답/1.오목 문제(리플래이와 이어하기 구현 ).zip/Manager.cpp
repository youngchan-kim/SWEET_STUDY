#include "Manager.h"

Manager::Manager()
{
	Player1.PlayerCursor("��");
	Player2.PlayerCursor("��");
	Player1.PlayerStone("��");
	Player2.PlayerStone("��");

	start_x = NULL;
	start_y = NULL;
	m_iwidth = NOMALLSIZE;
	m_iheight = NOMALLSIZE;
	m_iundo = NOMALLUNDO;
	m_igameturn = 1;
	state = "move";
	win = false;
	savefile = false;
}

void Manager::PlayerBacking(Position Cursor, Player *me, Player *opponent)
{
	bool canundo;
	me->PlayerUndoCountDown();
	canundo = opponent->PlayerUndo(Cursor);
	Cursor = opponent->CursorReTurn();
	if (canundo == true)
		m_igameturn--;
}
void Manager::OMokSave()
{
	string playersavefile;
	savefile = true;

	playersavefile = "Player1.txt";
	Player1.PlayerSave(playersavefile);

	playersavefile = "Player2.txt";
	Player2.PlayerSave(playersavefile);
	save.open("Omok.txt");
	if (save.is_open()) // �ϼ� 
	{					
		save << m_igameturn << endl;
		save << win << endl;
		save << savefile;
	}
	save.close();
}

void Manager::OMokLoad()
{
	string playersavefile;
	playersavefile = "Player1.txt";
	Player1.PlayerLoad(playersavefile);
	playersavefile = "Player2.txt";
	Player2.PlayerLoad(playersavefile);
	load.open("Omok.txt");
	if (!load.eof()) // �ϼ�
	{					
		load >> m_igameturn;
		load >> win;
		load >> savefile;
	}
	load.close();
}
void Manager::RePlaySave()
{
	string playersavefile;
	savefile = true;

	playersavefile = "Player1Replay.txt";
	Player1.PlayerSave(playersavefile);

	playersavefile = "Player2Replay.txt";
	Player2.PlayerSave(playersavefile);
	save.open("OmokReplay.txt");
	if (save.is_open()) // �ϼ� 
	{
		save << m_igameturn << endl;
		save << win << endl;
		save << savefile;
	}
	save.close();
}
void Manager::RePlayLoad()
{
	string playersavefile;
	playersavefile = "Player1Replay.txt";
	Player1.PlayerLoad(playersavefile);
	playersavefile = "Player2Replay.txt";
	Player2.PlayerLoad(playersavefile);
	load.open("OmokReplay.txt");
	if (!load.eof()) // �ϼ�
	{
		load >> m_igameturn;
		load >> win;
		load >> savefile;
	}
	load.close();
}


bool Manager::GamePlayer(Player *me, Player *opponent)
{
	string playerturn = "nextplayer";
	bool pass;
	char ch;
	while (TRUE)
	{

		GameTurn(); // ���� �����
		me->GameBacking(m_iwidth, m_iheight); //������ �����
		me->CursorDraw(); //Ŀ�� �׸���
		while (TRUE)
		{
			ch = getch();
			me->ReDraw(m_iwidth, m_iheight);
			opponent->OrignStoneDraw(Cursor);
			state = me->PlayerMove(ch ,m_iwidth, m_iheight);
			Cursor = me->CursorReTurn();

			if (state == "ENTER")
			{
				if ((me->StoneListPlayer(Cursor.m_ix, Cursor.m_iy) == true) || (opponent->StoneListPlayer(Cursor.m_ix, Cursor.m_iy) == true))
					playerturn = "stay";
				else
				{
					me->StoneDraw(Cursor);
					me->SetPlayer();
					pass = me->GameRole(m_iwidth, m_iheight);

					if (pass == false)
					{
						m_igameturn++;
						state = "playing";
						win = false;
					}
					else if (pass == true)
					{
						getch();
						win = true;
						RePlaySave();
						return "end";
					}
					playerturn = "nextplayer";
					break;
				}
			}
			else if (state == "Backing")
			{
				if (m_igameturn > 1)
				{
					if (m_igameturn % 2 != 0)
					{
						PlayerBacking(Cursor, me, opponent);
					}
					else
					{
						PlayerBacking(Cursor, me, opponent);
					}
				}
				playerturn = "nextplayer";
				break;
			}
			else if (state == "option")
			{
				state = "option";
				Option();
				GameState();
				me->allStoneDraw();
				opponent->allStoneDraw();
				playerturn = "stay";
				break;
			}
			else if (state == "end")
			{
				playerturn = "end";
				break;
			}
		}
		if (playerturn == "nextplayer")
			return false;
		else if (playerturn == "end")
			return true;
	}
}

void Manager::FirstPage()
{
	int undo;
	bool game_end;
	int num = NULL;
	while (TRUE)
	{
		m_igameturn = STARTTURN;
		MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
		MapDraw::DrawMidText("�� �� �� ��", m_iwidth, m_iheight * 0.1f);
		MapDraw::DrawMidText("1.���� ����", m_iwidth, m_iheight * 0.2f);
		MapDraw::DrawMidText("2.�̾� �ϱ�", m_iwidth, m_iheight * 0.3f);
		MapDraw::DrawMidText("3.���÷���", m_iwidth, m_iheight * 0.4f);
		MapDraw::DrawMidText("4.�ɼ� ����", m_iwidth, m_iheight * 0.5f);
		MapDraw::DrawMidText("5.���� ����", m_iwidth, m_iheight * 0.6f);
		MapDraw::SmallBoxDraw(m_iwidth * 0.7f, m_iheight * 0.7f, m_iwidth * 0.6f, 3);
		MapDraw::gotoxy(m_iwidth, m_iheight * 0.75f);
		cin >> num;
		switch (num)
		{
		case 1:
			GameSet();
			while (TRUE)
			{
				if (m_igameturn % 2 != 0)
					game_end = GamePlayer(&Player1, &Player2);
				else
					game_end = GamePlayer(&Player2, &Player1);
				if (game_end == true)
				{
					OMokSave();

					Player1.PlayerReset();
					Player2.PlayerReset();
					system("cls");
					break;
				}
			}
			break;
		case 2:
			OMokLoad();//�ҷ�����
			if (savefile == true)
			{
				if (win == false)
				{
					GameState();
					Player1.allStoneDraw();
					Player2.allStoneDraw();
					while (TRUE)
					{
						if (m_igameturn % 2 != 0)
							game_end = GamePlayer(&Player1, &Player2);
						else
							game_end = GamePlayer(&Player2, &Player1);
						if (game_end == true)
						{
							OMokSave();
							Player1.PlayerReset();
							Player2.PlayerReset();
							system("cls");
							break;
						}
					}
				}
				else
				{
					MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
					MapDraw::DrawMidText("���а� ������ �����Դϴ�.", m_iwidth, m_iheight * 0.4f);
					MapDraw::DrawMidText("���÷��̸� Ȯ�����ּ���.", m_iwidth, m_iheight * 0.6f);
					getch();
				}
			}
			else
			{
				MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
				MapDraw::DrawMidText("save ������ �����ϴ�.", m_iwidth, m_iheight * 0.5f);
				getch();
			}
			break;
		case 3:
			RePlayLoad();//���÷���

			if (savefile == true)
			{
				if (win == true)
				{
					int player1order = 0;
					int player2order = 0;
					GameState();
					for (int replayturn = 1; replayturn <= m_igameturn; replayturn++)
					{
						RePlayTurn(replayturn);
						if (replayturn % 2 != 0)
						{
							Player1.GameBacking(m_iwidth, m_iheight); //������ �����
							Player1.RePlayStoneDraw(player1order);
							player1order++;
						}
						else
						{
							Player2.GameBacking(m_iwidth, m_iheight); //������ �����
							Player2.RePlayStoneDraw(player2order);
							player2order++;
						}
						Sleep(200);
					}
					Player1.PlayerReset();
					Player2.PlayerReset();
				}
				else
				{
					MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
					MapDraw::DrawMidText("���а� ������ ������ �����ϴ�.", m_iwidth, m_iheight * 0.5f);
				}
			}
			else
			{
				MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
				MapDraw::DrawMidText("save ������ �����ϴ�.", m_iwidth, m_iheight * 0.5f);
			}
			getch();
			break;
		case 4:
			state = "move";
			Option();
			break;
		case 5:
			return;
		}
	}
}

void Manager::Option()
{
	while (TRUE)
	{
		int num = 0;
		system("cls");
		MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
		MapDraw::DrawMidText("= Option =", m_iwidth, m_iheight * 0.2f);
		MapDraw::DrawMidText("1.Map Size Set", m_iwidth, m_iheight * 0.3f);
		MapDraw::DrawMidText("2.Cursor Custom", m_iwidth, m_iheight * 0.4f);
		MapDraw::DrawMidText("3.Stone Custom", m_iwidth, m_iheight * 0.5f);
		MapDraw::DrawMidText("4.Undo Count Set", m_iwidth, m_iheight * 0.6f);
		MapDraw::DrawMidText("5.Return", m_iwidth, m_iheight * 0.7f);
		MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.8f);

		cin >> num;
		switch (num)
		{
		case 1:
			OptionMapSizeSet();
			break;
		case 2:
			OptionSetCursor();
			break;
		case 3:
			OptionSetStone();
			break;
		case 4:
			OptionSetUndo();
			break;
		case 5:
			return;
		}
	}
}

void Manager::OptionMapSizeSet( )
{
	int width = 0, height = 0;
	MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
	if (state != "option")
	{
		while ((width < 20) || (width > 90) || (height < 20) || (height > 45))
		{

			MapDraw::DrawMidText("Width : ", m_iwidth, m_iheight * 0.3f);
			cin >> width;
			MapDraw::DrawMidText("Height : ", m_iwidth, m_iheight * 0.6f);
			cin >> height;
			if ((width < 20) || (width > 90) || (height < 20) || (height > 45))
			{
				MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
				MapDraw::DrawMidText("���� �Ұ���", m_iwidth, m_iheight * 0.4f);
				MapDraw::DrawMidText("(���� : 20 ~ 90, ���� : 20 ~ 45)", m_iwidth, m_iheight * 0.6f);
				getch();
			}

		}
		m_iwidth = width;
		m_iheight = height;
	}
	else
	{
		MapDraw::DrawMidText("**���� ������**", m_iwidth, m_iheight * 0.5f);
		getch();
	}

}

void Manager::OptionSetCursor()
{
	int num = 0;
	system("cls");
	MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
	MapDraw::DrawMidText("= Set Cursor =", m_iwidth, m_iheight * 0.2f);
	MapDraw::DrawMidText("1.��,��", m_iwidth, m_iheight * 0.3f);
	MapDraw::DrawMidText("2.��,��", m_iwidth, m_iheight * 0.4f);
	MapDraw::DrawMidText("3.��,��", m_iwidth, m_iheight * 0.5f);
	MapDraw::DrawMidText("4.��,��", m_iwidth, m_iheight * 0.6f);
	MapDraw::DrawMidText("5.Return", m_iwidth, m_iheight * 0.7f);
	MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.8f);
	cin >> num;
	switch (num)
	{
	case 1:
		Player1.PlayerCursor("��");
		Player2.PlayerCursor("��");
		break;
	case 2:
		Player1.PlayerCursor("��");
		Player2.PlayerCursor("��");
		break;
	case 3:
		Player1.PlayerCursor("��");
		Player2.PlayerCursor("��");
		break;
	case 4:
		Player1.PlayerCursor("��");
		Player2.PlayerCursor("��");
		break;
	case 5:
		return;
	}
	system("pause");
}

void Manager::OptionSetStone()
{
	int num = 0;
	system("cls");
	MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
	MapDraw::DrawMidText("= Set Stone =", m_iwidth, m_iheight * 0.2f);
	MapDraw::DrawMidText("1.��,��", m_iwidth, m_iheight * 0.3f);
	MapDraw::DrawMidText("2.��,��", m_iwidth, m_iheight * 0.4f);
	MapDraw::DrawMidText("3.��,��", m_iwidth, m_iheight * 0.5f);
	MapDraw::DrawMidText("4.��,��", m_iwidth, m_iheight * 0.6f);
	MapDraw::DrawMidText("5.Return", m_iwidth, m_iheight * 0.7f);
	MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.8f);
	cin >> num;
	switch (num)
	{
	case 1:
		Player1.PlayerStone("��");
		Player2.PlayerStone("��");
		break;
	case 2:
		Player1.PlayerStone("��");
		Player2.PlayerStone("��");
		break;
	case 3:
		Player1.PlayerStone("��");
		Player2.PlayerStone("��");
		break;
	case 4:
		Player1.PlayerStone("��");
		Player2.PlayerStone("��");
		break;
	case 5:
		return;
	}
	system("pause");
}

void Manager::OptionSetUndo( )
{
	int num = 0;
	int undocount = -1;
	system("cls");
	MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
	if (state != "option")
	{
		MapDraw::DrawMidText("= Set Undo =", m_iwidth, m_iheight * 0.2f);
		MapDraw::DrawMidText("1.Set Undo Count", m_iwidth, m_iheight * 0.3f);
		MapDraw::DrawMidText("2.Undo Off", m_iwidth, m_iheight * 0.4f);
		MapDraw::DrawMidText("3.Return", m_iwidth, m_iheight * 0.5f);
		MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.6f);
		cin >> num;
		switch (num)
		{
		case 1:
			while ((undocount < 0) || (undocount > 10))
			{
				MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
				MapDraw::DrawMidText("������ Ƚ�� �Է�(�ִ� 10ȸ) :", m_iwidth, m_iheight * 0.5f);
				cin >> undocount;
				if ((undocount < 0) || (undocount > 10))
				{
					MapDraw::DrawMidText("������ ���� �ʽ��ϴ� ( 0 ~ 10 )", m_iwidth, m_iheight * 0.5f);
					getch();
				}
			}
			m_iundo = undocount;
			break;
		case 2:
			MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
			MapDraw::DrawMidText("������ off", m_iwidth, m_iheight * 0.5f);
			m_iundo = 0;
			getch();
			break;
		case 3:
			return;
		}
	}
	else
	{
		MapDraw::DrawMidText("**���� ������**", m_iwidth, m_iheight * 0.5f);
		getch();
	}
}

void Manager::GameSet()
{

	string player1name, player2name;
	system("cls");
	MapDraw::BoxDraw(start_x, start_y, m_iwidth, m_iheight);
	MapDraw::DrawMidText("P1 �̸�", m_iwidth, m_iheight * 0.3f);
	MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.4f);
	cin >> player1name;
	Player1.PlayerNameSave(player1name);
	MapDraw::DrawMidText("P2 �̸�", m_iwidth, m_iheight * 0.6f);
	MapDraw::DrawMidText("�Է� :", m_iwidth, m_iheight * 0.7f);
	cin >> player2name;
	Player2.PlayerNameSave(player2name);
	Cursor.m_ix = m_iwidth * 0.5f;
	Cursor.m_iy = m_iheight * 0.5f;
	Player1.SetPlayerCuser(Cursor, m_iundo);
	Player2.SetPlayerCuser(Cursor, m_iundo);
	GameState();
	save.open("Omok.txt", ios::app);
	if (save.is_open())
	{
		save << player1name;
		save << player2name;
		save << Cursor.m_ix, " ", Cursor.m_iy, m_iundo;
		save << Cursor.m_ix, " ", Cursor.m_iy, m_iundo;
		save << m_igameturn;
		save.close();
	}
}

void Manager::GameState()
{
	MapDraw::OmokBoxDraw(start_x, start_y, m_iwidth, m_iheight);
	MapDraw::DrawMidText("====����Ű====", m_iwidth, m_iheight);
	MapDraw::DrawMidText("�̵� : A,S,W,D ������ : ENTER", m_iwidth, m_iheight * 1.05f);
	MapDraw::DrawMidText("������ : N �ɼ� : P ���� : ESC", m_iwidth, m_iheight * 1.1f);
}
void Manager::GameTurn()
{
	MapDraw::DrawMidText("Player Name : ", m_iwidth * 0.1f, m_iheight * 1.15f);

	if (m_igameturn % 2 != 0)
		cout << Player1.PlayerName();
	else
		cout << Player2.PlayerName();
	MapDraw::DrawMidText("Turn : ", m_iwidth, m_iheight * 1.2f);
	cout << m_igameturn;
}

void Manager::RePlayTurn(int replayturn)
{
	MapDraw::DrawMidText("Player Name : ", m_iwidth * 0.1f, m_iheight * 1.15f);

	if (m_igameturn % 2 != 0)
		cout << Player1.PlayerName();
	else
		cout << Player2.PlayerName();
	MapDraw::DrawMidText("Turn : ", m_iwidth, m_iheight * 1.2f);
	cout << replayturn;
}
Manager::~Manager()
{

}