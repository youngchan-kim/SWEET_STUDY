#include"Mecro.h"
#include"GameClass.h"

void main()
{
	GameClass gameclass;
	gameclass.Menu();
}