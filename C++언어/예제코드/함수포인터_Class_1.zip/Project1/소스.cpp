#include"Character.h"



void main()
{
	Character character;
	character.HitbyAnimation();
	character.HitbyAnimation();
	character.HitbyAnimation();
	character.AttackAnimation();
	character.BuffAnimation();
	character.AttackAnimation();
	
	return;
}
