#include "Play.h"

Play::Play()
{
	bmback = new BitMap *[BACK_4];
}

Play::~Play()
{
	if (bmback != NULL) { delete[] bmback; bmback = NULL; }
}

void Play::Init()
{
	for (int i = 0; i < BACK_4; i++)  bmback[i] = BMMger->GetBack((BACK)(i)); 
}

void Play::Draw(HDC backDC)
{
	bmback[0]->Draw(backDC, 0, 500, 800, 400);
}

void Play::Update(float deltatime)
{
}
