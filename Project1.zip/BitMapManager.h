#pragma once
#include "BitMap.h"
#include <vector>

#define BMMger BitMapManager::GetInstance()

enum TITLE
{
	TITLE_1 = 1,
	TITLE_2,
	TITLE_3,
	TITLE_4
};

enum MENU
{
	MENU_1 = 1,
	MENU_2,
	MENU_3,
	MENU_4,
	MENU_5
};

enum GAMEINTERFACE
{
	INTERFACE_1 = 1,
	INTERFACE_2,
	INTERFACE_3
};

enum PLAYER
{
	PLAYER_1 = 1,
	PLAYER_2,
	PLAYER_3,
	PLAYER_4,
	PLAYER_5,
	PLAYER_6
};

enum RING
{
	RING_1 = 1,
	RING_2,
	RING_3,
	RING_4
};

enum FIRE
{
	FIRE_1 = 1,
	FIRE_2
};

enum BACK
{
	BACK_1 = 1,
	BACK_2,
	BACK_3,
	BACK_4
};

enum OTHEROBJECT
{
	OTHEROBJECT_1 = 1,
	OTHEROBJECT_2,
	OTHEROBJECT_3,
	OTHEROBJECT_4
};

class BitMapManager
{
private:
	static BitMapManager* p_mBMMInstance;
	BitMap* m_pBMTitle,*m_pBMMenu, *m_pBMGameInterface,* m_pBMPlayer;
	BitMap* m_pBMRing, *m_pBMFire,* m_pBMBack, *m_pBMObject;

public:
	static BitMapManager* GetInstance()
	{
		if (p_mBMMInstance == NULL)
			p_mBMMInstance = new BitMapManager;
		return p_mBMMInstance;
	}
	BitMap* GetTitle(TITLE index) { return &m_pBMTitle[index]; }
	BitMap* GetMENU(MENU index) { return &m_pBMTitle[index]; }
	BitMap* GetGAMEINTERFACE(GAMEINTERFACE index) { return &m_pBMGameInterface[index]; }
	BitMap* GetPLAYER(PLAYER index) { return &m_pBMPlayer[index]; }
	BitMap* GetRING(RING index) { return &m_pBMRing[index]; }
	BitMap* GetFIRE(FIRE index) { return &m_pBMFire[index]; }
	BitMap* GetBACK(BACK index) { return &m_pBMBack[index]; }
	BitMap* GetOTHEROBJECT(OTHEROBJECT index) { return &m_pBMObject[index]; }

	BitMapManager();
	void Init(HWND hWnd);
	void BackGround(HDC hdc);
	~BitMapManager();

};

