#include "Play.h"

Play::Play()
{
	bmback = new BitMap *[BACK_4];
	bminterface = new BitMap * [INTERFACE_3];
	bmplayer = new BitMap * [PLAYER_6];
	bmobject = new BitMap * [OTHEROBJECT_4];
}

Play::~Play()
{
	if (bmback != NULL) { delete[] bmback; bmback = NULL; }
	if (bminterface != NULL) { delete[] bminterface; bminterface = NULL; }
	if (bmplayer != NULL) { delete[] bmplayer; bmplayer = NULL; }
	if (bmobject != NULL) { delete[] bmobject; bmobject = NULL; }
}

void Play::Init(int width, int height)
{
	this->width = width;
	this->height = height;


	for (int i = 0; i < BACK_4; i++)  bmback[i] = BMMger->GetBack((BACK)(i)); 
	for (int i = 0; i < INTERFACE_3; i++)  bminterface[i] = BMMger->GetGameInterface((GAMEINTERFACE)(i));
	for (int i = 0; i < OTHEROBJECT_4; i++)  bmobject[i] = BMMger->GetOtherObject((OTHEROBJECT)(i));

	background_x = 0;
	goal_x = GOAL_POSITION;
	bonustime = 0, ibonus = 100000, iscore = 0;
}
void Play::BackGround(HDC backDC, int x, int m)
{
	//��� �ɸ��Ͱ� �޸��� ��
	bmback[0]->Draw(backDC, 0, 250, PLAYER_LOAD_WIDTH, 350);

	//��� ���߰� �ڳ���;
	int k = 2, j = 5;
	if (m > 105 * 21)
		m = 0;
	if(m == 0)
	for (int i = 0; i < 21; i++,j++)
	{
		if (j == 7){ k = 1; j = 0; }
		else k = 2;

		bmback[k]->Draw(backDC, x, 160, BACKGROUND_ONE_PICE_WIDTH, 90);
		x += 105;
		m += 105;
	}
}
void Play::Goal(HDC backDC)
{
	bmobject[1]->Draw(backDC, goal_x, 500, GOAL_WIDTH, GOAL_HEIGHT);
}

//void Play::Interface(HDC backDC)
//{
//	char chscore[256], chbonus[256];
//	bminterface[0]->Draw(backDC, 120, 20, INTERFACE_TOP_WIDTH, 100);
//
//	RECT score_rect = { 100, 100, 400, 300 };
//	RECT bonus_rect = { 500, 100, 400, 300 };
//
//	sprintf_s(chscore, "Scoure : %d", iscore);
//	sprintf_s(chbonus, "Bonus : %d", ibonus);
//	DrawTextA(backDC, chscore, -1, &score_rect, DT_LEFT | DT_VCENTER);
//	DrawTextA(backDC, chbonus, -1, &score_rect, DT_LEFT |DT_VCENTER);
//}

void Play::Bonus(float deltatime)
{
	if (bonustime < 100000)
	{
		bonustime += deltatime;
		ibonus -= bonustime;
	}
	else ibonus = 0;
}


void Play::Draw(HDC backDC)
{
	int x = background_x;
	int m = 0;
	BackGround(backDC, x, m);
	//Interface(backDC);
	Goal(backDC);
}


void Play::Update(float deltatime)
{
	Bonus(deltatime);

	if (GetAsyncKeyState(VK_LEFT))
	{
		background_x += 10;
		goal_x -= 10;
		
		//if (background_x >= 0) { background_x = 0; }
	}

	else if (GetAsyncKeyState(VK_RIGHT))
	{
		total_x += 10;
		background_x -= 10;
		goal_x += 10;
		//if (total_x >= 1000) { total_x = 1000;}
	}
	else if (GetAsyncKeyState(VK_SPACE))
	{
		player_y;
	}

	//if (total_x <= 9000) { background_x -= 10; }
	//else { player_x = (total_x - 9000); }
	

}

