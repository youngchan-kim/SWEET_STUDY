#include "Play.h"
Play::Play() { srand((unsigned int)time(NULL)); }

void Play::Clearmap()
{
	BLUE_GREEN
	system("cls");
	mapdraw.BoxDraw(START_X, START_Y, MAX_X, MAX_Y);
	ORIGINAL
}

void Play::Setting()
{

	iLife = 9;
	iScore = 0;
	strLife = '��';
	name = "?\t?\t?";
	for (int i = 0; i < 9; i++)
	{
		strCurLife += strLife;
	}
	//��� ������ ���� ��Ʈ ���� �Լ� �����
}
void Play::MainMenu()
{
	char nickname[MAX_LENGTH];
	Clearmap();
	Setting();
	BLUE_GREEN
	mapdraw.DrawMidText("�� �� �� �� ġ �� �� ��", MAX_X, MIDDLE_Y / 2);
	mapdraw.DrawMidText("1.Game Start", MAX_X, MIDDLE_Y);
	mapdraw.DrawMidText("2.Rank", MAX_X, MIDDLE_Y + 2);
	mapdraw.DrawMidText("3.Exit", MAX_X, MIDDLE_Y + 4);
	ORIGINAL

	switch (mapdraw.MenuSelectCursor(3, 3, CURSOR_X, MIDDLE_Y))
	{
	case 1:
		GamePlay();
		break;
	case 2:

		break;
	case 3:
		return;

	}
}

bool Play::InputStr(std::string& str, int maxcount)
{
	char iKey;
	if (_kbhit())
	{
		iKey = _getch();
		if ((iKey == KEY_ENTER) || (iKey == KEY_BACKSPACE) || ((iKey >= 'a') && (iKey <= 'z')))
		{
			switch (iKey)
			{
			case KEY_ENTER:
				if (!str.empty()) return true;
				break;
			case KEY_BACKSPACE:
				str = str.substr(0, str.length() - 1);
				break;
			default:
				if (str.length() >= maxcount)
				{
					mapdraw.DrawMidText(std::to_string(maxcount) + "���ڰ� �ԷµǾ��ֽ��ϴ�.", BOXSTART_X, BOXSTART_Y);
					break;
				}
				else
				{
					str += iKey;
				}
				break;
			}
			mapdraw.DrawMidText("                     ", MAX_X, BOX_IN_OBJECT_Y);
			mapdraw.DrawMidText(str, MAX_X, BOX_IN_OBJECT_Y);
		}
	}
	return false;
	//�Լ�ȭ �Ұ� 
}

void Play::State()
{

	std::string life = "Life : " + strCurLife; //��Ʈ�� ���� ���� �� �� �ֵ��� �Ұ�
	std::string score = "Score : " + std::to_string(iScore); // ������ ���� �� �ֵ��� �� ��
	std::string nickname = "Name : " + name; // �̸��� ���� �� �ֵ��� �� ��
	mapdraw.TextDraw(life, STATE_LIFE_X, STATE_Y);

	mapdraw.TextDraw(score, STATE_SCORE_X, STATE_Y);
	mapdraw.TextDraw(nickname, STATE_NAME_X, STATE_Y);
}
void Play::Box()
{
	mapdraw.BoxDraw(BOXSTART_X, BOXSTART_Y, BOXMAX_X, BOXMAX_Y);
}
void Play::LoadStory(std::vector<std::string>* story_list)
{
	std::string strObject = "0", strstory = "0";
	int iLineNum = 0;
	std::ifstream load;
	load.open("����ġ��_���丮.txt");
	if(load.is_open())
	{//����ó���� ���丮�� ����� �ε� �Ǿ����� Ȯ��
		try
		{
			load >> iLineNum;
			if (iLineNum != 26) throw iLineNum;
		}
		catch (const int& ex)
		{
			std::cout << "���� �߻�" << std::endl;
			std::cout << "���丮�� �ִ� �ټ��� �ٸ��ϴ�." << std::endl;
		}

		while (!load.eof())
		{
			getline(load, strstory);
			story_list->push_back(strstory);
		}

		load.close();
	}
}
void Play::Story()
{
	std::vector<std::string> story_list;
	
	Box();
	mapdraw.DrawMidText("Skip : s", MAX_X, BOX_IN_OBJECT_Y);
	LoadStory(&story_list);
	//int i = 0;
	int count = 1;
	int j = 0;
	std::string line[10] = {};
	//���͸� �迭 ó�� ���� ���� story_list[] �̷��� ��
	int OldClock = 0, CurClock = 0;
	OldClock = clock();
	while (story_list.size() - SCROLL_NUM >= j)
	{
		CurClock = clock();
		if (kbhit())
		{
			if (getch() == 's')return;
		}
		else
		{
			if (CurClock - OldClock >= 1000)
			{
				for (int i = 0; i < count; i++)
				{
					mapdraw.DrawMidText("                                            ", MAX_X, STORY_Y + i);
					mapdraw.DrawMidText(story_list[i + j], MAX_X, STORY_Y + i);
				}

				if (SCROLL_NUM > count) count++;
				else j++;
				OldClock = CurClock;
			}
		}
	}
	OldClock = 0, CurClock = 0;
	OldClock = clock();
	while (TRUE) { CurClock = clock(); if (CurClock - OldClock >= 2000) return; }
	// �ð� ����
}
void Play::Name()
{
	mapdraw.DrawMidText("�̸� �Է�", MAX_X, MIDDLE_Y);
	Box();
	mapdraw.gotoxy(MAX_X, BOX_IN_OBJECT_Y);
	while (!InputStr(name, MAX_LENGTH));

}
void Play::Story_Name()
{
	Clearmap();
	State();
	Story();
	Clearmap();
	State();
	Name();
	
}

void Play::GamePlay()
{
	Story_Name();
	Clearmap();
	State();
	iLife = 5; // ���߿� �����
	wordmanager.Load();
	int l = 0, t;
	int l2 = 0, t2;

	while (0 <= iLife)
	{
		t = clock();
		t2 = clock();
		if (l <= t)
		{
			l = t + 2000;
			wordmanager.MakeWord();
		}

		if (l2 <= t2)
		{
			l2 = t2 + 500;
			wordmanager.Drop();
		}
		
		CheckWord();
	}
	//input
	//���� üũ

}
void Play::CheckWord()
{
	InputStr(wordcheck, MAX_LENGTH);
	wordmanager.CheckWord(wordcheck, iScore);
	
}
Play::~Play() {}