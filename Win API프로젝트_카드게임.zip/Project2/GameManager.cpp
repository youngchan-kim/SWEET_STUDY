#include "GameManager.h"

void GameManager::First_Stage(HDC hdc)
{
	if (m_eStage == START)
		m_eStage = MAIN;
	else if (m_eStage == GAMING)
		return;
	std::wstring str = L"[���� ����]";
	Rectangle(hdc, 250, 300, 350, 350);
	RECT rect = { 250, 320, 350, 400 };
	DrawText(hdc, str.c_str(), -1, &rect, DT_VCENTER | DT_CENTER);
}

bool GameManager::ColliderCheck(POINT point)
{
	if (PtInRect(&rect, point))
	{
		m_eStage = GAMING;
		return true;
	}
	return false;
}

STAGE GameManager::StageCheck()
{
	if (m_eStage == MAIN) return MAIN;
	else return GAMING;
}
