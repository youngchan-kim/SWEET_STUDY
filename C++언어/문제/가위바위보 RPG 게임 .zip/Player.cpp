#include "Player.h"
Player::Player() : weapon(NULL) {}

void Player::Load(ifstream& load, string name)
{
	if (NULL != weapon)
	{
		delete weapon;
		weapon = NULL;
	}

	bool isLoad;
	isLoad = ("" == name);
	if (isLoad) load >> m_strname;
	else if (!isLoad) m_strname = name;
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	if (isLoad)
	{
		load >> m_iexp;
		load >> m_icurhealth;
		bool weaponcheck;
		load >> weaponcheck;
		if (weaponcheck)
		{
			string weapontype;
			load >> weapontype;
			if ("Bow" == weapontype)
				 weapon = new Bow;
			else if ("Dagger" == weapontype)
				weapon = new Dagger;
			else if ("Gun" == weapontype)
				weapon = new Gun;
			else if ("Sword" == weapontype)
				weapon = new Sword;
			else if ("Wand" == weapontype)
				weapon = new Wand;
			else if ("Hammer" == weapontype)
				weapon = new Hammer;
			weapon->Load(load);
		}
	}
	else
	{
		m_icurhealth = m_imaxhealth;
	}
}
void Player::Save(ofstream& save)
{
	save << m_strname << " ";
	save << m_idamage << " ";
	save << m_imaxhealth << " ";
	save << m_imaxexp << " ";
	save << m_igetexp << " ";
	save << m_iLv << " ";
	save << m_igold << " ";
	save << m_iexp << " ";
	save << m_icurhealth << endl;
	bool weaponcheck = (NULL != weapon);
	save << weaponcheck << " ";
	if (weaponcheck)
	{
		weapon->Save(save);
	}
	//���� �ƴҶ�
	// ���� �������� ���
}

void Player::Infomation(int x, int y)
{
	string line1, line2, line3, line4, line5;
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string((int)m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth) + " ";
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	YELLOW
	mapdraw.DrawMidText(line1, x, y);
	mapdraw.TextDraw(line2, x * 0.5f, y + 1);
	mapdraw.TextDraw(line3, x * 0.5f, y + 2);
	mapdraw.TextDraw(line4, x * 0.5f, y + 3);
	if (weapon != NULL)
	{
		line5 = "����Ÿ�� : " + weapon->WeaponType() + " " + weapon->WeaponInfo();
		mapdraw.DrawMidText(line5, x, y + 4);
	}
	ORIGINAL
}


void Player::Levelup()
{			PLUM
	int iDamage, iHealth, iLvup = 1;
	if (m_iexp >= m_imaxexp)
	{
		system("cls");
		BLUE
			mapdraw.BoxDraw(START_X, START_Y, WIDTH, HEIGHT);
		ORIGINAL

		iDamage = (rand() % UPATTACKSTAT) + 1;
		iHealth = (rand() % UPATTACKSTAT) + 1;
		m_idamage += iDamage;
		m_imaxhealth += iHealth;
		m_iLv += iLvup;
		m_imaxexp += m_imaxexp * 0.3;
		m_icurhealth = m_imaxhealth;
		m_iexp = 0;
		PLUM
		mapdraw.DrawMidText(to_string(iLvup) + "���� ��!!", WIDTH, HEIGHT_MIDDLE - 2);
		mapdraw.DrawMidText("���ݷ� " + to_string(iDamage) + " ����!!", WIDTH, HEIGHT_MIDDLE);
		mapdraw.DrawMidText("������ " + to_string(iHealth) + " ����!!", WIDTH, HEIGHT_MIDDLE + 2);
		ORIGINAL
		_getch();
	}
}
void Player::GetWinner(int exp, int gold)
{
	m_iexp += exp;
	m_igold += gold;
}

void Player::WeaponBuy(Weapon* weaponwear) 
{ 
	m_igold -= weaponwear->Price();
	if (weapon != NULL)
	{
		delete weapon;
		weapon = NULL;
	}
	weapon = weaponwear;
};


Player::~Player() {
	if (NULL != weapon)
	{
		delete weapon;
		weapon = NULL;
	}
}