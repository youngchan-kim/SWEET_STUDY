#pragma once
#include<iostream>
#include<string>
using namespace std;

class Manager
{
private:
	char* name;
public:
	void Print(char name[], string str);
	void Swap(char name[], string str, int barnum1, int barnum2);

	Manager();
	~Manager();
};


