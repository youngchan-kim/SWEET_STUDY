#include "Bitmap.h"

void Bitmap::Init(HDC hdc, char* FileName, int imagecode)
{
	MemDC = CreateCompatibleDC(hdc);
	switch (imagecode)
	{
	case 1:
		//�׷����� ī���� ���� ���� ���̴�  70, 120
		m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 70, 120, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		break;

	case 2:
		m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 70, 120, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		break;

	case 3:
		m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 70, 120, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		break;

	case 4:
		m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 70, 120, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		break;

	case 5:
		m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 70, 120, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		break;
	}

	
	SelectObject(MemDC, m_BitMap);
	BITMAP BitMap_Info;

	GetObject(m_BitMap, sizeof(BitMap_Info), &BitMap_Info);
	m_Size.cx = BitMap_Info.bmWidth;
	m_Size.cy = BitMap_Info.bmHeight;
}


////���� ���۸��� ���� ���ο� DIBSection�� ������ش�. Winȭ��� ���� ȭ���� ����� ��
//HBITMAP Bitmap::CreateDIBSectionRe(HDC hdc, int width, int height)
//{
//    BITMAPINFO bm_info;
//    ZeroMemory(&bm_info.bmiHeader, sizeof(BITMAPINFOHEADER));
//    bm_info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
//    bm_info.bmiHeader.biBitCount = 24;
//    bm_info.bmiHeader.biWidth = width;
//    bm_info.bmiHeader.biHeight = height;
//    bm_info.bmiHeader.biPlanes = 1;
//
//    LPVOID pBits;
//    return CreateDIBSection(hdc, &bm_info, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
//}