#pragma once
#include "BaseGameEntity.h"
#include "Locations.h"

#define COMFORT_LEVEL		5	// amount of gold that feel enough
#define MAX_NUGGETS			3	// max balance
#define THIRST_LEVEL		5	// max thristyness
#define TIREDNESS_THRESHOLD	5	// max tiredness

class WoodMan;
class State
{
public:
	virtual ~State() {}

	virtual void Enter(WoodMan*) abstract;
	virtual void Excute(WoodMan*) abstract;
	virtual void Exit(WoodMan*) abstract;
};

class WoodMan : public BaseGameEntity
{
private:
	State* m_pCurrState;
	Location_Type m_Location;
	int				m_nGoldCarried;	// amount of gold that miner got from mining
	int				m_nMoneyInBank;	// balance in bank 
	int				m_nThirst;		// thirstyness
	int				m_nFatigue;		// tiredness

public:
	WoodMan(const int& id);
	virtual ~WoodMan() {}

	void Update() override;
	void ChangeState(State*);

	Location_Type Location() const { return m_Location; }
	void ChangeLocation(const Location_Type& loc_type) { m_Location = loc_type; }

	int GoldCarried() const { return m_nGoldCarried; }
	void SetGoldCarried(const int& value) { m_nGoldCarried = value; }
	void AddToGoldCarried(const int&);
	bool PocketsFull()const { return (MAX_NUGGETS <= m_nGoldCarried); }

	bool Fatigued() const;
	void DecFatigued() { m_nFatigue--; }
	void
};


