#pragma once
#include"Student.h"


#define STUDENT_MAX 10
#define NULL 0
class StudentManager
{
private:
	list<Student> m_studentlist;
public:
	void AddStudent();
	inline int GetStudentCount()
	{
		return m_studentlist.size();
	}
	void ShowStudentList();
	void StudentClassPrint(int i);
	void ShowStudentClassList();
	void FindStudentName();
	void FindStudentClass();
	void StudentListLastDelete();
	void StudentAllDelete();
	StudentManager();
	~StudentManager();
};
//�г� ��� �ߺ� �ڵ�
