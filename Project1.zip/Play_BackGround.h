#pragma once
#include "BitMapManager.h"
class Play_BackGround
{
private:
	BitMap** bmback;
	int x;
public:
	Play_BackGround();
	~Play_BackGround();
	void Init();
	void Track(HDC backDC,int width);
	void GrandStand(HDC backDC, int x, int width);
};

