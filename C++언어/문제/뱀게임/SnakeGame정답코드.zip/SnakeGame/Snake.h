#pragma once
#include"Block.h"
#include"Timer.h"
#include<vector>

#define DEFAULT_SPEED 700
#define SPEED_UP_VALUE 30
#define MAX_SPPED 100
enum class DIRECTION
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	NON
};
class Snake
{
private:
	Block m_Head;
	Timer m_MoveTimer;
	DIRECTION m_eDirection;
	vector<Block> m_vecTailList;
	Block m_PrevPosition;
	bool m_bLifeStatus;
public:
	Snake();
	~Snake();
	inline bool GetLife() { return m_bLifeStatus; }
	void Init();
	void Move();
	void Draw();
	void CreateTail();
	void MoveTimerCheck();
	void Input();
	void DrawScore();
	inline int GetScore() { return m_vecTailList.size(); }

};

