#include "GameClass.h"

GameClass::GameClass()
{
	m_iStart_x = 0;
	m_iStart_y = 0;
	m_iWidth = MAXWIDTH_MAXHEIGHT;
	m_iHeight = MAXWIDTH_MAXHEIGHT;
	srand((unsigned)time(NULL));
	m_ch = NULL;
	num = 0;
}

int GameClass::RandomPosition()
{
	int position = (rand() % (MAXWIDTH_MAXHEIGHT-2)) + 1;
	return position;
}

bool GameClass::WallCrash(Position cursor)
{
	for (std::vector<BlockClass>::iterator iter = walllist.begin(); iter != walllist.end(); iter++)
	{
		if (iter->PositionCheck(cursor) == true)
			return true;
	}
	return false;
}

void GameClass::SetWall(BLOCK_TYPE type)
{
	wallshape.Shape(type, m_cursor);
	walllist.push_back(wallshape);
	wallshape.ShapeDraw(type, m_cursor);
}

void GameClass::WallList()
{
	for (m_cursor.m_iy = 0; m_cursor.m_iy < m_iHeight; m_cursor.m_iy++)
	{
		m_cursor.m_ix = 0;;
		if (m_cursor.m_iy == 0)
		{
			SetWall(BARRICADE);
			for (m_cursor.m_ix = 1; m_cursor.m_ix < m_iWidth - 1; m_cursor.m_ix++)
				SetWall(BARRICADE);
			SetWall(BARRICADE);
		}
		else if (m_cursor.m_iy == m_iHeight - 1)
		{

			SetWall(BARRICADE);
			for (m_cursor.m_ix = 1; m_cursor.m_ix < m_iWidth - 1; m_cursor.m_ix++)
				SetWall(BARRICADE);
			SetWall(BARRICADE);
		}
		else
		{
			SetWall(BARRICADE);
			m_cursor.m_ix = m_iWidth - 1;
			SetWall(BARRICADE);
		}
	}
	for (int i = 0; i < MAXWALLBLOCK; i++)
	{
		bool stop;
		do
		{
			stop = true;
			m_cursor.m_ix = RandomPosition();
			m_cursor.m_iy = RandomPosition();


				if (WallCrash(m_cursor) == true)
				{
					stop = false;
					break;
				}
				if (snack.HeadPositionCheck(m_cursor) == true)
				{
					stop = false;
					break;
				}
		} while (stop == false);
		SetWall(WALL);
	}
}

bool GameClass::ItemSearch(Position cursor)
{
	for (std::list<BlockClass>::iterator iter = itemlist.begin(); iter != itemlist.end(); iter++)
	{
		if (iter->PositionCheck(cursor) == true)
		return true;
	}
	return false;
}

std::list<BlockClass>::iterator GameClass::ItemSearch()
{
	for (std::list<BlockClass>::iterator iter = itemlist.begin(); iter != itemlist.end(); iter++)
	{
		if (iter->PositionCheck(snack.SnackPosition()) == true)
				return iter;
	}
	return itemlist.end();
}
//�̷���� �����ε��� �Ҳ�

void GameClass::ItemReMove()
{
	std::list<BlockClass>::iterator itemiter = ItemSearch();
	if (itemiter != itemlist.end())
	{
		itemlist.erase(itemiter);
		m_iitemcout--;
	}
}

void GameClass::SetItem()
{
	if (m_iitemcout < MAXITEMBLOCK)
	{
		bool stop;
		do
		{
			stop = true;
			m_cursor.m_ix = RandomPosition();
			m_cursor.m_iy = RandomPosition();

			if (WallCrash(m_cursor) == true)
			{
				stop = false;
			}
			else if (ItemSearch(m_cursor) == true)
			{
				stop = false;
			}
			else if (snack.HeadPositionCheck(m_cursor) == true)
			{
				stop = false;
			}
			else if (snack.TeilPositionCheck(m_cursor) == true)
			{
				stop = false;
			}
		} while (stop == false);
		itemshape.Shape(ITEM, m_cursor);
		itemlist.push_back(itemshape);
		itemshape.ShapeDraw(ITEM, m_cursor);
		m_iitemcout++;
	}
}

void GameClass::Map_Interface()
{
	strscore = "Score : ";
	score = strscore + std::to_string(snack.Score());
	MapDraw::DrawMidText(score, m_iWidth, m_iHeight + 1);
}

void GameClass::GameEnd()
{
	char space_bar = NULL;
	Map_Interface();
	MapDraw::DrawMap(m_iStart_x, m_iStart_y, m_iWidth, m_iHeight);
	MapDraw::DrawMidText("�� �� �� Game Over �� �� ��", m_iWidth, m_iHeight * 0.4f);
	MapDraw::DrawMidText("Continue : Space Bar", m_iWidth, m_iHeight * 0.6f);
	snack.END();
	itemlist.clear();
	walllist.clear();
	while(TRUE)
	{
		space_bar = getch();
		if (space_bar == SPACE_BAR)
			return;
	}
}

void GameClass::Game()
{
	system("cls");
	Map_Interface();
	bool add;
	m_ch = NULL;
	m_iitemcout = 0;
	m_cursor.m_ix = MAXWIDTH_MAXHEIGHT * 0.5f;
	m_cursor.m_iy = MAXWIDTH_MAXHEIGHT * 0.5f;
	snack.SetHead(m_cursor);
	WallList();
	m_imaintime = clock();
	while (TRUE)
	{
		m_iitemtime = clock();
		if (m_iitemtime - m_imaintime > ITEMTIME)
		{
			if (m_iitemcout < MAXITEMBLOCK)
			{
				SetItem();
				m_imaintime = m_iitemtime;
			}
		}

		if (WallCrash(snack.SnackPosition()) == true || snack.HeadTeilCrush() == true)
		{
 			GameEnd();
			return;
		}
		if (ItemSearch(snack.SnackPosition()) == true)
		{
 			ItemReMove();
			snack.Add_Teil();
			Map_Interface();
		}
		if (kbhit())
		{
			m_ch = getch();

			snack.Head_MoveArray(m_ch);
		}
		snack.Head_Move();
	}
}

void GameClass::Menu()
{
	while (TRUE)
	{
		int select;
		Map_Interface();
		MapDraw::DrawMap(m_iStart_x, m_iStart_y, m_iWidth, m_iHeight);
		MapDraw::DrawMidText("�� �� �� Snake Game �� �� ��", m_iWidth, m_iHeight * 0.3f);
		MapDraw::DrawMidText("1.���� ����", m_iWidth, m_iHeight * 0.4f);
		MapDraw::DrawMidText("2.���� ����", m_iWidth, m_iHeight * 0.5f);
		MapDraw::DrawMidText("���� : ", m_iWidth, m_iHeight * 0.6f);

		std::cin >> select;
		switch (select)
		{
		case 1:
			Game();
			break;
		case 2:
			return;
		default:
			break;
		}
	}
}

GameClass::~GameClass()
{
}