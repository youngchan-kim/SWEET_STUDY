#include "Template.h"

void main()
{
	Template tem;

	auto a = 0;
	auto b = 0;
	std::cin >> a >> b;
	Number(a, b);
}