#include "GameManager.h"

void main()
{
	system("mode con: cols=60 lines=30");
	GameManager g;
	g.Start();
}