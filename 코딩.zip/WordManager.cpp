#include "WordManager.h"
WordManager::WordManager() {}
WordManager::~WordManager() {}

void WordManager::Load()
{
	int num;
	std::ifstream load;
	load.open("Word.txt");
	if (load.is_open())
	{
		std::string strString;
		load >> num;
		wordnum = num;
		while (load.eof())
		{
			getline(load, strString);
			word_list.push_back(Word(strString));
		}
		load.close();
	}
}

void WordManager::MakeWord()
{
	int num = rand() % word_list.size();
	int word_x = (rand() % MAX_X)+1;
	int itme_type = (rand() % ITEM_TYPE) + 1;
	//if (itme_type == 1)
	//{
	//	//�Ϲ� ����
	//}
	//if (itme_type == 2)
	//{
	//	//���� �ӵ� ����
	//}
	//if (itme_type == 3)
	//{
	//	//���� �ӵ� ����
	//}
	//if (itme_type == 4)
	//{
	//	//���� �Ͻ� ����
	//}
	//if (itme_type == 5)
	//{
	//	//ȭ�� Ŭ����
	//}
	//if (itme_type == 6)
	//{
	//	//���� ������ 5��
	//}
	word_list[num].SetWord(word_x, itme_type);
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

void WordManager::Draw()
{
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

void WordManager::Drop()
{

	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Drop();
		}
	}

}
