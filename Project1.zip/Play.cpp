#include "Play.h"

void Play::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	//ȭ���� �ִ� �̵� �ϴ� �Ÿ� 9000
	background_max_distance = 2000.0f;


	background.Init(width, height);
	player.Init(width, height);
	object.Init(width, height, background_max_distance);
	play_interface.Init(width, height);

	
}

void Play::Draw(HDC backDC)
{
	background.Draw(backDC);
	player.Draw(backDC);
	object.Draw(backDC);
}

void Play::Update(float deltatime)
{
	speed = player.Update(deltatime, background_max_distance);

	distance = player.Distance();

	background.Update(deltatime, speed, background_max_distance, distance);
	object.Update(deltatime, speed, distance);
}



