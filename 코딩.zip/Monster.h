#pragma once
#include "Character.h"
class Monster : public Character
{
protected:
	string line1, line2, line3, line4;
public:
	Monster();
	void Load(ifstream& load, string name = "") override;
	void Infomation() override;
	~Monster();
};

