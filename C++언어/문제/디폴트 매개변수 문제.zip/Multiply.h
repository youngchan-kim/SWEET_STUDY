#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;
#define TRUE 1
#define YES 1
#define NO 2

class Multiply
{
public:
	void Multiply_inupt();
	void Multiply_Print(int min = 2, int max = 9);
	Multiply();
	~Multiply();
};

