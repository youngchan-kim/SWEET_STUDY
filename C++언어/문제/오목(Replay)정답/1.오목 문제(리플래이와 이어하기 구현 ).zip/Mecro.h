#pragma once

#include<iostream>
#include<string>
#include<conio.h>
#include<iomanip>
#include<Windows.h>
#include<list>
#include<iostream>
#include<fstream>
using namespace std;
