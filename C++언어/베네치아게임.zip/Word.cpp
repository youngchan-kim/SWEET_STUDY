#include "Word.h"
Word::Word() {};
Word::~Word() {};

void Word::Draw(bool bBlind)
{	
	if (bBlind) BlindWord();
	else
	{
		switch (iWordType)
		{
		case SPEEDUP:
			BLUE
				break;
		case SPEEDDOWN:
			RED
				break;
		case PUASE:
			GREEN
				break;
		case CLEAR:
			GOLD
				break;
		case BLIND:
			PLUM
				break;
		}
		mapdraw.TextDraw(str, x, y);
		ORIGINAL
	}
}


int Word::Drop(bool bBlind)
{ 
	Erase(); 
	y++; 
	Draw(bBlind);
	if (y == 28)
	{
		Die();
		return 1;
	}
	return 0;
}

