#include "BlockClass.h"

BlockClass::BlockClass() {}
std::string BlockClass::Type_Shape(BLOCK_TYPE type)
{
	switch (type)
	{
	case WALL:
		return "��";
	case BARRICADE:
		return "��";
	case ITEM:
		return "��";
	case HEAD:
		return "��";
	case TEIL:
		return "��";
	}
}

void BlockClass::ShapeDraw(BLOCK_TYPE type, Position cursor)
{
	MapDraw::DrawPoint(Type_Shape(type), cursor.m_ix, cursor.m_iy);
}

void BlockClass::Position_input(int x, int y)
{
	m_position.m_ix = x;
	m_position.m_iy = y;
}
void BlockClass::Shape(BLOCK_TYPE type, Position cursor)
{
	block_type = type;
	m_strshape = Type_Shape(type);
	Position_input(cursor.m_ix, cursor.m_iy);
	ShapeDraw(type, cursor);
}


bool BlockClass::PositionCheck( Position cursor)
{
	if (m_position.m_ix == cursor.m_ix)
		if (m_position.m_iy == cursor.m_iy)
			return true;
	return false;
}

BlockClass::~BlockClass(){}