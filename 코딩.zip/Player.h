#pragma once
#include "Character.h"
class Player : public Character
{
private:
public:
	Player();

	void Load(ifstream& load, string name = "") override;
	void Save(int slot);
	void Infomation() override;
	~Player();
};

