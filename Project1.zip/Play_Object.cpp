#include "Play_Object.h"

Play_Object::Play_Object()
{
	bmobject = new BitMap * [OTHEROBJECT_4];
}

Play_Object::~Play_Object()
{
	if (bmobject != NULL) { delete[] bmobject; bmobject = NULL; }
}

void Play_Object::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	for (int i = 0; i < OTHEROBJECT_4; i++)  bmobject[i] = BMMger->GetOtherObject((OTHEROBJECT)(i));
}

void Play_Object::Draw(HDC backDC)
{
	bmobject[1]->Draw(backDC, GOAL_X, 500, GOAL_WIDTH, GOAL_HEIGHT);
}

void Play_Object::Update(float deltatime)
{
}
