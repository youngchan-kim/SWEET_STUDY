#include "Play_Interface.h"

Play_Interface::Play_Interface()
{
	bminterface = new BitMap * [INTERFACE_3];
}

Play_Interface::~Play_Interface()
{
	if (bminterface != NULL) { delete[] bminterface; bminterface = NULL; }
}

void Play_Interface::Init(int width, int height,float move_change_point)
{
	this->width = width;
	this->height = height;
	this->move_change_point = move_change_point;
	for (int i = 0; i < INTERFACE_3; i++)  bminterface[i] = BMMger->GetGameInterface((GAMEINTERFACE)(i));
	between_distence_block = width;
	start_distence_x = 0;

	billboard_x = width*0.1f;
	billboard_y = height * 0.01f;
	billboard_Sx = width * 0.8f;
	billboard_Sy = height * 0.14f;

	life_x = billboard_Sx;
	life_y = billboard_Sy- height * 0.04f;
	life_Sx = width*0.01f;
	life_Sy = height*0.02f;

	distence_x = start_distence_x; 
	distence_y = height*0.825f; 
	distence_Sx = width*0.1f; 
	distence_Sy= height * 0.1f;
	
	end_x = move_change_point;
	while (end_x >= width)
	{
		end_x -= width;
		if (end_x <= width)break;
	}
}

void Play_Interface::Draw(HDC backDC)
{
	bminterface[0]->Draw(backDC, billboard_x, billboard_y, billboard_Sx, billboard_Sy);
	bminterface[1]->Draw(backDC, life_x, life_y, life_Sx, life_Sy);


	bminterface[2]->Draw(backDC, distence_x- between_distence_block, distence_y, distence_Sx, distence_Sy);
	bminterface[2]->Draw(backDC, distence_x, distence_y, distence_Sx, distence_Sy);
	bminterface[2]->Draw(backDC, distence_x + between_distence_block, distence_y, distence_Sx, distence_Sy);

	//M_point(backDC, str1 , distence_x - between_distence_block, distence_y, distence_Sx, distence_Sy);
	//M_point(backDC, str2, distence_x, distence_y, distence_Sx, distence_Sy);
	//M_point(backDC, str3, distence_x + between_distence_block, distence_y, distence_Sx, distence_Sy);
}

void Play_Interface::Update(float deltatime, int speed, float distance, int saveindex)
{
	//bminterface[1]�� �÷��̾��� ����� ������ ����
	distence_x -= speed * deltatime;



	if (distance <= 0.0f) distence_x = start_distence_x;
	else if (distance < move_change_point)
	{
		//���� ������ �ݺ�
		if (distence_x <= -between_distence_block) distence_x += between_distence_block;
		else if (distence_x > between_distence_block)distence_x -= between_distence_block;
	}

	else if (distance >= move_change_point)
	{
		distence_x = end_x + (width * 0.6f);
	}
//��
	if (distance >= between_distence_block * saveindex)
	{
		str1 = L"����";
		str2 = L"����1";
		str3 = L"����2";
	}
	
}

//���� ǥ��
void Play_Interface::M_point(HDC backDC, std::wstring m, float left, float top, float right, float bottom)
{
	RECT rect = { left, top, right, bottom };
	DrawText(backDC, m.c_str(), -1, &rect, DT_VCENTER | DT_CENTER);
}