#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;
#define TRUE 1
#define YES 1
#define NO 2


class Sum_From_1_to_x
{
public:
	void Sum_From_1_to_x_inupt();
	void Sum_Print(int xnum = 10);
	Sum_From_1_to_x();
	~Sum_From_1_to_x();
};

