#pragma once
#include"Figure.h"
class Quadrangle : public Figure
{
public:
	void Draw();
	void SetSize();
	Quadrangle();
	~Quadrangle();
};

