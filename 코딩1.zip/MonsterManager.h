#pragma once
#include "Monster.h"
#include <vector>

class MonsterManager:public Monster
{
private:
	vector<Monster> monsterlist;
public:
	MonsterManager();

	void SetMonster();
	void MonsterList();
	void DongeonList(int x, int y);
	void MonsterSelect(int dongeonnum, int x, int y);
	~MonsterManager();
};

