#include "Template.h"

void main()
{
	Template tem;

	int a = 0;
	std::cin >> a;
	Number(a);
}