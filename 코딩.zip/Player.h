#pragma once
#include "Character.h"
class Player : public Character
{
private:
public:
	Player();

	void Load(ifstream& load, string name = "") override;
	void Save(int slot);
	void Infomation(int x, int y) override;
	inline int Atteck() {return m_idamage;	};
	inline int Gold() { return m_igold;	};
	~Player();
};

