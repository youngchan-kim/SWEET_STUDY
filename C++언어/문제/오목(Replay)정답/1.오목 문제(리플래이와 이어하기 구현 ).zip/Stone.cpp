#include "Stone.h"

Stone::Stone() {}

void Stone::SetStone(Position iCursor)
{
	m_position.m_ix = iCursor.m_ix;
	m_position.m_iy = iCursor.m_iy;
}

Position Stone::StoneXY()
{
	return m_position;
}

bool Stone::StoneCompareXY(int x, int y)
{	
	if (x == m_position.m_ix)
		if (y == m_position.m_iy)
			return true;
	return false;
}

Stone::~Stone() {}