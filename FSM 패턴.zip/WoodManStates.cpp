#include "WoodManStates.h"
#include "EntityNames.h"
#include "ConsoleUtils.h"

//EnterWoodcutter-----------------------

EnterWoodCutting* EnterWoodCutting::Instance()
{
	static EnterWoodCutting instance;
	return &instance;
}

void EnterWoodCutting::Enter(WoodMan* pWoodMan)
{
	if (pWoodMan->Location() != MyLocationType::forest)
	{
		SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << GetNameOfEntity(pWoodMan->ID()) << " : �����Ϸ� ���� ����." << std::endl;

		pWoodMan->ChangeLocation(MyLocationType::forest);
	}
}

void EnterWoodCutting::Excute(WoodMan* pWoodMan)
{
	pWoodMan->AddToGoldCarried(1);

	SetTextColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
	std::cout << GetNameOfEntity(pWoodMan->ID()) << " : ���� 1�� �����." << std::endl;

}