#include "WordManager.h"
WordManager::WordManager() {}
WordManager::~WordManager() {}

void WordManager::Load()
{
	int num;
	std::ifstream load;
	load.open("Word.txt");
	if (load.is_open())
	{
		std::string str;
		load >> num;
		wordnum = num;
		while (!load.eof())
		{
			getline(load, str);
			word_list.push_back(Word(str));
		}
		load.close();
	}
}
// ����� ���� ����Ʈ�� �������� 76����
// 0��°�� str�� ���� ����


void WordManager::MakeWord()
{
	int i = rand() % word_list.size();
	int x = (rand() % (MAX_X - 4)) + 2;
	//int iWordType = (rand() % (MAX_X - 4)) + 2;
	if(word_list[i].IsDead())
		word_list[i].SetWord(x, 0);
}
//void WordManager::WordTypeEffect(int wordtype)
//{
//
//}

bool WordManager::CheckWord(std::string& wordcheck, int& iScore)
{
	for (int i = 0; word_list.size() > i; i++)
	{
		if (!word_list[i].IsDead())
		{
			if (word_list[i].GetWord() == wordcheck)
			{
				word_list[i].Die();
				iScore += word_list[i].GetWordSize(); //���� ����
				return true; //�ܾ �¾Ҵ��� Ʋ�ȴ���
			}
		}
	}

	return false;
}

void WordManager::Draw()
{
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

int WordManager::Drop()
{
	int life = 0;
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			if (word_list[i].Drop() == 1)
			{
				life = 1;
				word_list[i].Die();
			}
		}
	}
	return life;
}

void WordManager::ClearWord()
{
	word_list.clear();
}
