#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>
#include "Object.h"
class Box : public Object
{
private:
	float half_width, half_height;
	float volume;

public:
	void Init(float x, float y, float width, float height, float d, bool fix);

	void Draw(HDC hdc);
	float GetVolume() { return volume; }

	float GetHalf_Width() { return half_width; }
	float GetHalf_Height() { return half_height; }	
};

