#include "Quiz03.h"


Quiz03::Quiz03()
{
}
void Quiz03::Print(int iarr[], int len)
{
	for (int i = 0; i < len; i++)
		cout << "iarr[" << i << "] : " << iarr[i] << endl;
}
void Quiz03::CharPrint(int iarr[], int len)
{
	for (int i = 0; i < len; i++)
		cout << "iarr[" << i << "] : " << (char)iarr[i] << endl;
}

void Quiz03::Quiz3(int num01, int num02, int num03, int num04, int num05)
{
	int tmp;
	int iarr[MAX] = { num01 , num02 ,num03 ,num04 ,num05 };
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			if (iarr[i] > iarr[j])
			{
				tmp = iarr[i];
				iarr[i] = iarr[j];
				iarr[j] = tmp;
			}
		}
	}
	Print(iarr, MAX);
}
void Quiz03::Quiz3(char char01, char char02, char char03, char char04, char char05)
{
	int tmp;
	int iarr[MAX] = { char01 , char02 ,char03 ,char04 ,char05 };

	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			if (iarr[i] < iarr[j])
			{
				tmp = iarr[i];
				iarr[i] = iarr[j];
				iarr[j] = tmp;
			}
		}
	}
	CharPrint(iarr, MAX);

}
Quiz03::~Quiz03()
{
}