#include "Character.h"

Character::Character() {}

Character::~Character() {}