#pragma once

#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include<functional>
#include<time.h>
#include<stdlib.h>
using namespace std;

#define WIDTH 50
#define HEIGHT 30

enum class KEY
{
	LEFT = 'a',
	RIGHT = 'd',
	UP = 'w',
	DOWN = 's',
};