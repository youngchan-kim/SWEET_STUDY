#pragma once
#include "Character.h"
#include "Weapon.h"
#define UPATTACKSTAT 4

class Player : public Character
{
private:
	Weapon* weapon;
public:
	Player();
	virtual int Atteck() override { return (NULL != weapon) ? weapon->Atteck(m_idamage,WIDTH, HEIGHT_MIDDLE - 3) : m_idamage; } //���׿����� 

	void Load(ifstream& load, string name = "") override;
	void Save(ofstream& save);
	void Infomation(int x, int y) override;
	void Levelup();
	void GetWinner(int exp, int gold);
	void WeaponBuy(Weapon* weaponwear);
	~Player();
};

