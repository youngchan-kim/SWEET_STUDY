#include "Play_Interface.h"

Play_Interface::Play_Interface()
{
	bminterface = new BitMap * [INTERFACE_3];
}

Play_Interface::~Play_Interface()
{
	if (bminterface != NULL) { delete[] bminterface; bminterface = NULL; }
}

void Play_Interface::Init(int width, int height,float move_change_point, int distance_index, int life)
{
	this->width = width;
	this->height = height;
	this->move_change_point = move_change_point;
	this->distance_index = (distance_index+1)*10;
	start_distance_index = this->distance_index;

	for (int i = 0; i < INTERFACE_3; i++)  bminterface[i] = BMMger->GetGameInterface((GAMEINTERFACE)(i));
	between_distence_block = width;
	start_distence_x = 0;

	billboard_x = width * 0.1f;
	billboard_y = height * 0.01f;
	billboard_Sx = width * 0.8f;
	billboard_Sy = height * 0.14f;

	life_x = billboard_Sx- width * 0.025f;
	life_y = billboard_Sy- height * 0.035f;
	life_Sx = width*0.01f;
	life_Sy = height*0.02f;

	distence_x = start_distence_x; 
	distence_y = height*0.825f; 
	distence_Sx = width*0.1f; 
	distence_Sy = height * 0.1f;
	
	Bonus_x = width * 0.5f;
	Bonus_y = height * 0.05f;
	Bonus_Sx = width * 0.4f;
	Bonus_Sy = height * 0.14f;

	Score_x= width * 0.1f;
	Score_y = height * 0.05f;
	Score_Sx = width * 0.3f;
	Score_Sy = height * 0.14f;

	end_x = move_change_point;
	while (end_x >= width)end_x -= width;

	this->life = life;
	bonus_score = 10000;
	save_bonus_score = 0;
	this->score = 0;

	str1 = std::to_wstring(distance_index + 10);
	str2 = std::to_wstring(distance_index);
	str3 = std::to_wstring(distance_index - 10);
}

void Play_Interface::Draw(HDC backDC)
{
	bminterface[0]->Draw(backDC, billboard_x, billboard_y, billboard_Sx, billboard_Sy);
	for (int i = 0; i < this->life; i++) 	bminterface[1]->Draw(backDC, life_x + (width * (0.015f * i)), life_y, life_Sx, life_Sy);


	bminterface[2]->Draw(backDC, distence_x - between_distence_block, distence_y, distence_Sx, distence_Sy);
	bminterface[2]->Draw(backDC, distence_x, distence_y, distence_Sx, distence_Sy);
	bminterface[2]->Draw(backDC, distence_x + between_distence_block, distence_y, distence_Sx, distence_Sy);



	//��µ�
	//�� ������ ���� ���ڷ� ����
	
	//��µ�
	rect_left = distence_x;
	rect_right = distence_Sx + rect_left;
	rect_top = distence_y+ width * 0.01f;;
	rect_bottom = distence_Sy + rect_top;
	//���� ���
	Print_point(backDC, str1, rect_left - (LONG)between_distence_block, rect_top, rect_right - (LONG)between_distence_block, rect_bottom);
	Print_point(backDC, str2, rect_left, rect_top, rect_right, rect_bottom);
	Print_point(backDC, str3, rect_left + (LONG)between_distence_block, rect_top, rect_right + (LONG)between_distence_block, rect_bottom);
	//�߰� ���� ���
	Print_point(backDC, str_bonus, Bonus_x, Bonus_y, Bonus_x + Bonus_Sx, Bonus_y + Bonus_Sy);
	Print_point(backDC, str_score, Score_x, Score_y, Score_x + Score_Sx, Score_y + Score_Sy);
	Print_point(backDC, str_life, Score_x, Score_y-30.0f, Score_x + Score_Sx, Score_y + Score_Sy);
}

bool Play_Interface::Update(float deltatime, int speed, float distance, int score, bool win)
{
	if (!win)
	{
	
		bonus_score -= deltatime;
		save_bonus_score = bonus_score;
		//bminterface[1]�� �÷��̾��� ����� ������ ����
		distence_x -= speed * deltatime;

		if (distance <= 0.0f) { distence_x = start_distence_x; distance_index = start_distance_index; }
		else if (distance < move_change_point)
		{
			//���� ������ �ݺ�
			if (distence_x <= -between_distence_block) { distence_x += between_distence_block; distance_check -= between_distence_block; distance_index -= 10; }
			else if (distence_x > between_distence_block) { distence_x -= between_distence_block; distance_check += between_distence_block; distance_index += 10; }
		}

		else if (distance >= move_change_point)
		{
			distence_x = end_x + (width * 0.6f);
			distance_index = 0;
		}
		this->score += score;
	}
	else
	{
		if (bonus_score > 100)
		{
			bonus_score -= 100;
			this->score += 100;
		}
		else if (bonus_score <= 100 && bonus_score > 10)
		{
			bonus_score -= 10;
			this->score += 10;
		}
		else if (bonus_score <= 10 && bonus_score > 0)
		{
			bonus_score -= deltatime;
			this->score += 1;
		}
		else if (bonus_score == 0)
		{
			if (GetAsyncKeyState(VK_HOME) & 0x8000)
				return true;
		}
	}
	
	//���� ������Ʈ
	str1 = std::to_wstring(distance_index + 10);
	str2 = std::to_wstring(distance_index);
	str3 = std::to_wstring(distance_index - 10);

	//�߰����� ������Ʈ
	str_bonus = L"BONUS_SCORE : " + std::to_wstring(bonus_score);
	str_score = L"SCORE : " + std::to_wstring(this->score);
	str_life = L"life : " + std::to_wstring(this->life);
	return false;
}

//���� ǥ��
void Play_Interface::Print_point(HDC backDC, std::wstring m, int left, int top, int right, int bottom)
{
	RECT rect = { left, top, right, bottom };
	DrawText(backDC, m.c_str(), -1, &rect, DT_VCENTER | DT_CENTER);
}


void Play_Interface::Dead(int distance_index, float distance, int saveindex, int life)
{
	distence_x = distance;
	this->distance_index = ((distance_index+1 )- saveindex) *10;
	while (distence_x >= width) { distence_x -= width; }
	this->life = life;
	bonus_score = save_bonus_score;
}

void Play_Interface::Gameset(int life)
{
	this->life = life;
	bonus_score = 10000;
	save_bonus_score = 0;
	this->score = 0;
}

