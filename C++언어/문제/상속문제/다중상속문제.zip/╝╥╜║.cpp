#include"Student.h"

void main()
{
	Student s;
	s.Input();
	s.Output();
}