#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include <time.h>
#include <conio.h>
#include <list>

#define MOVE_FASTMODE 32


enum TIME
{
	TIME_CREATE_NEWCAR = 4500,
	TIME_NORMALMODE_MOVE = 300,
	TIME_FASTMODE_MOVE = 50
};



