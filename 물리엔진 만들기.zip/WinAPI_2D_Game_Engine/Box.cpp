#include "Box.h"

void Box::Init(float x, float y, float width, float height, float d, bool fix)
{
	this->fix = fix;

	half_width = width * 0.5f;
	half_height = height * 0.5f;

	volume = width * height;

	position.x = x + half_width;
	position.y = y + half_height;

	mass = volume * d;



	if (0 < mass)invMass = 1 / mass;
	else invMass = 0;
	//�Է��ϴ� ���� �ƴ϶� �ۿ��� ����� ���� ��
	if (!fix)
		velocity = { 0, 0 };
}

void Box::Draw(HDC hdc)
{
	Rectangle(hdc , position.x - half_width, position.y - half_height,
		position.x + half_width, position.y + half_height);
}
