#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;
#define TRUE 1
#define YES 1
#define NO 2

class Employee
{
public:
	void Employee_Print(int day, int time = 8, int salary = 7500);
	void Employee_Salary();
	Employee();
	~Employee();
};
