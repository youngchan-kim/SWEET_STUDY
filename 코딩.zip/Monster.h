#pragma once
#include "Character.h"
class Monster : public Character
{
protected:
	string line1, line2, line3, line4;
public:
	Monster();
	void Load(ifstream& load, string name = "") override;
	void Infomation(int x, int y) override;
	inline string Monstername() { return m_strname; };
	inline int Gethealth() { return m_icurhealth; };
	inline float Atteck() { return m_idamage; };
	inline int Getexp() { return m_igetexp; };
	inline int GetGold() { return m_igold; };
	void Curhealth(int hp);
	~Monster();
};

