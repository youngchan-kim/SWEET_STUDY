#pragma once
#include "Character.h"
class Monster : public Character
{
private:
public:
	Monster();
	void Load(ifstream& load) override;
	void Infomation() override;
	~Monster();
};

