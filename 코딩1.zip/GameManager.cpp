#include "GameManager.h"

GameManager::GameManager()
{
	Start_x = 0;
	Start_y = 0;
	m_iWidth = 30;
	m_iHeight = 30;

	monstermanager.SetMonster();
}
void GameManager::OutLine()
{
	system("cls");
	mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
}
void GameManager::MainMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� DonGeonRPG �ڡ�", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("New Game", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Load Game", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Game Exit", m_iWidth, m_iHeight * 0.7f);

}
void GameManager::GameMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� Menu �ڡ�", m_iWidth, m_iHeight * 0.2f);
	mapdraw.DrawMidText("Dongeon", m_iWidth, m_iHeight * 0.3f);
	mapdraw.DrawMidText("Player Info", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("Monster Info", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Weapon Shop", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Save", m_iWidth, m_iHeight * 0.7f);
	mapdraw.DrawMidText("Exit", m_iWidth, m_iHeight * 0.8f);

}
void GameManager::DongeonMenu()
{
	OutLine();
	monstermanager.DongeonList(m_iWidth, 6);
	mapdraw.DrawMidText("���ư���", m_iWidth, 22);
}
void GameManager::PVE(int dongeonnum)
{
	OutLine();
	int player_x = m_iWidth, player_y = 4, monster_x = m_iWidth, monster_y = 24;

	player.Infomation(player_x, player_y);
	mapdraw.DrawMidText("--------------------------vs--------------------------", m_iWidth, m_iHeight * 0.5f);
	monstermanager.MonsterSelect(dongeonnum, monster_x, monster_y);
}
void GameManager::Dongeon()
{
	DongeonMenu();
	int select = mapdraw.MenuSelectCursor(7, 2, m_iWidth * 0.2f, 10);
	switch (select)
	{
	default:

		PVE(select);
	case 7:
		return;;
	}

}
void GameManager::Player_Info()
{
	player.Infomation(m_iWidth, m_iHeight *0.5f);
}
void GameManager::Monster_Info()
{
	monstermanager.MonsterList();
}

void GameManager::Weapon_Shop()
{
	/*int x, y;
	shop.ShopMenu();

	shop.ShopLsit(x, y);
	string weapon;
	string shop = " Shop";
	string line1;
	string line2;
	switch (mapdraw.MenuSelectCursor(7, 2, m_iWidth * 0.3f, m_iHeight * 0.45f))
	{
	case 1:
	{
		weapon = "Dagger";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);

		break;
	}
	case 2:
		weapon = "Gun";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);
		break;
	case 3:
		weapon = "Sword";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);
		break;
	case 4:
		weapon = "Wand";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);
		break;
	case 5:
		weapon = "Bow";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);
		break;
	case 6:
		weapon = "Hammer";
		line1 = "���� Gold : " + to_string(player.Gold());
		line2 = weapon + shop;
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.1f);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.2f);
		break;
	case 7:
		return;
	}*/
}

void GameManager::Save()
{
	

}

void GameManager::Playing()
{

	GameMenu();
	switch (mapdraw.MenuSelectCursor(6, 3, m_iWidth * 0.35f, m_iHeight * 0.3f))
	{
	case 1:
		Dongeon();
		break;
	case 2:
		OutLine();
		Player_Info();
		break;
	case 3:
		OutLine();
		Monster_Info();
		break;
	case 4:
		OutLine();
		Weapon_Shop();
		break;
	case 5:
		OutLine();
		Save();
		break;
	case 6:
		return;
	}

}

void GameManager::LoadSlot()
{
	string line[10] = {};
	float height = 0.25f, down = 0.05f;
	bool OX;
	for (int i = 0; i < 10; i++)
	{
		ifstream load;
		OX = false;
		char is_true;
		string playerlist = "SavePlayer" + to_string(i + 1) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			OX = true;
			load.close();
		}
		if (OX == true)
			is_true = 'O';
		else
			is_true = 'X';
		line[i] = to_string(i + 1) + "������ : (���Ͽ��� : " + is_true + ")";

		mapdraw.DrawMidText(line[i], m_iWidth, m_iHeight * (height += down));
	}
	mapdraw.DrawMidText("11.���ư���", m_iWidth, m_iHeight * 0.8f);
	
	int select = mapdraw.MenuSelectCursor(11, 2, m_iWidth * 0.35f, m_iHeight * 0.3f);
	if (select < 11)
	{
		ifstream load;
		string playerlist = "SavePlayer" + to_string(select) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			player.Load(load);
			load.close();
		}
		else
		{
			mapdraw.DrawMidText("�ش� ������ �����ϴ�.", m_iWidth, m_iHeight * 0.5f);
			system("pause");
		}
	}

}

void GameManager::Start()
{
	string name;
	ifstream load;
	MainMenu();
	int playing = mapdraw.MenuSelectCursor(3, 3, m_iWidth * 0.35f, m_iHeight * 0.5f);

	switch (playing)
	{
	case 1:
		OutLine();
		mapdraw.DrawMidText("Player �̸� �Է� : ", m_iWidth, m_iHeight * 0.5f);
		cin >> name;
		load.open("DefaultPlayer.txt");
		if (load.is_open())
		{
			player.Load(load, name);
			load.close();
		}
		Playing();
		break;
	case 2:
		OutLine();
		LoadSlot();
		Playing();
		break;
	case 3:
		break;
	default:
		break;
	}

}
GameManager::~GameManager() {}