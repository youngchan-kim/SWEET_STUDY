#pragma once
#include<vector>
#include"Model.h"
#include"Frustum.h"
#include "LOD.h"
enum Corner { TL = 0, TR, BL, BR};

struct QuadTreeNode
{
	int size;

	int center;
	int corners[4];

	bool isCulled;
	float radius;

	std::unique_ptr<QuadTreeNode> childs[4];
	QuadTreeNode* neighbors[4] = { 0 };
};
class QuadTree
{
private:
	int triangleCount, drawCount;
	ModelVertex* vertices;
	std::unique_ptr<QuadTreeNode> root;
	int rootSize;
	LOD* lod = nullptr;

public:
	void Initilize(ModelVertex* vertices, int cx, int cy);
	void ProcessFrustumCulling(class Frustum* frustum);
	std::vector<DWORD> GenerateIndices();
	void SetLOD(LOD* lod);

private:
	void Build(QuadTreeNode* node, int topLeft, int topRight, int bottomLeft, int bottomRight);
	void FrustumCulling(QuadTreeNode* node, class Frustum* frustum);
	void SetIndices(QuadTreeNode* node, std::vector<DWORD>& indices);
	void MakeUpIndices(QuadTreeNode* node, std::vector<DWORD>& indices);
	void MakeUpIndicesToLOD(QuadTreeNode* node, std::vector<DWORD>& indices);
	void BuildNeighbor(QuadTreeNode* node);
	QuadTreeNode* FindNeighborNode(Neighbor pos, int topLeft, int topRight, int bottomLeft, int bottomRight);
	QuadTreeNode* FindNode(QuadTreeNode* node, POINT center, const int& topLeft, const int& topRight, const int& bottomLeft, const int&
		bottomRight);

};

