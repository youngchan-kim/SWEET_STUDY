#pragma once
#include "Mecro.h"
#include "TimerClass.h"

#define MAX_DESTANCE 80

enum POSITION
{
	POSITION_DEFAULT_X = 10,
	POSITION_DEFAULT_Y = 10
};

enum CARPART
{
	CARPART_HEAD,
	CARPART_BODY,
	CARPART_WHEEL
};

typedef struct CarShape
{
	std::string Head;
	std::string Body;
	std::string Wheel;
}CarShape;

class CarClass
{
private:
	int m_ix;
	int m_iy;

	bool m_bCreateFlag;
	bool m_bFinishFlag;
	bool m_bFastModeFlag;

	TimerClass Timer;
	CarShape Car_Character;
	
public:
	CarClass();
	void Set_ModeChange();
	bool Move_Car();
	void Draw_Car(CarShape Car_Character, int x, int y);
	void Erease_Car(CarShape Car_Character, int x, int y);

	inline bool Get_m_iFinish()
	{
		return m_bFinishFlag;
	}

	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~CarClass();
};
