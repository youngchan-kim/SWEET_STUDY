#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Weapon.h"
#include <map>
#include <vector>

class Shop : public Weapon
{
private:
	MapDraw mapdraw;
	map<string, vector<Weapon*>> _map;

	//�ʰ� ���͸� ���� �� ��
public:
	Shop();
	void ShopMenu();
	void Load();
	void ShopLsit(int x ,int y);
	void SetWeapon();
	~Shop();
};

