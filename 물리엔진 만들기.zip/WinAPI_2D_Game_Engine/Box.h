#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>
#include "Object.h"
class Box : public Object
{
private:
	float half_width, half_height;
	float volume;
	float mass;
	float invMass;
	bool fix;
	//Vector2 position;
	//Vector2 velocity;
public:
	void Init(float x, float y, float width, float height, float d, bool fix);
	//void Update();
	void Draw(HDC hdc);
	float GetVolume() { return volume; }
	float GetMass() { return mass; }
	float GetInvMass()	{return invMass;}
	float GetHalf_Width() { return half_width; }
	float GetHalf_Height() { return half_height; }

	//Vector2 GetPosition() { return object->GetPosition(); }
	//Vector2 GetVelocity() { return object->GetVelocity(); }
	//void Add_Gravity(Vector2 gravityvelocity) { object->Add_Gravity(gravityvelocity);}
	//��ü�� ���� ������ �ӵ�
	//void Add_Velocity(Vector2 addvelocity) { object->Add_Velocity(addvelocity);}
	
};

