#pragma once
#include"Mecro.h"

class MapDraw
{
public:
	static void CarDraw(int cardrawstart_x, int cardrawstart_y, int carwidth, int carheight)
	{
		for (int y = 0; y < carheight; y++)
		{
			gotoxy(cardrawstart_x, cardrawstart_y + y);
			if (y == 0)
			{
				cout << "  ";
				for (int x = 0; x < carwidth - 1; x++)
					if (x == 1)
						cout << "��";
					else if (x >= 1 && x < carwidth - 2)
						cout << "��";
					else if (x == carwidth - 2)
						cout << "��";
				cout << "  " << endl;
			}
			else if (y == carheight - 2)
			{
				cout << "��";
				for (int x = 1; x < carwidth - 1; x++)
					if (x == 1)
						cout << "��";
					else if (x >= 1 && x < carwidth - 2)
						cout << "��";
					else if (x == carwidth - 2)
						cout << "��";
					cout << "��" << endl;
			}
			else
			{
				cout << "��";
				for (int x = 1; x < carwidth - 1; x++)
					if (x == 1)
						cout << "��";
					else if (x >= 1 && x < carwidth - 2)
						cout << "��";
					else if (x == carwidth - 2)
						cout << "��";
					cout << "��";
			}
		}
		return;
	}
	static void CarErase(int cardrawstart_x, int cardrawstart_y, int carwidth, int carheight)
	{
		for (int y = 0; y < carheight; y++)
		{
			gotoxy(cardrawstart_x, cardrawstart_y + y);
			if (y == 0)
			{
				cout << "  ";
				for (int x = 0; x < carwidth - 1; x++)
					if (x == 1)
						cout << "  ";
					else if (x >= 1 && x < carwidth - 2)
						cout << "  ";
					else if (x == carwidth - 2)
						cout << "  ";
				cout << "  " << endl;
			}
			else if (y == carheight - 2)
			{
				cout << "  ";
				for (int x = 1; x < carwidth - 1; x++)
					if (x == 1)
						cout << "  ";
					else if (x >= 1 && x < carwidth - 2)
						cout << "  ";
					else if (x == carwidth - 2)
						cout << "  ";
				cout << "  " << endl;
			}
			else
			{
				cout << "  ";
				for (int x = 1; x < carwidth - 1; x++)
					if (x == 1)
						cout << "  ";
					else if (x >= 1 && x < carwidth - 2)
						cout << "  ";
					else if (x == carwidth - 2)
						cout << "  ";
				cout << "  ";
			}
		}
		return;
	}
	static void DrawPoint(string str, int x, int y)
	{
		gotoxy(x*2, y);
		cout << str;
		gotoxy(-1, -1);
		return;
	}
	static void DrawMidText(string str, int x, int y)
	{
		if (x > str.size() / 2)
			x -= str.size() / 2;
		gotoxy(x, y);
		cout << str;
		return;
	}
	static void ErasePoint( int x, int y)
	{
		gotoxy(x, y);
		cout << "  ";
		gotoxy(-1, -1);
		return;
	}
	MapDraw() {}
	static inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~MapDraw() {}
};

