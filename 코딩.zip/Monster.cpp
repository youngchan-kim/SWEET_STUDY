#include "Monster.h"
Monster::Monster() {}

void Monster::Load(ifstream& load)
{
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	m_icurhealth = m_imaxhealth;
	m_iexp = MOSTEREXP;

	//ifstream load;
	//load.open("DefaultMonster.txt");
	//if (load.is_open())
	//{
	//	if (!load.eof()) // �ϼ�
	//	{
	//		load >> monsterlist;
	//		for (int i = 0; i < monsterlist; i++)
	//		{
	//			load >> m_idamage;
	//			load >> m_imaxhealth;
	//			load >> m_imaxexp;
	//			load >> m_igetexp;
	//			load >> m_iLv;
	//			load >> m_igold;
	//			m_icurhealth = m_imaxhealth;
	//			m_iexp = MOSTEREXP;
	//		}
	//	}
	//	load.close();
	//}
}
void Monster::Infomation()
{
	int m_iWidth = 30;
	int m_iHeight = 34;
	string line1, line2, line3, line4;
	for (int i = 0; i < monsterlist; i++) 
	{

		line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
		line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
		line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
		line4 = "Gold = " + to_string(m_igold);
		mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.2f + i);
		mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.25f + i);
		mapdraw.DrawMidText(line3, m_iWidth, m_iHeight * 0.3f + i);
		mapdraw.DrawMidText(line4, m_iWidth, m_iHeight * 0.35f + i);
	}

}
Monster::~Monster() {}