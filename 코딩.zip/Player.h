#pragma once
#include "Character.h"
#include "Weapon.h"
#define UPATTACKSTAT 4

class Player : public Character
{
private:
	Weapon* weapon;
public:
	Player();
	virtual int Atteck() override { return m_idamage + ((NULL != weapon) ? weapon->Damage() : 0); } //���׿����� 

	void Load(ifstream& load, string name = "") override;
	void Save(ofstream& save);
	void Infomation(int x, int y) override;
	void Levelup();
	void GetWinner(int exp, int gold);
	void WeaponBuy(Weapon* weaponwear);
	~Player();
};

