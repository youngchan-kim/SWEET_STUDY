#include "Monster.h"
Monster::Monster() {}

void Monster::Load(ifstream& load, string name)
{
	load >> m_strname;
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	m_icurhealth = m_imaxhealth;
	m_iexp = MOSTEREXP;

}
void Monster::Infomation()
{
	int m_iWidth = 30;
	int m_iHeight = 30;
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	mapdraw.DrawMidText(line1, m_iWidth, m_iHeight * 0.2f);
	mapdraw.DrawMidText(line2, m_iWidth, m_iHeight * 0.25f);
	mapdraw.DrawMidText(line3, m_iWidth, m_iHeight * 0.3f);
	mapdraw.DrawMidText(line4, m_iWidth, m_iHeight * 0.35f);

}
Monster::~Monster() {}