#include "Play_Interface.h"

Play_Interface::Play_Interface()
{
	bminterface = new BitMap * [INTERFACE_3];
}

Play_Interface::~Play_Interface()
{
	if (bminterface != NULL) { delete[] bminterface; bminterface = NULL; }
}

void Play_Interface::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	for (int i = 0; i < INTERFACE_3; i++)  bminterface[i] = BMMger->GetGameInterface((GAMEINTERFACE)(i));
}

void Play_Interface::Draw(HDC backDC)
{

}
void Play_Interface::Update(float deltatime)
{

}
