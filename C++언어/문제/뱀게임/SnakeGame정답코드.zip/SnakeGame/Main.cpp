#include"GameManager.h"

void main()
{
	GameManager gameManager;
	gameManager.MainLoop();
}