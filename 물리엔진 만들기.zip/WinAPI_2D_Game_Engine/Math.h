#include <cmath>

#ifndef ENGINE_MATH_H
#define ENGINE_MATH_H

//namespace ENGINE
//{
	struct Vector2
	{
		float x, y;

		Vector2() : x(0), y(0) {}
		Vector2(float x, float y) : x(x), y(y) {}

		Vector2 operator-() const { return Vector2(-x, -y);  /* ���� ���� �ϱ� */ }// int a; -a;

		Vector2 operator*(const float& value) const { return Vector2(x * value, y * value);/* ���� ���� �ϱ� */ }
		Vector2 operator/(const float& value) const { return Vector2(x / value, y / value);/* ���� ���� �ϱ� */ }
		Vector2 operator*=(const float& value) { return Vector2(x *= value, y *= value);/* ���� ���� �ϱ� */ }
		Vector2 operator/=(const float& value) { return Vector2(x /= value, y /= value); /* ���� ���� �ϱ� */ }
		// a /= 1
		Vector2 operator+(const Vector2& v) const 
		{ 
			return Vector2(x + v.x, y + v.y); /* ���� ���� �ϱ� */
		}
		Vector2 operator-(const Vector2& v) const { return Vector2(x - v.x, y - v.y);/* ���� ���� �ϱ� */ }
		Vector2 operator+=(const Vector2& v) { return Vector2(x += v.x, y += v.y); /* ���� ���� �ϱ� */ }
		Vector2 operator-=(const Vector2& v) { return Vector2(x -= v.x, y -= v.y);/* ���� ���� �ϱ� */ }

	    float SqrMagnitude()const{	return (x * x) + (y * y);}

		float Magnitude() {	 return sqrt(SqrMagnitude());}

		void Normalize() 
		{
			float magnitude = Magnitude();

			if (0.0f < magnitude) // if(0 < magnitude)
			{
				float invMagnitude = 1.0f / magnitude;
				x *= invMagnitude;
				y *= invMagnitude;
			}
		}
	};

	inline bool operator== (const Vector2& lhs, const Vector2& rhs) {/* ���� ���� �ϱ� */
		if (lhs.x == rhs.x && lhs.y == rhs.y)
			return true;
		else 
			return false;
		
	}
	inline bool operator!= (const Vector2& lhs, const Vector2& rhs) { /* ���� ���� �ϱ� */
		if (lhs.x == rhs.x && lhs.y == rhs.y)
			return false;
		else
			return true;
		 
	}

	
	const float Epsilon = 0.0001f;

	inline bool Equal(float lhs, float rhs) { return (std::abs(lhs - rhs) <= Epsilon); }
	inline float Dot(const Vector2& lhs, const Vector2& rhs) { return lhs.x * rhs.x + lhs.y * rhs.y; }

#ifndef clamp
#define clamp(v, a, b) (a < b) ? min(max(v, a), b) : min(max(v, b), a)
#endif // !clamp
namespace ENGINE
{
	int Repeat(int value, const int& max);
}

#endif // !ENGINE_MATH_H