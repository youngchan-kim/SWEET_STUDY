#include "Template.h"

void main()
{
	Template tem;

	auto a = 0;
	auto b = 0;
	auto c = 0;
	std::cin >> a >> b >> c;
	Number(a, b, c);
}