#include "Circle.h"

void Circle::Init(float x, float y, float radius)
{
	this->x = x;
	this->y = y;
	this->radius = radius;

	position.x = this->x + radius;
	position.y = this->y + radius;
}

void Circle::Update()
{
}

void Circle::Draw()
{

}


