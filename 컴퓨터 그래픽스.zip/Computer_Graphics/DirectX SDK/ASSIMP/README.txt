*.dll 파일은 반드시 실행파일(*.exe)과 같은 폴더에 포함

*.lib와 *.dll은 프랫폼(x64,x86)/구성(Debug,Release)에 상관없이 사용해도 된다