#pragma once
#include<iostream>
using namespace std;

class Manager
{
private:
	int m_isum = 0;

public:
	void Sum(int num01, int num02);
	Manager();
	Manager(int num01);
	Manager(int num01, int num02);

	~Manager();
};


