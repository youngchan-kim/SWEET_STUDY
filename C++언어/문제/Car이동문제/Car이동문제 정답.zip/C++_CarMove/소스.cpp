#include "Mecro.h"
#include "Manager.h"

void main()
{
	Manager manager;
	manager.PlayLoop();
}