﻿// WinAPI.cpp : 애플리케이션에 대한 진입점을 정의합니다.
//
#pragma comment(lib, "msimg32.lib")  
#include "framework.h"
#include "WinAPI.h"
#include <iostream>
#define MAX_LOADSTRING 100

// 전역 변수:
HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINAPI, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }
    MSG msg;

    // 기본 메시지 루프입니다:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW /*더블클릭사용 알리기*/ | CS_DBLCLKS;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINAPI));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = 0;// MAKEINTRESOURCEW(IDC_WINAPI);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_SYSMENU | WS_MINIMIZEBOX,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

TCHAR str[256]; //전역 변수
/*타이머_전역 변수
char g_buf[256];//전역 변수
*/
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    /*타이머_지역변수
    SYSTEMTIME time;//지역변수
    */
    //static int x = 0;
    //static int y = 0;
    switch (message)
    {
    /*
        input 키보드 입력을 받았을 경우 발생
        wParam : 입력한 문자를 알아온다.
       
    case WM_CHAR:
        {
            int len = lstrlen(str);
            str[len] = (TCHAR)wParam;
            str[len + 1] = 0;
            HDC hdc = GetDC(hWnd);
            TextOut(hdc, 100, 100, str, lstrlen(str));
            ReleaseDC(hWnd, hdc);
        }
    break;
     */

    /*

        WM_CHAR 처럼 키보드를 입력 받았을 경우 발생
        wParam : 문자가 아닌 카상키 코드를 알려 준다.
       누를때 전송된다.
    case WM_KEYDOWN:
        switch (wParam) {
        case VK_LEFT:
            x -= 8;
            break;
        case VK_UP:
            y -= 8;
            break;
        case VK_RIGHT:
            x += 8;
            break;
        case VK_DOWN:
            y += 8;
            break;
        }
        InvalidateRect(hWnd, NULL, TRUE);

        * WM_PAINT에 적을 내용
        TextOut(hdc, x, y, L"A", 1);
   */

    /*마우스 좌표 출력하기_INTPUT
    case WM_MOUSEMOVE:
        x = LOWORD(lParam);
        y = HIWORD(lParam);
        InvalidateRect(hWnd, NULL, TRUE);
        break;*/

    /*타이머_INPUT
    case WM_CREATE: SetTimer(hWnd, 1, 1000, NULL); break;
    case WM_TIMER:
        switch (wParam)
        {
        case 1:
            GetLocalTime(&time);
            sprintf_s(g_buf, "%d년 %d월 %d일 %d시 %d분 %d초", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond);
            InvalidateRect(hWnd, NULL, true);
            break;
        }
        break;
        */

    /*메시지 박스
    case WM_LBUTTONDBLCLK:
        if (MessageBox(hWnd, L"내용", L"제목", MB_OK) == IDOK)
        {
            // 수행할 내용.
        }
        break;
    */
    
    
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: 여기에 hdc를 사용하는 그리기 코드를 추가합니다...
            
            /*
            //문자 출력
            //TextOut()을 이용하여 문자 출력
            std::wstring str = L"TEST test TEST";
            TextOut(hdc, 10, 10, str.c_str(), str.length());

            //DrawText()를 이용하여 문자 출력.
            str = L"TEST test TEST test TEST test TEST test TEST test TEST test TEST test TEST";
            RECT rect = { 100, 100, 400, 300 };
            DrawText(hdc, str.c_str(), -1, &rect, DT_CENTER | DT_WORDBREAK);
            */

            /*그래픽 출력
            //SetPixel()로 붉은 점 찍기
            for (int i = 0; 10 > i; i++)SetPixel(hdc, 10 + 10 * i, 10, RGB(255, 0, 0));

            //MoveToEx()와 LineTo()를 이용하여 선 긋기.
            MoveToEx(hdc, 10, 60, NULL);
            LineTo(hdc, 100, 20);

            //Rectangle()을 이용하여 사각형 그리기.
            Rectangle(hdc, 10, 100, 100, 150);

            //Ellipse()를 이용하여 타원 그리기.
            Ellipse(hdc, 10, 160, 100, 210);
            */

            /*마우스 좌표 출력하기_OUTPUT
           wsprintf(str, TEXT("마우스 X 좌표 = %d, 마우스 Y 좌표 = %d"), x, y);
           TextOut(hdc, 10, 30, str,lstrlen(str));
           */

            /*타이머_OUTPUT
            TextOutA(hdc, 10, 10, g_buf, strlen(g_buf));
            */

            /*이미지
            HDC memDC = CreateCompatibleDC(hdc);
            HBITMAP myBitmap = (HBITMAP)LoadImage(NULL, L"00.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
            auto OldBitmap = (HBITMAP)SelectObject(memDC, myBitmap);

            BitBlt(hdc, 0, 0, 145, 245, memDC, 0, 0, SRCCOPY);

            StretchBlt(hdc, 200, 200, 245, 345, memDC, 0, 0, 145, 245, SRCCOPY);
            SelectObject(memDC, OldBitmap);
            DeleteObject(myBitmap);
            DeleteDC(memDC);
            */

            /*투명 처리
            #pragma comment(lib, "msimg32.lib")  
            TransparentBlt() 함스를 사용하기 위해서는,
            // 해당 라이브러리를 추가하여야 한다.
            */
            HDC memDC = CreateCompatibleDC(hdc);
            HBITMAP myBitmap = (HBITMAP)LoadImage(NULL, L"block_w_00.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
            auto OldBitmap = (HBITMAP)SelectObject(memDC, myBitmap);

            TransparentBlt(hdc, 200, 200, 145, 145, memDC, 0, 0, 125, 125, RGB(255, 0, 255));
            BitBlt(hdc, 0, 0, 145, 245, memDC, 0, 0, SRCCOPY);
            SelectObject(memDC, OldBitmap);
            DeleteObject(myBitmap);
            DeleteDC(memDC);
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        /*타이머 파괴 함수
        KillTimer(hWnd, 1);
        */
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
/*
BOOL TextOut(HDC hdc, int x, int y, LPCWSTR IpString, int c)

int DrawText(HDC hDC, LPCWSTR IpString, int nCount, LPRECT IpRext, UINT uFormat)
*/