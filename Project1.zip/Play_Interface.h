#pragma once
#include "BitMapManager.h"


class Play_Interface
{
private:
	BitMap** bminterface;
	int width, height;
public:
	Play_Interface();
	~Play_Interface();
	void Init(int width, int height);
	void Draw(HDC backDC);
	void Update(float deltatime);

};

