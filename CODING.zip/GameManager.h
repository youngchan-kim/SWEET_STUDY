#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Character.h"
class GameManager
{
private:
	int m_iWidth;
	int m_iHeight;
	int Start_x;
	int Start_y;
	MapDraw mapdraw;
	Character character;
public:
	void MainMenu();
	void Playing();
	void GameMenu();
	void Dongeon();
	void Player_Info();
	void Monster_Info();
	void Weapon_Shop();
	void Save();
	GameManager();
	~GameManager();
};

