#pragma once
#include "BitMapManager.h"


class Play_Goal
{
private:
	BitMap** bmgoal;
	int width, height;
	float m_fGoal_Width, m_fGoal_height;
	float m_fGoal_x, m_fGoal_y, m_startGoal_x;
	float dont_move_point, end_x;
	RECT goal_rect;

public:
	Play_Goal();
	~Play_Goal();
	void Init(int width, int height, float dont_move_point);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed, float distance);
	void Dead();
	RECT Goal_Rect() { return goal_rect; }
};
