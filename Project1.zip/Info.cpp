#include "Info.h"

Info::Info(){}
void Info::Infomation()
{
	cout << "======" << m_strname << "(" << m_iLv << "Lv)" << "======";
	cout << "���ݷ� = " << m_idamage;
	cout << "������ = " << m_icurhealth << "/" << m_imaxhealth;
	cout << "����ġ = " << m_iexp << "/" << m_imaxexp;
	cout << "GetEXP : " << m_igetexp;
	cout << "Gold = " << m_igold;
}

Info::~Info() {}