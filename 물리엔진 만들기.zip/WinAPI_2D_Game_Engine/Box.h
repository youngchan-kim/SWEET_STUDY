#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>
class Box
{
public:
	Vector2 position;
	float g = 5;
	float gravity;
	float right, left, bottom, top;
	float half_width, half_height;
public:
	void Init(float right, float left, float bottom, float top);
	void Update(const FLOAT& deltaTime);
	void Draw(HDC hdc);
};

