#include "Monster.h"
Monster::Monster() {}

void Monster::Load(ifstream& load, string name)
{
	load >> m_strname;
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	m_icurhealth = m_imaxhealth;
	m_iexp = MOSTEREXP;

}
void Monster::Infomation(int x, int y)
{
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	mapdraw.DrawMidText(line1, x, y);
	mapdraw.TextDraw(line2, x * 0.5f, y+1);
	mapdraw.TextDraw(line3, x * 0.5f, y+2);
	mapdraw.TextDraw(line4, x * 0.5f, y+3);

}
Monster::~Monster() {}