#include "Object.h"

void Object::Init(bool Cycle, bool Fix, float x, float y, float Width, float Height)
{
	this->x = x, this->y = y, this->Width = Width, this->Height = Height;
	switch (Cycle)
	{
	case true:

		break;

	case false:
		switch (Fix)
		{
		case true:

			break;

		case false:

			break;
		}
		break;
	}


}


void Object::Update(float move_x, float move_y)
{
	y+= move_x
	//	x,	y,	Width,	Height
}

void Object::Draw()
{

}
