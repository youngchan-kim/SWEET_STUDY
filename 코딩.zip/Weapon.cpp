#include "Weapon.h"

Weapon::Weapon(){}

void Weapon::Load(ifstream& load)
{
	load >> m_strname;
	load >> m_idamage;
	load >> m_iprice;
}

void Weapon::WeaponInfo(int x, int y)
{
	//string line1 = "���� : " + to_string(m_iprice) + " ����Ÿ�� : " + m_strweapontype; 
	string line2 = "�����̸� : " + m_strname + " ���ݷ� : " + to_string((int)m_idamage);
	//mapdraw.DrawMidText(line1, x, y);
	mapdraw.DrawMidText(line2, x, y);
}
void Weapon::Save(ofstream& save)
{
	save << m_strweapontype << " ";
	save << m_strname << " ";
	save << m_idamage << " ";
	save << m_iprice << endl;
}

Weapon::~Weapon() {}


Bow::Bow() { m_strweapontype = "Bow"; }
float Bow::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 11)
	{
		all_damage = playerdamage + (m_idamage * 10);
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 10) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
}

Bow::~Bow() {}


Dagger::Dagger() { m_strweapontype = "Dagger"; }
float Dagger::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 21)
	{
		all_damage = playerdamage + ((m_idamage * 5) * 2);
		string line1 = "ũ��Ƽ�ü�!!(Damage : " + to_string((m_idamage * 5) * 2) + ")";
		/*mapdraw.DrawMidText(line1, x, y);*/
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
}
Dagger::~Dagger() {}


Gun::Gun() { m_strweapontype = "Gun"; }
float Gun::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 51)
	{
		all_damage = playerdamage + (m_idamage * 2);
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 2) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
}
Gun::~Gun() {}


Sword::Sword() { m_strweapontype = "Sword"; }
float Sword::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 31)
	{
		all_damage = playerdamage + ((m_idamage * 1.5) * 3);
		string line1 = "�˱�!!(Damage : " + to_string(m_idamage * 1.5) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		/*mapdraw.DrawMidText(line1, x, y);*/
		return all_damage;
	}
}
Sword::~Sword() {}


Wand::Wand() { m_strweapontype = "Wand"; }
float Wand::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 6)
	{
		all_damage = playerdamage + (m_idamage * 1000);
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 1000) + ")";
		/*mapdraw.DrawMidText(line1, x, y);*/
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
}
Wand::~Wand() {}


Hammer::Hammer() { m_strweapontype = "Hammer"; }
float Hammer::Atteck(float playerdamage)
{
	int x, y;
	float all_damage = 0;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance > 51)
	{
		all_damage = playerdamage + (m_idamage * 1.2);
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 1.2) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
	else
	{
		all_damage = playerdamage + m_idamage;
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		//mapdraw.DrawMidText(line1, x, y);
		return all_damage;
	}
}
Hammer::~Hammer() {}
