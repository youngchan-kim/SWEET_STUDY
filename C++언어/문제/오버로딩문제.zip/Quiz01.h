#pragma once
#include<iostream>
#include<string>
using namespace std;
#define TRUE 1
class Quiz01
{
private:
	int m_inum01, m_inum02;
	int m_isum = 1;
	char m_chch;
public:
	void Quiz1(int num01, int num02);
	void Quiz1(char char01, int num01);
	Quiz01();
	~Quiz01();
};