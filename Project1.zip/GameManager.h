#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Player.h"
class GameManager
{
private:
	int m_iWidth;
	int m_iHeight;
	int Start_x;
	int Start_y;
	MapDraw mapdraw;
	Player player;
public:
	void MainMenu();
	void Playing();
	void GameMenu();

	GameManager();
	~GameManager();
};

