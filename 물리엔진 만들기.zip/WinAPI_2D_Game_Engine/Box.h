#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>
class Box
{
private:
	float x, y, width, height;
	float half_width, half_height;
	float volume;
	float mass;
	float invMass;
	bool fix;

	Vector2 position;
	Vector2 velocity;
public:
	void Init(float x, float y, float width, float height, float d, bool fix);
	void Update();
	void Draw(HDC hdc);
	float GetVolume() { return volume; }
	float GetMass() { return mass; }
	float GetInvMass()
	{
		return invMass;
	}
	float GetHalf_Width() { return half_width; }
	float GetHalf_Height() { return half_height; }

	Vector2 GetPosition() { return position; }
	Vector2 GetVelocity() { return velocity; }
	void Add_Gravity(Vector2 gravityvelocity) { if (!fix)velocity += gravityvelocity; }
	//��ü�� ���� ������ �ӵ�
	void Add_Velocity(Vector2 addvelocity) { if (!fix)velocity += addvelocity; }
	
};

