#pragma once
#include "Info.h"
class Player : public Info
{
private:

public:
	void NewPlayer(string m_strname);
	Player();
	~Player();
};

