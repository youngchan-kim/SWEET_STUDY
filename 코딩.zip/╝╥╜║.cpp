#include "GameManager.h"

void main()
{
	GameManager g;
	g.Start();
}