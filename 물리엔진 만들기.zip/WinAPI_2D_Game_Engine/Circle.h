#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>


//���� �׸��� ���� �߽� ��

class Circle
{
public:
	float g = 5;
	float gravity = 0;
	float radius = 0;
	Vector2 position;
public:
	void Init(float x, float y, float radius);
	void Update(const FLOAT& deltaTime);
	void Draw(HDC hdc);
	
};

