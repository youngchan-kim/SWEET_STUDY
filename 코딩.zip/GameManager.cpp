#include "GameManager.h"

GameManager::GameManager()
{
	monstermanager.SetMonster();
	shop.Load();
}
void GameManager::OutLine()
{
	system("cls");
	mapdraw.BoxDraw(START_X, START_Y, WIDTH, HEIGHT);
}
void GameManager::MainMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� DonGeonRPG �ڡ�", WIDTH, HEIGHT * 0.4f);
	mapdraw.DrawMidText("New Game", WIDTH, HEIGHT * 0.5f);
	mapdraw.DrawMidText("Load Game", WIDTH, HEIGHT * 0.6f);
	mapdraw.DrawMidText("Game Exit", WIDTH, HEIGHT * 0.7f);

}
void GameManager::GameMenu()
{
	OutLine();
	mapdraw.DrawMidText("�١� Menu �ڡ�", WIDTH, HEIGHT * 0.2f);
	mapdraw.DrawMidText("Dongeon", WIDTH, HEIGHT * 0.3f);
	mapdraw.DrawMidText("Player Info", WIDTH, HEIGHT * 0.4f);
	mapdraw.DrawMidText("Monster Info", WIDTH, HEIGHT * 0.5f);
	mapdraw.DrawMidText("Weapon Shop", WIDTH, HEIGHT * 0.6f);
	mapdraw.DrawMidText("Save", WIDTH, HEIGHT * 0.7f);
	mapdraw.DrawMidText("Exit", WIDTH, HEIGHT * 0.8f);

}
void GameManager::DongeonMenu()
{
	OutLine();
	monstermanager.DongeonList(WIDTH, 6);
	mapdraw.DrawMidText("���ư���", WIDTH, 22);
}

void GameManager::PVE(int dongeonnum)
{
	OutLine();
	int player_y = 4, monster_y = 24, player_rsp_y = 10 , monster_rsp_y = 20, result_rsp_y = 12;

	string Rock = "Rock" , Paper = "Paper", Scissor = "Scissor";

	string Monsterstate;
	int iselect = 0, iresult = 0, icom = 0;
	string strresult = "", str_allreslut = "";
	player.Infomation(WIDTH, player_y);
	mapdraw.DrawMidText("1.����   2.����   3.��", WIDTH, player_rsp_y);
	mapdraw.DrawMidText("--------------------------vs--------------------------", WIDTH, HEIGHT * 0.5f);
	monstermanager.MonsterSelect(dongeonnum, WIDTH, monster_y);

	srand((unsigned)time(NULL));
	// 1. ��ư ���� �� ���� ������ ������������ �缳���Ǿߵ� 

	iselect = _getch();
	icom = ((rand() % 3) + 1);
	iselect -= 48;
	iresult = iselect - icom;

	if (icom == 1)
		mapdraw.DrawMidText("����!!", WIDTH, monster_rsp_y);
	else if (icom == 2)
		mapdraw.DrawMidText("����!!", WIDTH, monster_rsp_y);
	else if (icom == 3)
		mapdraw.DrawMidText("��!!", WIDTH, monster_rsp_y);

	if (iselect == 1)
		strresult = "����";
	else if (iselect == 2)
		strresult = "����";
	else
		strresult = "��";


	if (0 == iresult)
	{
		str_allreslut = strresult + "(���º�!!)";
		mapdraw.DrawMidText(str_allreslut, WIDTH, result_rsp_y);
	}
	else if (-2 == iresult || 1 == iresult)
	{
		str_allreslut = strresult + "(�¸�!!)";
		mapdraw.DrawMidText(str_allreslut, WIDTH, result_rsp_y);
		monstermanager.MonsterCurhealth(player.Atteck());
	}
	else
	{
		str_allreslut = strresult + "(�й�!!)";
		mapdraw.DrawMidText(str_allreslut, WIDTH, result_rsp_y);
		player.Curhealth(monstermanager.MonsterAtteck());
	}

	if (monstermanager.MonsterHP() <= 0)
	{
		mapdraw.DrawMidText("Player �¸�!!", WIDTH, player_y);
		player.GetWinner(monstermanager.MonsterGetexp(), monstermanager.MonsterGetgold());
	}
	else if (player.Gethealth() <= 0)
	{
		life = false;
		return;
	}
}
void GameManager::Dongeon()
{
	if (life = true)
	{
		DongeonMenu();
		int select = mapdraw.MenuSelectCursor(7, 2, WIDTH * 0.2f, 10);
		switch (select)
		{
		default:
			PVE(select);
		case 7:
			return;
		}
	}
	else
		return;

}
void GameManager::Player_Info()
{
	player.Infomation(WIDTH, HEIGHT *0.5f);
}
void GameManager::Monster_Info()
{
	monstermanager.MonsterList();
}

void GameManager::Weapon_Shop()
{
	shop.ShopMenu(WIDTH, &player); //���� Ÿ���� �ҷ���
}

void GameManager::Save()
{
	while (TRUE)
	{
		string line[10] = {};
		bool OX;
		int i = 0;
		mapdraw.DrawMidText("SAVE", WIDTH, SUBTITLE_START_Y + (i++ * LIST_SPACE));
		for (i; i <= 10; i++)
		{
			ifstream load;
			OX = false;
			char is_true;
			string playerlist = "SavePlayer" + to_string(i) + ".txt";
			load.open(playerlist);
			if (load.is_open())
			{
				OX = true;
				load.close();
			}
			if (OX == true)
				is_true = 'O';
			else
				is_true = 'X';
			line[i-1] = to_string(i) + "������ : (���Ͽ��� : " + is_true + ")";

			mapdraw.DrawMidText(line[i-1], WIDTH, SUBTITLE_START_Y+(i * LIST_SPACE));
		}
		mapdraw.DrawMidText("11.���ư���", WIDTH, SUBTITLE_START_Y+(i * LIST_SPACE));

		int select = mapdraw.MenuSelectCursor(11, 2, WIDTH * 0.1f, SUBTITLE_START_Y + (LIST_SPACE));
		if (select < 11)
		{
			ofstream save;
			string playerlist = "SavePlayer" + to_string(select) + ".txt";
			save.open(playerlist);
			if (save.is_open())
			{
				player.Save(save);

				save.close();
			}
			mapdraw.DrawMidText("Save �Ϸ�", WIDTH, HEIGHT * 0.5f);
		}
		else if (select == 11)
			return;
	}
}

void GameManager::Playing()
{
	life = true;
	while (life == true)
	{
		GameMenu();
		switch (mapdraw.MenuSelectCursor(6, 3, WIDTH * 0.35f, HEIGHT * 0.3f))
		{
		case 1:
			Dongeon();
			_getch();
			break;
		case 2:
			OutLine();
			Player_Info();
			_getch();
			break;
		case 3:
			OutLine();
			Monster_Info();
			_getch();
			break;
		case 4:
			OutLine();
			Weapon_Shop();
			break;
		case 5:
			OutLine();
			Save();
			_getch();
			break;
		case 6:
			return;
		}
	}
}

void GameManager::LoadSlot()
{
	string line[10] = {};
	float height = 0.25f, down = 0.05f;
	bool OX;
	for (int i = 0; i < 10; i++)
	{
		ifstream load;
		OX = false;
		char is_true;
		string playerlist = "SavePlayer" + to_string(i + 1) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			OX = true;
			load.close();
		}
		if (OX == true)
			is_true = 'O';
		else
			is_true = 'X';
		line[i] = to_string(i + 1) + "������ : (���Ͽ��� : " + is_true + ")";

		mapdraw.DrawMidText(line[i], WIDTH, HEIGHT * (height += down));
	}
	mapdraw.DrawMidText("11.���ư���", WIDTH, HEIGHT * 0.8f);
	
	int select = mapdraw.MenuSelectCursor(11, 2, WIDTH * 0.35f, HEIGHT * 0.3f);
	if (select < 11)
	{
		ifstream load;
		string playerlist = "SavePlayer" + to_string(select) + ".txt";
		load.open(playerlist);
		if (load.is_open())
		{
			player.Load(load);
			load.close();
		}
		else
		{
			mapdraw.DrawMidText("�ش� ������ �����ϴ�.", WIDTH, HEIGHT * 0.5f);
			system("pause");
		}
	}

}

void GameManager::Start()
{
	string name;
	ifstream load;
	MainMenu();
	int playing = mapdraw.MenuSelectCursor(3, 3, WIDTH * 0.35f, HEIGHT * 0.5f);
	while (TRUE)
	{
		switch (playing)
		{
		case 1:
			OutLine();
			mapdraw.DrawMidText("Player �̸� �Է� : ", WIDTH, HEIGHT * 0.5f);
			cin >> name;
			load.open("DefaultPlayer.txt");
			if (load.is_open())
			{
				player.Load(load, name);
				load.close();
			}
			Playing();
			break;
		case 2:
			OutLine();
			LoadSlot();
			Playing();
			break;
		case 3:
			return;
		default:
			break;
		}
	}
}
GameManager::~GameManager() {}