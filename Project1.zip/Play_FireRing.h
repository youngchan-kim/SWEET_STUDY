#pragma once
#include "BitMapManager.h"

class Play_FireRing
{
private:
	BitMap** bmring;
	int width, height;
	float background_max_distance;

	int distance_unit;
	int animation_left, animation_right;
	float ani_time;
	float ring_start_x, ring_x, ring_y, ring_width, ring_height;

public:
	Play_FireRing();
	~Play_FireRing();
	void Init(int width, int height, float background_max_distance);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed, float distance);
};
