#include "Play_Little_Firering.h"
#include <wtypes.h>


//void Play_Little_Firering::Init(int width, int height, float dont_move_point)
//{
//	animation_left = 0, animation_right = 1;
//
//	distance_unit = (width * 0.7f);
//	ring_width = width * 0.04f;
//	ring_height = height * 0.3f;
//
//	ring_start_x = (width * 0.1f) + distance_unit;
//	ring_y = height * 0.3f;
//
//	fire_ring_x = width + ring_start_x;
//}

void Play_Little_Firering::Init(int width, int height, float dont_move_point, int num)
{
	Play_FireRing::Init(width,  height,  dont_move_point,  num);
	speed = 170;



}

void Play_Little_Firering::Draw(HDC backDC)
{
	cash.Draw();
}

void Play_Little_Firering::Update(float deltatime, int speed, float distance, bool win)
{
	cash.Update();

}

int Play_Little_Firering::Play_ScoreUp(RECT player_Rect)
{
	cash.
	return 0;
}
