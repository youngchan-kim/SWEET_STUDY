#include "Play.h"

void Play::Init(int width, int height)
{
	this->width = width;
	this->height = height;
	background.Init();
	player.Init();
	object.Init();
	play_interface.Init();

}

void Play::Draw(HDC backDC)
{
	background.Track(backDC, PLAYER_LOAD_WIDTH);
	background.GrandStand(backDC, GRANDSTAND_START, BACKGROUND_ONE_PICE_WIDTH);
	player.Player(backDC);
	object.Goal(backDC);
}


void Play::Update(float deltatime)
{

	if (GetAsyncKeyState(VK_LEFT))
	{
		//background_x += 10;

		//if (background_x >= 0) { background_x = 0; }
	}

	else if (GetAsyncKeyState(VK_RIGHT))
	{
		//background_x -= 10;
		//goal_x += 10;
		//if (total_x >= 1000) { total_x = 1000;}
	}
	else if (GetAsyncKeyState(VK_SPACE))
	{
		//player_y;
	}

	//if (total_x <= 9000) { background_x -= 10; }
	//else { player_x = (total_x - 9000); }
	

}



