#pragma once
#include "BitMapManager.h"

#define PLAYER_WIDTH 100
#define PLAYER_HEIGHT 100

class Play_Player
{
private:
	BitMap** bmplayer;
	int player_x, player_y;
public:
	Play_Player();
	~Play_Player();
	void Init();
	void Player(HDC backDC);
};

