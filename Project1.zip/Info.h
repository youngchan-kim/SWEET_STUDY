#pragma once
#include"Mecro.h"

class Info
{
private:
	string m_strname;
	int m_idamage;
	int m_imaxhealth;
	int m_imaxexp;
	int m_igetexp;
	int m_iLv;
	int m_igold;
	int m_iexp;
	int m_icurhealth;
public:
	void Infomation(string m_strname);
	void Infomation();
	Info();
	~Info();
};

