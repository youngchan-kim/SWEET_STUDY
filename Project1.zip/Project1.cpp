﻿// Project1.cpp : 애플리케이션에 대한 진입점을 정의합니다.
//
#pragma comment(lib, "msimg32.lib")  
#include "framework.h"
#include "Project1.h"
#include "GameManager.h"

#include <iostream>
#define MAX_LOADSTRING 100

// 전역 변수:
HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);


//void DoubleBuffer(HWND hWnd, HDC hdc);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_PROJECT1, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    //hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

    //만든 윈도우를 윈도우 핸들값에 넣어 사용하기 위함
    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    //윈도우 핸들이 만들어지지 않으면 
    if (!hWnd)
    {
        //실패를 리턴함 그렇게 되면 프로그램이 실행되지 않음
        return FALSE;
    }

    //
    ShowWindow(hWnd, nCmdShow);
    //
    UpdateWindow(hWnd);
    //게임 메니저의 이니셜라이저 함수를 호출하여 이미지를 비트맵에 입력한다. 매개변수로 윈도우의 핸들 값을 넣어준다.
    Ggr->Init(hWnd);


    MSG msg;
    //ZeroMemory는 구조체를 초기화 할때 사용됨 매크로 함수 메모리를 0으로 채워준다.
    //msg를 msg의 크기 만큼 전부 0으로 채워준다.
    ZeroMemory(&msg, sizeof(msg));


    // 프레임값을 100분의 3으로 한다.
    int frameRate = 1000 / 30;
    //ULONGLONG은 unsigned longlong int 자료형이다. 길고 길긴 int 형인데 음수가 없는 자료형
    //GetTickCount64 시스템이 시작한 시점부터 이 함수를 호출한 시점까지 흘러간 시간을 1000분의 1포 단위의 시간으로 알려주는 함수
    //limitTime 프로그램이 시작될때의 시간 값을  가진다.
    ULONGLONG currTime, limitTime = GetTickCount64();

    // 기본 메시지 루프입니다:
    //정상적인 X를 클릭해서 끝난게 아닌 alt+F4 등의 방법으로 종료될때 루프문을 빠져나온다.
    while (WM_QUIT != msg.message)
    {//PeekMessage는 getmessage와 다르게 메세지를 검사할때 메세지가 없어도 즉각리턴을 한다.
        if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
        {
            //해당 라인이 실행될때 currTime가 현재 시간으로 초기화된다.
            currTime = GetTickCount64();
            //시스템이 실행된 첫 시간이 현재시간보다 작거나 같으면 프로그램을 실행한다.
            if (limitTime <= currTime)
            {
                //deltaTime으로 프로그램의 새로고침을 제어한다.
                //deltaTime은 현재시간-시스템실행시간에 +(1000분의 30)에 1000분의 1을 곱한다.
                float deltaTime = (currTime - limitTime + frameRate) * 0.001f;
                //프로그램 실행 시간은 현재시간에 프레임을 늦춘 시간을 더한 시간이다.
                limitTime = currTime + frameRate;

                //if (GetAsyncKeyState(VK_RIGHT))
                //{
                //    g_nX += 500 * deltaTime;
                //}
                //if (GetAsyncKeyState(VK_LEFT))
                //{
                //    g_nX -= 500 * deltaTime;
                //}

                //DoubleBuffer(hWnd, hdc);
            }
        }
    }

    return (int)msg.wParam;
}



//
//  함수: MyRegisterClass()
//
//  용도: 창 클래스를 등록합니다.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PROJECT1));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = 0;
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}



//
//  함수: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  용도: 주 창의 메시지를 처리합니다.
//
//  WM_COMMAND  - 애플리케이션 메뉴를 처리합니다.
//  WM_PAINT    - 주 창을 그립니다.
//  WM_DESTROY  - 종료 메시지를 게시하고 반환합니다.
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        //case WM_PAINT:
        //{
        //    PAINTSTRUCT ps;
        //    HDC hdc = BeginPaint(hWnd, &ps);
        //    // TODO: 여기에 hdc를 사용하는 그리기 코드를 추가합니다...
        //    EndPaint(hWnd, &ps);
        //}
        //break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}