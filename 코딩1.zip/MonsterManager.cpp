#include "MonsterManager.h"

MonsterManager::MonsterManager() {}
void MonsterManager::SetMonster()
{
	Monster monster;
	int listnum;
	ifstream load;
	load.open("DefaultMonster.txt");
	if (load.is_open())
	{
		load >> listnum;
		for (int i = 0; i < listnum; i++)
		{
			monster.Load(load);
			monsterlist.push_back(monster);
		}
		load.close();
	}
}
void MonsterManager::MonsterList()
{
	int m_iWidth = 30;
	int m_iHeight = 30;
	vector<Monster>::iterator iter = monsterlist.begin();
	while(iter != monsterlist.end())
	{
		iter->Infomation();
		iter++;
		// �����ؼ� ���͸� ����Ұ�
	}
}
void MonsterManager::MonsterSelect()
{

}
MonsterManager::~MonsterManager() {}