#include"Manager.h"

void main()
{
	Manager Manager1, Manager2(100), Manager3(1, 5);
}