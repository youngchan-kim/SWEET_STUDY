#include "BitmapManager.h"

BitmapManager* BitmapManager::m_pInstance = NULL;

BitmapManager::BitmapManager()
{
	m_parrBitMap = new Bitmap[1];
}

void BitmapManager::Init(HWND hWnd)
{
	char buf[256];
	HDC hdc = GetDC(hWnd);
	sprintf_s(buf, "back_%d.bmp", IMAGE_BACKGROUND1);
	ReleaseDC(hWnd, hdc);
}
//���� ���۸�
//void BitmapManager::DoubleBuffer(HWND hWnd, HDC hdc)
//{
//    RECT windowRect;
//    GetWindowRect(hWnd, &windowRect);
//
//    HBITMAP backBitmap = bitmap.CreateDIBSectionRe(hdc, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top);
//    HDC backDC = CreateCompatibleDC(hdc);
//    SelectObject(backDC, backBitmap);
//
//    HDC memDC = CreateCompatibleDC(hdc);
//    HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, Dog/*������ ���*/);
//
//    TransparentBlt(backDC, 100 + g_nX, 100, 125, 125, memDC, 0, 0, 125, 125, RGB(255, 0, 255));
//    SelectObject(memDC, oldBitmap);
//    oldBitmap = (HBITMAP)SelectObject(memDC, Chess/*���*/);
//
//    BitBlt(backDC, 0, 0, 145, 245, memDC, 0, 0, SRCCOPY);
//    StretchBlt(backDC, 200, 200, 245, 345, memDC, 0, 0, 145, 245, SRCCOPY);
//    SelectObject(memDC, oldBitmap);
//    DeleteDC(memDC);
//
//    BitBlt(hdc, 0, 0, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, backDC, 0, 0, SRCCOPY);
//    DeleteDC(backDC);
//    DeleteObject(backBitmap);
//}


