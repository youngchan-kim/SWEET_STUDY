#include "Word.h"
Word::Word() {};
Word::~Word() {};

void Word::Draw()
{	
	switch (iWordType)
	{
	case NOMAL:
		ORIGINAL
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	case SPEEDUP:
		BLUE
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	case SPEEDDOWN:
		RED
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	case PUASE:
		GREEN
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	case CLEAR:
		GOLD
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	case BLIND:
		PLUM
			mapdraw.TextDraw(str, x, y);
		ORIGINAL
		break;
	}
}

int Word::Drop(bool bBlind)
{ 
	Erase(); 
	y++; 
	if (bBlind) BlindWord();
	else Draw();
	if (y == 28)
	{
		Die();
		return 1;
	}
	return 0;
}

