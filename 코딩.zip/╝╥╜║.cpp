#include <iostream>

void main()
{
	class Observer
	{
	public:
		Observer() {}
		virtual ~Observer() {}
		virtual void update()abstract;
	};

	class Subject
	{
	public:
		Subject(){}
		virtual ~Subject() {}
		virtual void add(Observer*)abstract;
		virtual void remove(Observer*)abstract;
		virtual void notify()abstract;
	};
}