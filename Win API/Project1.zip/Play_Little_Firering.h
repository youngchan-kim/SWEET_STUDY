#pragma once
#include "Play_FireRing.h"
#include "Play_Cash.h"
class Play_Little_Firering : public Play_FireRing
{
private:
	//ĳ�� �ɹ� ����
	Play_Cash cash;
	bool cash_stealth;
public:
	Play_Little_Firering() {}
	~Play_Little_Firering() {}
	//�����Լ�
	virtual void Init(int width, int height, float dont_move_point, float distance_unit);
	virtual void L_Draw(HDC backDC);
	virtual void R_Draw(HDC backDC);
	virtual void Update(float deltatime, int speed, float distance, bool win);
	virtual void Dead();
	virtual bool Play_DeadIntersect(RECT player_Rect);
	virtual int Play_ScoreUp(RECT player_Rect);
	virtual void Gameset();
};

