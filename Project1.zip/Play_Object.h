#pragma once
#include "BitMapManager.h"


class Play_Object
{
private:
	BitMap** bmobject;
	int width, height;
	float m_fGoal_Width, m_fGoal_height;
	float m_fGoal_x, m_fGoal_y;
public:
	Play_Object();
	~Play_Object();
	void Init(int width, int height);
	void Draw(HDC backDC);
	void Update(float deltatime, int speed);
};

