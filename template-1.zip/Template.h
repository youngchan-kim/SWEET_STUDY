#pragma once
#include <iostream>

class Template
{public:

	Template();
	~Template();
};

template<typename T>
void Number(T a)
{
	a += 1;
	std::cout << a;
}