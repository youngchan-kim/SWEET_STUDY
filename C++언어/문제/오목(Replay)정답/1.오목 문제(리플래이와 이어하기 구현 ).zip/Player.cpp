#include "Player.h"


Player::Player()
{

}


void Player::PlayerSave(string playersavefile)
{
	save.open(playersavefile);
	if (save.is_open()) // �����ؾ��� �� Player1: �̸� , Ŀ�� ���, �� ���, ������ Ƚ��, Ŀ����ǥ, ������Ʈ
	{					// �ϼ�
		save << m_strName << " " << m_player_cursor << " " << m_player_stone << " " << m_iUndoCount;
		save << " " << m_StoneList.size() << endl;
		for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		{
			save << iter->StoneXY().m_ix << " ";
			save << iter->StoneXY().m_iy << endl;
		}
		save << iCursor.m_ix << " " << iCursor.m_iy;
		save.close();
	}
}

void Player::PlayerLoad(string playersavefile)
{
	int i = 0;
	load.open(playersavefile);
	if (!load.eof())
	{
		load >> m_strName >> m_player_cursor >> m_player_stone >> m_iUndoCount >> stonecount;

		while (stonecount > i)
		{
			load >> iStoneposition.m_ix >> iStoneposition.m_iy;
			Stone stone;
			stone.SetStone(iStoneposition);
			m_StoneList.push_back(stone);
			i++;
		}
		load >> iCursor.m_ix >> iCursor.m_iy;
		load.close();
	}
}
// ���� � ��Ȳ���� �� �ϱ� ���ؼ� ��� �Ҳ���
// ���� ���� ��ǥ�� ����Ʈ �������� ������ ���¿��� 
//i�� ��°�� �ش��ϴ� ���� ��ǥ�� �������ٲ���
// �� ���� ��ǥ�� �ؽ�Ʈ ���Ͽ� �������ٰ��̴�.
void Player::PlayerNameSave(string name)
{
	m_strName = name;
}

void Player::PlayerCursor(string pattern)
{
	m_player_cursor = pattern;
}
void Player::PlayerStone(string pattern)
{
	m_player_stone = pattern;
}

void Player::PlayerReset()
{
	m_StoneList.clear();
}


void Player::PlayerUndoCountDown()
{
	m_iUndoCount--;
}

bool Player::PlayerUndo(Position Cursor)
{
	if (m_StoneList.size() > 0)
	{
		iCursor = m_StoneList.back().StoneXY();
		m_StoneList.pop_back();	
		return true;
	}
	return false;
}

void Player::SetPlayerCuser(Position Cursor, int iundo)
{

	iCursor.m_ix = Cursor.m_ix;
 	iCursor.m_iy = Cursor.m_iy;
	m_iUndoCount = iundo;
}

void Player::SetPlayer()
{
	Stone stone;
	stone.SetStone(iCursor);
	m_StoneList.push_back(stone);
	m_iUndoCount;
}

bool Player::StoneListPlayer(int x, int y)
{
	for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		if (iter->StoneCompareXY(x, y) == true)
			return true;
	return false;
}

void Player::StoneDraw(Position Cursor)
{
	iCursor = Cursor;
	MapDraw::DrawPoint(m_player_stone, iCursor.m_ix, iCursor.m_iy);
}
void Player::CursorDraw()
{
	MapDraw::DrawPoint(m_player_cursor, iCursor.m_ix, iCursor.m_iy);
}

void Player::OrignStoneDraw(Position Cursor)
{
	if (StoneListPlayer(Cursor.m_ix, Cursor.m_iy) == true)
		MapDraw::DrawPoint(m_player_stone, Cursor.m_ix, Cursor.m_iy);
}

void Player::allStoneDraw()
{
	for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		MapDraw::DrawPoint(m_player_stone, iter->StoneXY().m_ix, iter->StoneXY().m_iy);
}
void Player::RePlayStoneDraw(int order)
{
	int stonenumber = 0;
	for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
	{
		if (stonenumber == order)
		{
			MapDraw::DrawPoint(m_player_stone, iter->StoneXY().m_ix, iter->StoneXY().m_iy);
		}
		stonenumber++;
	}
}

void Player::ReDraw(int iwidth, int iheight)
{
	MapDraw::ErasePoint(iCursor.m_ix, iCursor.m_iy);
	if (iCursor.m_ix == 0)
	{
		if (iCursor.m_iy == 0)
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
		else if (iCursor.m_iy == iheight - 1)
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
		else
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
	}
	else if (iCursor.m_ix == iwidth - 1)
	{
		if (iCursor.m_iy == 0)
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
		else if (iCursor.m_iy == iheight - 1)
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
		else
			MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
	}
	else if (iCursor.m_iy == 0)
		MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
	else if (iCursor.m_iy == iheight - 1)
		MapDraw::DrawPoint("��", iCursor.m_ix, iCursor.m_iy);
	OrignStoneDraw(iCursor);

}

void Player::OMokCountCheck(list<Stone>::iterator iter, int x, int y) //
{
	m_bstonecheck = false;
	if (iter->StoneCompareXY(x, y) == true)
	{
		m_bstonecheck = true;
		m_iomokcount++;
	}
}


bool Player::Widthline(int x, int y)
{
	int distancedifference = 0;
	while (TRUE)
	{
		for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		{
			OMokCountCheck(iter, x + 1, y);
			if (m_bstonecheck == true)
			{
				x++;
				distancedifference++;
				break;
			}
		}
		if(m_bstonecheck == false)
		{
			x -= distancedifference;
			while (TRUE)
			{
				for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
				{
					OMokCountCheck(iter, x - 1, y);
					if (m_bstonecheck == true)
					{
						x--;
						break;
					}
				}
				if (m_bstonecheck == false)
				{
					if (m_iomokcount != 5)
					{
						m_iomokcount = 1;
						return false;
					}
					else
						return true;
				}
			}
		}
	}
}

bool Player::Heightline(int x, int y)
{
	int distancedifference = 0;
	while (TRUE)
	{
		for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		{
			OMokCountCheck(iter, x, y + 1);
			if (m_bstonecheck == true)
			{
				y++;
				distancedifference++;
				break;
			}
		}
		if(m_bstonecheck == false)
		{
			y -= distancedifference;
			while (TRUE)
			{
				for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
				{
					OMokCountCheck(iter, x, y - 1);
					if (m_bstonecheck == true)
					{
						y--;
						break;
					}
				}
				if (m_bstonecheck == false)
				{
					if (m_iomokcount != 5)
					{
						m_iomokcount = 1;
						return false;
					}
					else
						return true;
				}
			}
		}
	}
}

bool Player::Diagonalline(int x, int y)
{
	int distancedifference = 0;
	while (TRUE)
	{
		for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		{
			OMokCountCheck(iter, x + 1, y + 1);
			if (m_bstonecheck == true)
			{
				x++;
				y++;
				distancedifference++;
				break;
			}
		}
		if (m_bstonecheck == false)
		{
			x -= distancedifference;
			y -= distancedifference;
			while (TRUE)
			{

				for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
				{
					OMokCountCheck(iter, x - 1, y - 1);
					if (m_bstonecheck == true)
					{
						x--;
						y--;
						break;
					}
				}
				if (m_bstonecheck == false)
				{
					if (m_iomokcount != 5)
					{
						m_iomokcount = 1;
						return false;
					}
					else
						return true;
				}
			}
		}
	}
}


bool Player::OppositeDiagonal(int x, int y)
{
	int distancedifference = 0;
	while (TRUE)
	{

		for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
		{
			OMokCountCheck(iter, x - 1, y + 1);
			if (m_bstonecheck == true)
			{
				x--;
				y++;
				distancedifference++;
				break;
			}
		}
		if (m_bstonecheck == false)
		{
			x += distancedifference;
			y -= distancedifference;
			while (TRUE)
			{
				for (list<Stone>::iterator iter = m_StoneList.begin(); iter != m_StoneList.end(); iter++)
				{
					OMokCountCheck(iter, x + 1, y - 1);
					if (m_bstonecheck == true)
					{
						x++;
						y--;
						break;
					}
				}
				if (m_bstonecheck == false)
				{
					if (m_iomokcount != 5)
					{
						m_iomokcount = 1;
						return false;
					}
					else
						return true;
				}
			}
		}
	}
}

string Player::OMok(string win)
{
	m_iomokcount = 1;
	//������ ��������� ���� ���� �������� ������ �ϼ��ȴ�. ���ʿ� ��� �ִ��� �����ʿ� ��� �ִ��� Ȯ��
	//�� ���� ���� ���� ������ ���� �ʴ´�.
	win = "false";

	if (Widthline(iCursor.m_ix, iCursor.m_iy) == true)
		win = m_strName;
	else if (Heightline(iCursor.m_ix, iCursor.m_iy) == true)
		win = m_strName;
	else if (Diagonalline(iCursor.m_ix, iCursor.m_iy) == true)
		win = m_strName;
	else if (OppositeDiagonal(iCursor.m_ix, iCursor.m_iy) == true)
		win = m_strName;

	return win;
}

bool Player::GameRole(int m_iwidth, int m_iheight)
{
	string win;
	if (m_StoneList.size() > 4)
	{
		win = OMok(win);
		if (win == m_strName)
		{
			MapDraw::DrawMidText(m_strName, m_iwidth, m_iheight *0.5f);
			cout << " �¸�!!";
			getch();
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

void Player::GameBacking(int m_iwidth, int m_iheight)
{
	int iundo;
	MapDraw::DrawMidText("������ : ", m_iwidth * 1.5f, m_iheight * 1.15f);
	iundo = PlayerUndoCount();
	cout << iundo;

}
Position Player::CursorReTurn()
{
	return iCursor;
}

string Player::PlayerMove(char ch, int m_iwidth, int m_iheight)
{
	switch (ch)
	{
	case 'w':
		if (iCursor.m_iy > 0)
		{
			iCursor.m_iy--;
			MapDraw::DrawPoint(m_player_cursor, iCursor.m_ix, iCursor.m_iy);
		}
		return "move";
	case 's':
		if (iCursor.m_iy < m_iheight - 1)
		{
			iCursor.m_iy++;
			MapDraw::DrawPoint(m_player_cursor, iCursor.m_ix, iCursor.m_iy);
		}
		return "move";
	case 'd':
		if (iCursor.m_ix < m_iwidth - 1)
		{
			iCursor.m_ix++;
			MapDraw::DrawPoint(m_player_cursor, iCursor.m_ix, iCursor.m_iy);
		}
		return "move";
	case 'a':
		if (iCursor.m_ix > 0)
		{
			iCursor.m_ix--;
			MapDraw::DrawPoint(m_player_cursor, iCursor.m_ix, iCursor.m_iy);
		}
		return "move";
	case '\r':
		return "ENTER";

	case 'n':// �������
		if (m_iUndoCount > 0)
			return "Backing";
		return "move";

	case 'p':
		return "option";

	case ESC:
		return "end";
	default:
		return "move";
	}
}

Player::~Player() {}