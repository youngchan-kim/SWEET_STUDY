#pragma once
#include "Character.h"
class Monster : public Character
{

public:
	Monster();
	void Load(ifstream& load, string name = "") override;
	void Infomation(int x, int y) override;
	~Monster();
};

