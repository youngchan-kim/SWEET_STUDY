#include "Play_Cash.h"
#include <wtypes.h>
Play_Cash::Play_Cash()
{
	bmcash = new BitMap * [OTHEROBJECT_1];
}

Play_Cash::~Play_Cash()
{
	if (bmcash != NULL) { delete[] bmcash; bmcash = NULL; }
}

void Play_Cash::Init(int width, int height, float dont_move_point, int speed, float distance_unit)
{
	this->width = width;
	this->height = height;
	this->dont_move_point = dont_move_point;
	this->speed = speed;
	bmcash[0] = BMMger->GetOtherObject((OTHEROBJECT)(2));

	this->distance_unit = distance_unit;
	cash_width = width * 0.04f;
	cash_height = height * 0.06f;
	cash_y = height * 0.32f;

	cash_start_x = (width * 0.1f) + (cash_width * 0.5f) + this->distance_unit;
	cash_x = width + cash_start_x;

	Intersect_check = false;
	score_check = false;
	cash_stealth = false;

}

//x��ǥ�� �ٸ��� ���ؾ��Ѵ�.
//�Ұ��� ���� ������ ������ �ʿ�� ����.
void Play_Cash::Draw(HDC backDC)
{
	if(!cash_stealth)bmcash[0]->Draw(backDC, cash_x + (width * 0.01f), cash_y, cash_width - (width * 0.02f), cash_height);

	//Rectangle(backDC, cash_rect.left, cash_rect.top, cash_rect.right, cash_rect.bottom);
}

void Play_Cash::Update(float deltatime, int speed, float distance, int win)
{
	if (!win)
	{
		if (distance <= 0 || distance >= dont_move_point) speed = 0;
		cash_x -= (this->speed + speed) * deltatime;

		if (cash_x <= -cash_width * 2)
		{
			cash_x += width + cash_width * 2;
			cash_stealth = false;
		}
	}
	else
	{
		cash_x = width + distance;
	}

	
	cash_rect = { (LONG)(cash_x+ cash_width*0.1f),(LONG)(cash_y),(LONG)(cash_x + cash_width * 0.9f ),(LONG)(cash_y + cash_height) };
}

void Play_Cash::Dead()
{
	cash_x = width + cash_start_x;
}

int Play_Cash::Play_ScoreUp(RECT player_Rect)
{
	RECT tmpRect;
	if (IntersectRect(&tmpRect, &player_Rect, &cash_rect))Intersect_check = true;
	else Intersect_check = false;
	//�浹 ������ true�϶� ���ھ�üũ�� false�̸� ���ھ� üũ�� true�� �ٲ۴�.
	if (Intersect_check && !score_check) { score_check = true; cash_stealth = true; }
	//�浹 ������ false�̰� ���ھ�üũ�� true�̸� ���ھ� üũ�� false�� �ٲٰ� ���� 100�� ���ش�.
	if (!Intersect_check && score_check)
	{
		score_check = false;

		return 200;
	}
	return 0;
}

void Play_Cash::Gameset()
{
	cash_x = width + cash_start_x;
}
