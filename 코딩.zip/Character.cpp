#include "Character.h"

Character::Character() {}

//void Character::NewMonster()
//{
//	monsterlist = 0;
//	ifstream load;
//	load.open("DefaultMonster.txt");
//	if (!load.eof()) // �ϼ�
//	{
//		load >> monsterlist;
//		for (int i = 0; i < monsterlist; i++)
//		{
//			load >> m_strname;
//			load >> m_idamage;
//			load >> m_imaxhealth;
//			//load >> m_icurhealth;
//			load >> m_imaxexp;
//			load >> m_igetexp;
//			load >> m_iLv;
//			load >> m_igold;
//		}
//	}
//	load.close();
//}


Character::~Character() {}