#include "Shop.h"

Shop::Shop() {}
void Shop::ShopMenu()
{
	//mapdraw.DrawMidText("�� �� S H O P �� ��", m_iWidth, m_iHeight * 0.2f);
	//mapdraw.DrawMidText("Dagger", m_iWidth, m_iHeight * 0.45f);
	//mapdraw.DrawMidText("Gun", m_iWidth, m_iHeight * 0.5f);
	//mapdraw.DrawMidText("Sword", m_iWidth, m_iHeight * 0.55f);
	//mapdraw.DrawMidText("Wand", m_iWidth, m_iHeight * 0.6f);
	//mapdraw.DrawMidText("Bow", m_iWidth, m_iHeight * 0.65f);
	//mapdraw.DrawMidText("Hammer", m_iWidth, m_iHeight * 0.7f);
	//mapdraw.DrawMidText("���ư���", m_iWidth, m_iHeight * 0.75f);
}
void Shop::ShopLsit(int x, int y)
{
}
void Shop::SetWeapon()
{
	/*Weapon* weapon;
	ifstream load;
	load.open("WeaponList.txt");
	if (load.is_open())
	{
		while (!load.eof())
		{
			load >> m_strweapon;
			if ("Bow" == m_strweapon)
			{
				weapon = new Bow(m_strweapon);
			}

			weapon->Load(load);
			weaponlist.push_back(weapon);
		}
		load.close();
	}*/
}
Shop::~Shop() {}