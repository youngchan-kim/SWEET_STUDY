#include "WordManager.h"
WordManager::WordManager() {}
WordManager::~WordManager() {}

void WordManager::Load()
{
	int num;
	std::ifstream load;
	load.open("Word.txt");
	if (load.is_open())
	{
		std::string strString;
		load >> num;
		wordnum = num;
		while (load.eof())
		{
			getline(load, strString);
			word_list.push_back(Word(strString));
		}
		load.close();
	}
}

void WordManager::MakeWord()
{
	int num = rand() % word_list.size();
	word_list[num].SetWord();
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

void WordManager::Draw()
{
	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Draw();
		}
	}
}

void WordManager::Drop()
{

	for (int i = 0; word_list.size() > i; i++)
	{

		if (!word_list[i].IsDead())
		{
			word_list[i].Drop();
		}
	}

}
