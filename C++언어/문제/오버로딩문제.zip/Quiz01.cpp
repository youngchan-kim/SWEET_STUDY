#include "Quiz01.h"


Quiz01::Quiz01()
{
}

void Quiz01::Quiz1(int num01, int num02)
{
	m_inum01 = num01;
	m_inum02 = num02;
	if (m_inum02 >= 1) {
		for (int i = 1; i <= m_inum02; i++)
		{
			m_isum *= num01;
		}
		cout << m_inum01 << "�� " << m_inum02 << "�� : " << m_isum << endl;
	}
	else
		cout << "���� 1���� �۽��ϴ�." << endl;
}

void Quiz01::Quiz1(char char01, int num01)
{
	char output;
	if (('a' <= char01 && 'z' >= char01) || ('A' <= char01 && 'Z' >= char01))
	{
		if ('a' <= char01 && 'z' >= char01)
		{
			if ((char01 + num01) > 'z')
			{
				output = (char)96 + ((char01 + num01) - 'z');
			}
			else 
				output = (char)(char01 + num01) ;
		}
		else if ('A' <= char01 && 'Z' >= char01)
		{
			if ((char01 + num01) > 'Z')
			{
				output = (char)64 + ((char01 + num01) - 'Z');
			}
		}
		cout << char01<<" >> "<<num01<<" : "<< output << endl;
	}
	else
		cout << "�ش� ���ڰ� ���ĺ��� �ƴմϴ�." << endl;
}

Quiz01::~Quiz01()
{
}