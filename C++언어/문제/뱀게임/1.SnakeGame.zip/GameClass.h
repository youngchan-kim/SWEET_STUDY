#pragma once
#include"Mecro.h"
#include "BlockClass.h"
#include "SnackClass.h"

#define MAXWALLBLOCK 20
#define MAXITEMBLOCK 9
#define MAXWIDTH_MAXHEIGHT 30
#define SPACE_BAR 32
#define ITEMTIME 2000

class GameClass
{
private:
	BLOCK_TYPE type;

	BlockClass wallshape;
	BlockClass itemshape;

	std::list<BlockClass> itemlist;
	std::vector<BlockClass> walllist;
	SnackClass snack;
	
	Position m_cursor;

	int m_iStart_x;
	int m_iStart_y;
	int m_iWidth;
	int m_iHeight;


	int m_iitemcout;

	int m_imaintime;
	int m_iitemtime;
	char m_ch;
	int num;
	std::string strscore;
	std::string score;

public:
	int RandomPosition();
	bool WallCrash(Position cursor);
	void SetWall(BLOCK_TYPE type);
	void WallList();
	bool ItemSearch(Position cursor);
	std::list<BlockClass>::iterator ItemSearch();
	void ItemReMove();
	void SetItem();

	void Map_Interface();
	void GameEnd();
	void Game();
	void Menu();

	GameClass();
	~GameClass();
};

