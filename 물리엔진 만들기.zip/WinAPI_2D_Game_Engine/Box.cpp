#include "Box.h"

void Box::Init(float left , float top, float right, float bottom)
{
	half_width = (right - left) * 0.5f;
	half_height = (top - bottom) * 0.5f;
	position.x = left + half_width;
	position.y = top + half_height;
}

void Box::Update(const FLOAT& deltaTime)
{
	gravity = g * deltaTime;
	position.y += gravity;
}

void Box::Draw(HDC hdc)
{
	Rectangle(hdc , position.x- half_width, position.y - half_height,
		position.x + half_width, position.y + half_height);
}
