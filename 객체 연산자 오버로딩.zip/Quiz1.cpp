#include "Quiz1.h"

Quiz1::Quiz1()
{
	x = 0;
	y = 0;
}
Quiz1::Quiz1(int a, int b) 
{
	x = a;
	y = b;
	Print();
}


void Quiz1::Print()
{
	cout << "x = " << x << ", y = " << y << endl;
}

Quiz1::~Quiz1(){}

Quiz1 operator/(Quiz1 quiz1, Quiz1 quiz2)
{
	Quiz1 tmp;
	cout << "��ü / ��ü" << endl;
	if (quiz1.x > quiz2.x)
	{
		tmp.x = quiz1.x / quiz2.x;
		if (quiz1.y > quiz2.y)
			tmp.y = quiz1.y / quiz2.y;
		else
			tmp.y = quiz2.y / quiz1.y;
	}
	else
	{
		tmp.x = quiz2.x / quiz1.x;
		if (quiz1.y > quiz2.y)
			tmp.y = quiz1.y / quiz2.y;
		else
			tmp.y = quiz2.x / quiz1.x;
	}
	return tmp;
}