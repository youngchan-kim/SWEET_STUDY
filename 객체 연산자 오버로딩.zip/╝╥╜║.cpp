#include "Quiz1.h"

void main()
{
	Quiz1 quiz1(10, 20), quiz2(5, 40);
	quiz2 = quiz1 / quiz2;
	quiz2.Print();
}