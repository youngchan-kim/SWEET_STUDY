#include "Play_Cash.h"
#include <wtypes.h>
Play_Cash::Play_Cash()
{
}

Play_Cash::~Play_Cash()
{
}

void Play_Cash::Init(int width, int height, float distance_unit)
{
	this->width = width;
	bmcash = BMMger->GetOtherObject((OTHEROBJECT)(2));

	cash_width = width * 0.04f;
	cash_height = height * 0.06f;
	cash_y = height * 0.32f;

	cash_start_x = (width * 0.1f) + (cash_width * 0.5f) + distance_unit;
	cash_x = width + cash_start_x;

}

//x��ǥ�� �ٸ��� ���ؾ��Ѵ�.
//�Ұ��� ���� ������ ������ �ʿ�� ����.
void Play_Cash::Draw(HDC backDC)
{
	bmcash->Draw(backDC, cash_x, cash_y, cash_width, cash_height);
	Rectangle(backDC, cash_rect.left, cash_rect.top, cash_rect.right, cash_rect.bottom);
}

void Play_Cash::Update(float positionX)
{
	cash_x = positionX + cash_width * 0.5f;
	cash_rect = { (LONG)(cash_x+ cash_width*0.4f),(LONG)(cash_y),(LONG)(cash_x + cash_width * 0.6f ),(LONG)(cash_y + cash_height*2.0f) };
}

int Play_Cash::Play_ScoreUp(RECT player_Rect)
{
	RECT tmpRect;
	if (IntersectRect(&tmpRect, &player_Rect, &cash_rect))
	{
		return 200;
	}
	return 0;
}