#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Timer.h"

#define ITEMTIME 2000
#define TRUE 1
#define NULL 0

typedef struct Position
{
	int m_ix;
	int m_iy;
};

enum BLOCK_TYPE
{
	WALL,
	BARRICADE,
	ITEM,
	HEAD,
	TEIL
};
class BlockClass
{
private:

	std::string m_strshape;
	BLOCK_TYPE block_type;
	Position m_position;
	Timer timer;
public:
	inline Position PositionXY() {return m_position;};
	std::string Type_Shape(BLOCK_TYPE type);
	void ShapeDraw(BLOCK_TYPE type, Position cursor);
	void Position_input(int x, int y);
	void Shape(BLOCK_TYPE type, Position cursor);
	bool PositionCheck(Position cursor);
	//void SetItem();
	void setItemtime();
	BlockClass();
	~BlockClass();
};