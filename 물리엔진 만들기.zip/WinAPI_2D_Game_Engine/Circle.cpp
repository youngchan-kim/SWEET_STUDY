#include "Circle.h"

void Circle::Init(float x, float y, float radius, float d)
{
	this->radius = radius;

	position.x = x + radius;
	position.y = y + radius;
	volume = radius * radius * 3.141592f;
	mass = volume * d;
}

void Circle::Update(const FLOAT& deltaTime)
{
	gravity = g * deltaTime;
	position.y += gravity;
}

void Circle::Draw(HDC hdc)
{
	Ellipse(hdc,position.x - radius, position.y - radius, position.x + radius, position.y + radius);
}


