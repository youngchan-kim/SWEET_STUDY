#pragma once
#include"Quiz01.h"
#include"Quiz02.h"
#include"Quiz03.h"

class Manager
{
private:
	Quiz01 quiz01;
	Quiz02 quiz02;
	Quiz03 quiz03;
public:
	void List();

	Manager();
	~Manager();
};

