#include "Box.h"

void Box::Init(float x, float y, float width, float height, float d,bool fix)
{
	//this->fix = fix;

	half_width = width * 0.5f;
	half_height = height * 0.5f;
	position.x = x + half_width;
	position.y = y + half_height;

	volume = width * height;

	mass = volume * d;
	if (mass > 0) invMass = 1 / mass;
	else invMass = 0;
	//if (!fix) velocity = { 0,0 };
}

//void Box::Update()
//{
//	object->Update();
//}

void Box::Draw(HDC hdc)
{
	Rectangle(hdc , position.x- half_width, position.y - half_height,
		position.x + half_width, position.y + half_height);
}
