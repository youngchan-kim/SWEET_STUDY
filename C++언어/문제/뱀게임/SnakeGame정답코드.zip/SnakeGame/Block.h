#pragma once
#include"DrawManager.h"

enum class BLOCK_TYPE
{
	COLLIDER,
	FOOD,
	TAIL,
	HEAD
};

class Block
{
private:
	int m_ix;
	int m_iy;
	string m_strShape;
	BLOCK_TYPE m_eType;
public:
	Block();
	~Block();
	void Init(int _ix, int _iy, BLOCK_TYPE _eType);
	void Draw();
	void Erase();
	bool Compare(int _ix, int _iy);
	bool Compare(Block b);
	void AddPosition(int _iAdd_x, int _iAdd_y);
	void SetType(BLOCK_TYPE _eType);
	void CopyPosition(Block b);
};

