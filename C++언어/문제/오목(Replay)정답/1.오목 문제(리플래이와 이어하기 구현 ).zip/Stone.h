#pragma once
#include"Mecro.h"

struct Position
{
	int m_ix;
	int m_iy;
};

class Stone
{
private:
	Position m_position;

public:
	void SetStone(Position iCursor);
	Position StoneXY(); 
	bool StoneCompareXY(int x, int y);
	Stone();
	~Stone();
};

