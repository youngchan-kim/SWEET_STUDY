#pragma once
#include "Monster.h"
#include <vector>

class MonsterManager
{
private:
	vector<Monster> monsterlist;
	//Monster selectMon;
	MapDraw mapdraw;
public:
	MonsterManager();
	//float MonsterAtteck() {
	//	return selectMon.Atteck(); 
	//}
	//int MonsterHP() { return selectMon.CurrentHealth(); }
	//int MonsterGetexp() { return selectMon.Getexp(); }
	//int MonsterGetgold() { return selectMon.Gold(); }
	//string MonsterGetName() { return selectMon.GetName(); }
	//void MonsterInfomation(int x, int y){ selectMon.Infomation(x, y); }
	void SetMonster();
	void MonsterList();
	void DongeonList(int x, int y);
	Monster MonsterSelect(int dongeonnum, int x, int y);
	void Relese();
	~MonsterManager();
};

