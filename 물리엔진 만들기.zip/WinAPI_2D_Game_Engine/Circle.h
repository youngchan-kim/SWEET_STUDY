#pragma once
#include "EngineMecro.h"
#include <iostream>
#include <Windows.h>
#include "Object.h"

//���� �׸��� ���� �߽� ��

class Circle:public Object
{
private:
	//������
	float radius;
public:
	void Init(float x, float y, float radius, float d, bool fix);
	//void Update();
	void Draw(HDC hdc);
	//float GetVolume() { return volume; }
	//float GetMass() { return mass; }
	//float GetInvMass()
	//{
	//	return invMass;
	//}
	float GetRadius() { return radius; }
	//Vector2 GetPosition() { return position; }
	//Vector2 GetVelocity() { return velocity; }
	//void Add_Gravity(Vector2 gravityvelocity) { if(!fix)velocity += gravityvelocity; }
	////��ü�� ���� ������ �ӵ�
	//void Add_Velocity(Vector2 addvelocity) { if (!fix)velocity += addvelocity; }
	////void Add_Gravity() { this->velocity = }
};

