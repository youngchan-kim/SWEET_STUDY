#pragma once
#include<iostream>
#include<string>
#include<Windows.h>

using namespace std;

class School
{
private:
	int i_mgrade, i_mclass, i_mnumber;
public:
	void Information();
	void Print();
	School();
	~School();

};

