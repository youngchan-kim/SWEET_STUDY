#pragma once
#include "Mecro.h"
#include "MapDraw.h"
class Character
{
private:
	string m_strname;
	int m_idamage;
	int m_imaxhealth;
	int m_imaxexp;
	int m_igetexp;
	int m_iLv;
	int m_igold;
	int m_iexp;
	int m_icurhealth;
	MapDraw mapdraw;
public:
	void Infomation();

	void NewPlayer(string m_strname);
	void LoadPlayer();
	void Monster();
	Character();
	~Character();
};

