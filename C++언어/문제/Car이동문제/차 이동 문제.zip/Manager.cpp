#include "Manager.h"
Manager::Manager() 
{
	m_isetcarclock = 0;
	m_imainclock = 0;
	m_moveclock = 0;
}



void Manager::SetCar()
{
	Car car;
	car.CreateCar();
	m_carlist.push_back(car);
}

void Manager::SpeedSwap()
{
	for (list<Car> ::iterator iter = m_carlist.begin(); iter != m_carlist.end(); iter++)
	{
		iter->SpeedBool();
	}
}

list<Car>::iterator Search(std::list<Car>* m_carlist)
{
	for (list<Car>::iterator iter = m_carlist->begin(); iter != m_carlist->end(); iter++)
	{
		if (iter->X_Position() >= 200)
			return iter;
	}
	return m_carlist->end();
}

void Manager::ReMove()
{
	list<Car>::iterator findIter = Search(&m_carlist);
	if (findIter != m_carlist.end())
	{
		findIter->EraseCar();
		m_carlist.erase(findIter);
		for (list<Car> ::iterator iter = m_carlist.begin(); iter != m_carlist.end(); iter++)
		{
			iter->DrawCar();
		}
	}
}

void Manager::MoveCar()
{
	m_moveclock = clock();
	for (list<Car> ::iterator iter = m_carlist.begin(); iter != m_carlist.end(); iter++)
	{
		iter->MoveCheck(m_moveclock);
	}
	ReMove();
}

void Manager::CarDriver()
{
	SetCar();
	m_imainclock = clock();
 	while (1)
	{
		m_isetcarclock = clock();
		if (kbhit())
		{
			char ch = getch();
			if (ch == SPACEBAR)
				SpeedSwap();
		}
		MoveCar();
		if (m_isetcarclock - m_imainclock > 10000)
		{
			SetCar();
			m_imainclock = m_isetcarclock;
		}

	}
}

Manager::~Manager() {}