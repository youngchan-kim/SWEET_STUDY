#pragma once
#include <iostream>

class Template
{public:

	Template();
	~Template();
};

template<typename T1, typename  T2>
void Number(T1 a, T2 b)
{
	if (a > b)
		std::cout << "�ּڰ���" << b << "�Դϴ�.";
	else
		std::cout << "�ּڰ���" << a << "�Դϴ�.";
}