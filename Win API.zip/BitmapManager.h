#pragma once
#include "Bitmap.h"
#include<vector>

enum IMAGE_BACK
{
	IMAGE_BACKGROUND1 = 1, //�޸��� �ʷϻ� ��
	IMAGE_BACKGROUND2, //�ڳ���
	IMAGE_BACKGROUND3, //����
	IMAGE_BACKGROUND4 //ȯȣ�ϴ� ����
};

enum IMAGE_OBJECT 
{
	IMAGE_FIRE1 =1,
	IMAGE_FIRE2,
	IMAGE_RING1 =1 ,
	IMAGE_RING2,
	IMAGE_RING3,
	IMAGE_RING4

};

enum IMAGE_PLAYER
{
	IMAGE_PLAYER1=1,
	IMAGE_PLAYER2,
	IMAGE_PLAYER3,
	IMAGE_PLAYER4,
	IMAGE_PLAYER5,
	IMAGE_PLAYER6

};
enum IMAGE_INTERFACE
{
	IMAGE_INTERFACE1=1,
	IMAGE_INTERFACE2,
	IMAGE_INTERFACE3
};
enum IMAGE_MENU
{
	IMAGE_MENU1=1,
	IMAGE_MENU2,
	IMAGE_MENU3,
	IMAGE_MENU4,
	IMAGE_MENU5,
	IMAGE_MENU_TITLE_1=1,
	IMAGE_MENU_TITLE_2,
	IMAGE_MENU_TITLE_3,
	IMAGE_MENU_TITLE_4
};

#define IMAGE_CASH cash
#define IMAGE_POINT point
#define IMAGE_GOAL goal 

class BitmapManager
{
private:
	Bitmap* m_parrBitMap;
	static BitmapManager* m_pInstance;

private:

public:
	BitmapManager();
	~BitmapManager() {}

	//�̱���
	static BitmapManager* get_instance()
	{
		if (NULL == m_pInstance)m_pInstance = new BitmapManager;
		return m_pInstance;
	}
	void Init(HWND hWnd);
	//void DoubleBuffer(HWND hWnd, HDC hdc);

};



#define BitMgr BitmapManager::get_instance()

//bitmap�� ����� �ۿ뿡 ���� ����
//