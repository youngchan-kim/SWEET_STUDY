#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Player.h"
#include "MonsterManager.h"
#include "Shop.h"
enum RSP
{
	Rock = 1,
	Scissors,
	Paper
};

class GameManager
{
private:
	int m_iWidth;
	int m_iHeight;
	int Start_x;
	int Start_y;
	MapDraw mapdraw;
	Player player;
	MonsterManager monstermanager;
	Shop shop;
	bool life;
public:
	void OutLine();
	void MainMenu();
	void GameMenu();
	void DongeonMenu();
	void LoadSlot();
	void Start();
	void Playing();

	void PVE(int dongeonnum);
	void Dongeon();
	void Player_Info();
	void Monster_Info();
	void Weapon_Shop();

	void Save();
	GameManager();
	~GameManager();
};

