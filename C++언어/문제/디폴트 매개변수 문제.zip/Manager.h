#pragma once
#include"Employee.h"
#include"Multiply.h"
#include"Sum_From_1_to_x.h"


class Manager
{
private:
	Employee m_Employee;
	Sum_From_1_to_x m_Sum_From_1_to_x;
	Multiply m_Multiply;
public:
	void Menu();
	void UsingEmployee_Salary();
	void UsingSum_From_1_to_x();
	void UsingMultiply();
	Manager();
	~Manager();
};


