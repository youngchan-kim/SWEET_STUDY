#pragma once
#include "Monster.h"
#include <vector>

class MonsterManager:public Monster
{
private:
	vector<Monster> monsterlist;
	Monster* selectMon;
public:
	MonsterManager();
	inline float MonsterAtteck() { return selectMon->Atteck(); };
	inline int MonsterHP() { return selectMon->Gethealth(); };
	inline int MonsterGetexp() { return selectMon->Getexp(); };
	void SetMonster();
	void MonsterList();
	void DongeonList(int x, int y);
	void MonsterSelect(int dongeonnum, int x, int y);
	void MonsterCurhealth(int tookdamage);
	void Relese();
	~MonsterManager();
};

