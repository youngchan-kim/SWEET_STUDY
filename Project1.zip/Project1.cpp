﻿// Project1.cpp : 애플리케이션에 대한 진입점을 정의합니다.
//
#pragma comment(lib, "msimg32.lib")  
#include "framework.h"
#include "Project1.h"
#include "GameManager.h"

#include <iostream>
#define MAX_LOADSTRING 100

// 전역 변수:
HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);


int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_PROJECT1, szWindowClass, MAX_LOADSTRING);

    //
    MyRegisterClass(hInstance);

    // 윈도우를 만들고 핸들값을 반환한다.
    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    //윈도우 핸들이 만들어지지 않으면 
    //메모리가 부족하면 윈도우 생성이 실패한다.
    if (!hWnd)
    {
        //프로그램 종료
        return FALSE;
    }

    //윈도우를 보여줌
    ShowWindow(hWnd, nCmdShow);
    //윈도우를 새로 고침 즉 업데이트
    UpdateWindow(hWnd);

    //게임 메니저의 이니셜라이저 함수를 호출하여 이미지를 비트맵에 입력한다. 매개변수로 윈도우의 핸들 값을 넣어준다.
    Ggr->Init(hWnd);

    MSG msg;
    //ZeroMemory는 메모리 값을 0으로 바꾸어주는 함수
    ZeroMemory(&msg, sizeof(msg));


    // 프레임값을 1000분의 30으로 한다.
    //1000은 밀리세컨드의 1초이다.
    int frameRate = 1000 / 30;

    //ULONGLONG은 unsigned longlong 정수 자료형이다.
    // unsigned는 음수의 범위를 사용하지 않는 키워드이다.    
    //GetTickCount64 시스템이 시작한 시점부터 이 함수를 호출한 시점까지 흘러간 시간을 1000분의 1초 단위의 시간으로 알려주는 함수
    //limitTime 프로그램이 시작될때의 시간 값을  가진다.
    ULONGLONG currTime, limitTime = GetTickCount64();

    //종료되면 루프 탈출 
    //WM_QUIT : 종료되면 발생
    while (WM_QUIT != msg.message)
    {//PeekMessage는 getmessage와 다르게 메세지를 검사할때 메세지가 없으면 false
        if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
        {
            //해당 라인이 실행될때 currTime가 현재 시간으로 초기화된다.
            currTime = GetTickCount64();

            //그림을 그리는데 CPU의 연산 비용이 크기 때문에 부하가 간다.
            //CPU의 부하를 낮추기 위해 초당 그리는 갯수를 제한
            if (limitTime <= currTime)
            {
                //이전 프레임에서 현제프레임까지 걸린 시간 값
                //연산속도가 다른 컴퓨터에서도 같은 시간 동안 이동한 거리가 같게 하기 위함.
                float deltaTime = (currTime - limitTime + frameRate) * 0.001f;
                //다음 프레임까지 걸리는 시간
                limitTime = currTime + frameRate;

                Ggr->Update(deltaTime);
                Ggr->Draw();
            }
        }
    }

    delete Ggr;

    return (int)msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PROJECT1));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = 0;
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}