#pragma once
#include "WoodMan.h"

class EnterWoodCutting : public State
{
private:
	EnterMineAndDigForNugget() {}
	
private:
};