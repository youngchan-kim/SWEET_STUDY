#include "Play.h"

void main()
{
	system("mode con: cols=120 lines=40");
	Play p;
	p.MainMenu();

}