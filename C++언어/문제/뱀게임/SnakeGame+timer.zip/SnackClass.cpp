#include "SnackClass.h"

SnackClass::SnackClass() 
{
	m_ilife = 0;
	ch_mmove = NULL;
	m_isnackmaintime = clock();
};

bool SnackClass::HeadTeilCrush()
{
	for (std::vector<BlockClass>::iterator firstiter = teillist.begin(); firstiter != teillist.end(); firstiter++)
	{
		if (firstiter->PositionCheck(head.PositionXY()) == true)
			return true;
	}
	return false;
}

bool SnackClass::HeadPositionCheck(Position cursor)
{
	if (head.PositionXY().m_ix == cursor.m_ix)
		if (head.PositionXY().m_iy == cursor.m_iy)
			return true;
	return false;
}

bool SnackClass::TeilPositionCheck(Position cursor)
{
	for (std::vector<BlockClass>::iterator teiliter = teillist.begin(); teiliter != teillist.end(); teiliter++)
	{
		if (teiliter->PositionXY().m_ix == cursor.m_ix)
			if (teiliter->PositionXY().m_iy == cursor.m_iy)
				return true;
	}
	return false;
}

void SnackClass::SetSnackTime()
{
	timer.SetTimer(TIMER_TYPE_LOOP, SPEED - (teillist.size() * SPEED_UP),
		std::bind(&SnackClass::Head_Move, this));
}

void SnackClass::SnackTimeCheck()
{
	timer.CheckTimer();
}

void SnackClass::SetHead(Position cursor)
{
	head.Shape(HEAD, cursor);
}

void SnackClass::Add_Teil()
{
	BlockClass teil;
	if (teillist.begin() == teillist.end())
		teil.Shape(TEIL, m_tmpposition);
	else if(teillist.begin() != teillist.end())
		teil.Shape(TEIL, teillist.back().PositionXY());
	timer.SetTimer(SPEED - (teillist.size() * SPEED_UP));
	teillist.push_back(teil);
	m_ilife++;

}


void SnackClass::Teil_Move()
{
	Position swapposition;
	for(std::vector<BlockClass>::iterator firstiter = teillist.begin(); firstiter != teillist.end(); firstiter++)
	{
		MapDraw::ErasePoint(firstiter->PositionXY().m_ix, firstiter->PositionXY().m_iy);
		swapposition = firstiter->PositionXY();
		firstiter->Position_input(m_tmpposition.m_ix, m_tmpposition.m_iy);
		firstiter->ShapeDraw(TEIL, m_tmpposition);
		m_tmpposition = swapposition;
	}
}

void SnackClass::Move(int x, int y)
{
	MapDraw::ErasePoint(head.PositionXY().m_ix, head.PositionXY().m_iy);
	head.Position_input(head.PositionXY().m_ix + x, head.PositionXY().m_iy + y);
	head.ShapeDraw(HEAD, head.PositionXY());
}

void SnackClass::Head_MoveArray(char ch)
{
	if (ch == NULL || (ch == UP || ch == DOWN || ch == RIGHT || ch == LEFT))
	{
		if (ch == DOWN && ch_mmove == UP)
			ch_mmove = UP;
		else if (ch == UP && ch_mmove == DOWN)
			ch_mmove = DOWN;
		else if (ch == RIGHT && ch_mmove == LEFT)
			ch_mmove = LEFT;
		else if (ch == LEFT && ch_mmove == RIGHT)
			ch_mmove = RIGHT;
		else
			ch_mmove = ch;
	}
}

void SnackClass::Head_Move()
{
		m_tmpposition = head.PositionXY();
		switch (ch_mmove)
		{
		case UP:
			Move(0, -1);
			break;
		case DOWN:
			Move(0, 1);
			break;
		case RIGHT:
			Move(1, 0);
			break;
		case LEFT:
			Move(-1, 0);
			break;
		}
		if (!teillist.empty())
			Teil_Move();
}

void SnackClass::END()
{
	ch_mmove = NULL;
	m_ilife = 0;
	head.Position_input(-1, -1);
	teillist.clear();
}
SnackClass::~SnackClass() {};