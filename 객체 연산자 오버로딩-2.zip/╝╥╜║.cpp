#include "Time.h"

void main()
{
	int Day = 1;
	int iHour = 0, iMin = 0;
	Time time;
	while (1)
	{
		system("cls");
		int select = 0;
		time.ShowTime();
		std::cout << "======���� �ð� ���� ���α׷�(" << Day << "Day)======" << std::endl;
		std::cout << "\t1.�ð� ���" << std::endl;
		std::cout << "\t2.����" << std::endl;
		std::cout << "\t�Է� : ";
		std::cin >> select;
		switch (select)
		{
		case 1:
		{
			std::cout << "�ð� : ";
			std::cin >> iHour;
			std::cout << "�� : ";
			std::cin >> iMin;
			Time time2(iHour, iMin);
			time += time2;
			Day++;
			break;
		}
		case 2:
			return;
		default:
			break;

		}
	}
}