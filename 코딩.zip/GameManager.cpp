#include "GameManager.h"

GameManager::GameManager()
{
	Start_x = 0;
	Start_y = 0;
	m_iWidth = 30;
	m_iHeight = 34;
}

void GameManager::MainMenu()
{
	mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
	mapdraw.DrawMidText("�١� DonGeonRPG �ڡ�", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("New Game", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Load Game", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Game Exit", m_iWidth, m_iHeight * 0.7f);

}
void GameManager::GameMenu()
{
	system("cls");
	mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
	mapdraw.DrawMidText("�١� Menu �ڡ�", m_iWidth, m_iHeight * 0.2f);
	mapdraw.DrawMidText("Dongeon", m_iWidth, m_iHeight * 0.3f);
	mapdraw.DrawMidText("Player Info", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("Monster Info", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Weapon Shop", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Save", m_iWidth, m_iHeight * 0.7f);
	mapdraw.DrawMidText("Exit", m_iWidth, m_iHeight * 0.8f);

}
void GameManager::Dongeon()
{

}
void GameManager::Player_Info()
{
	player.Infomation();
}
void GameManager::Monster_Info()
{

}
void GameManager::Weapon_Shop()
{

}
void GameManager::Save()
{

}

void GameManager::Playing()
{
	monster.Monster();
	GameMenu();
	switch (mapdraw.MenuSelectCursor(6, 3, m_iWidth * 0.35f, m_iHeight * 0.3f))
	{
	case 1:
		Dongeon();
		break;
	case 2:
		Player_Info();
		break;
	case 3:
		Monster_Info();
		break;
	case 4:
		Weapon_Shop();
		break;
	case 5:
		Save();
		break;
	case 6:
		return;
	}

}

void GameManager::Start()
{
	string name;
	MainMenu();
	//int playing = mapdraw.MenuSelectCursor(3, 3, m_iWidth * 0.35f, m_iHeight * 0.5f);
	switch (mapdraw.MenuSelectCursor(3, 3, m_iWidth * 0.35f, m_iHeight * 0.5f))
	{
	case 1:
		system("cls");
		mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
		mapdraw.DrawMidText("Player �̸� �Է� : ", m_iWidth, m_iHeight * 0.5f);
		cin >> name;
		player.NewPlayer(name);
		Playing();
		break;
	case 2:
		player.LoadPlayer();
		Playing();
		break;
	case 3:
		break;
	default:
		break;
	}

}
GameManager::~GameManager() {}