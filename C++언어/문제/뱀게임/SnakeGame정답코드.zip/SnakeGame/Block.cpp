#include "Block.h"


Block::Block()
{

}
Block::~Block()
{

}


void Block::Init(int _ix, int _iy, BLOCK_TYPE _eType) // �׸��� ���� ����
{
	m_ix = _ix;
	m_iy = _iy;
	m_eType = _eType;
	switch (m_eType)
	{
	case BLOCK_TYPE::COLLIDER:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::FOOD:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::TAIL:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::HEAD:
		m_strShape = "��";
		break;
	}
}

void Block::CopyPosition(Block b)
{
	m_ix = b.m_ix;
	m_iy = b.m_iy;
}

void Block::SetType(BLOCK_TYPE _eType)
{
	m_eType = _eType;
	switch (m_eType)
	{
	case BLOCK_TYPE::COLLIDER:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::FOOD:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::TAIL:
		m_strShape = "��";
		break;
	case BLOCK_TYPE::HEAD:
		m_strShape = "��";
		break;
	}
}


void Block::AddPosition(int _iAdd_x, int _iAdd_y)
{
	m_ix += _iAdd_x;
	m_iy += _iAdd_y;
}
bool Block::Compare(int _ix, int _iy)
{
	return m_ix == _ix && m_iy == _iy;
}

bool Block::Compare(Block b)
{
	return m_ix == b.m_ix && m_iy == b.m_iy;
}


void Block::Erase()
{
	DrawManager::DrawPoint("  ", m_ix, m_iy);
}

void Block::Draw()
{
	DrawManager::DrawPoint(m_strShape, m_ix, m_iy);
}