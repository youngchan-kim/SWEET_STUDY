#include "Timer.h"

Timer::Timer()
{
}
Timer::~Timer()
{
}
void Timer::SetTimer(TIMER_TYPE Type, int iSecond, std::function<void()> _callbackFunc, int iMaxCount)
{
	Timer_Type = Type;
	m_iSecond = iSecond;
	m_bLive = true;
	m_iOldTime = clock();
	m_iMaxCount = iMaxCount;
	if (Timer_Type == TIMER_TYPE_COUNT)
		m_iCurCount = 0;
	else
		m_iCurCount = -1;
	m_callbackFunc = _callbackFunc;
}

bool Timer::CheckTimer()
{
	if (m_bLive == true && clock() - m_iOldTime >= m_iSecond)
	{
		m_callbackFunc();
		switch (Timer_Type)
		{
		case TIMER_TYPE_ONCE:
			m_bLive = false;
			return true;
			break;
		case TIMER_TYPE_LOOP:
			m_iOldTime = clock();
			return true;
			break;
		case TIMER_TYPE_COUNT:
			m_iCurCount++;
			if (m_iCurCount == m_iMaxCount)
				m_bLive = false;
			else
				m_iOldTime = clock();
			return true;
			break;
		default:
			break;
		}
	}
	else
		return false;
}