#include "Circle.h"

void Circle::Init(float x, float y, float radius)
{
	this->radius = radius;

	position.x = x + radius;
	position.y = y + radius;
}

void Circle::Update(const FLOAT& deltaTime)
{
	gravity = g * deltaTime;
	position.y += gravity;
}

void Circle::Draw(HDC hdc)
{
	Ellipse(hdc,position.x - radius, position.y - radius, position.x + radius, position.y + radius);
}


