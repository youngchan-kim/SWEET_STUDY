#include "Interface.h"

Interface::Interface(){}

void Interface::ErasePoint(int x, int y)
{
	gotoxy(x * 2, y);
	std::cout << "  ";
	gotoxy(-1, -1);
	return;
}


void Interface::EraseText(std::string str, int x, int y)
{
	std::string erasetext;
	for (int i = 0; i < str.length(); i++)
	{
		erasetext += "  ";
	}
	gotoxy(x, y);
	std::cout << erasetext;
	gotoxy(-1, -1);
	return;
}


void Interface::BoxErase(int Width, int Height)
{
	for (int y = 1; y < Height - 1; y++)
	{
		gotoxy(2, y);
		for (int x = 1; x < Width - 1; x++)
			std::cout << "  ";
	}
}

void Interface::DrawPoint(std::string str, int x, int y)
{
	gotoxy(x * 2, y);
	std::cout << str;
	gotoxy(-1, -1);
	return;
}

void Interface::DrawMidText(std::string str, int x, int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	std::cout << str;
	return;
}


void Interface::TextDraw(std::string str, int x, int y)
{
	gotoxy(x, y);
	std::cout << str;
}


void Interface::blindText(std::string str, int x, int y)
{
	std::string erasetext;
	for (int i = 0; i < str.length(); i++)
	{
		erasetext += "#";
	}
	gotoxy(x, y);
	std::cout << erasetext;
	gotoxy(-1, -1);
	return;
}


void Interface::BoxDraw(int Start_x, int Start_y, int Width, int Height)
{
	if (Start_x > Width)
		Start_x -= Width;
	for (int y = 0; y < Height; y++)
	{
		gotoxy(Start_x, Start_y + y);
		if (y == 0)
		{
			std::cout << "��";
			for (int x = 1; x < Width - 1; x++)
				std::cout << "��";
			std::cout << "��";
		}
		else if (y == Height - 1)
		{
			std::cout << "��";
			for (int x = 1; x < Width - 1; x++)
				std::cout << "��";
			std::cout << "��";
		}
		else
		{
			std::cout << "��";
			for (int x = 1; x < Width - 1; x++)
				std::cout << "  ";
			std::cout << "��";
		}
	}
	return;
}

int Interface::MenuSelectCursor(int MenuLen, int AddCol, int x, int y)
{
	int Select = 1;
	RED
		DrawPoint("��", x, y);
	ORIGINAL
		while (1)
		{
			switch (getch())
			{
			case UP:
				if (Select - 1 >= 1)
				{
					ErasePoint(x, y);
					y -= AddCol;
					Select--;
				}
				break;
			case DOWN:
				if (Select + 1 <= MenuLen)
				{
					ErasePoint(x, y);
					y += AddCol;
					Select++;
				}
				break;
			case ENTER:
				return Select;
			}
			RED
				DrawPoint("��", x, y);
			ORIGINAL
		}
}
Interface::~Interface()
{
}
