#include "Player.h"
Player::Player() : weapon(NULL) {}

void Player::Load(ifstream& load, string name)
{
	if (NULL != weapon)
	{
		delete weapon;
		weapon = NULL;
	}

	bool isLoad;
	isLoad = ("" == name);
	if (isLoad) load >> m_strname;
	else if (!isLoad) m_strname = name;
	load >> m_idamage;
	load >> m_imaxhealth;
	load >> m_imaxexp;
	load >> m_igetexp;
	load >> m_iLv;
	load >> m_igold;
	if (isLoad)
	{
		load >> m_iexp;
		load >> m_icurhealth;
		bool weaponcheck;
		load >> weaponcheck;
		if (weaponcheck)
		{
			weapon->Load(load);
		}
	}
	else
	{
		m_icurhealth = m_imaxhealth;
	}
}
void Player::Save(ofstream& save)
{
	save << m_strname << " ";
	save << m_idamage << " ";
	save << m_imaxhealth << " ";
	save << m_imaxexp << " ";
	save << m_igetexp << " ";
	save << m_iLv << " ";
	save << m_igold << " ";
	save << m_iexp << " ";
	save << m_icurhealth << endl;
	bool weaponcheck = (NULL != weapon);
	save << weaponcheck;
	if (weaponcheck)
	{
		weapon->Save(save);
	}
	//���� �ƴҶ�
	// ���� �������� ���
}

void Player::Infomation(int x, int y)
{
	string line1, line2, line3, line4;
	line1 = "======" + m_strname + "(" + to_string(m_iLv) + "Lv)======";
	line2 = "���ݷ� = " + to_string(m_idamage) + "\t" + "������ = " + to_string(m_icurhealth) + "/" + to_string(m_imaxhealth);
	line3 = "����ġ = " + to_string(m_iexp) + "/" + to_string(m_imaxexp) + "\t" + "GetEXP : " + to_string(m_igetexp);
	line4 = "Gold = " + to_string(m_igold);
	mapdraw.DrawMidText(line1, x, y);
	mapdraw.TextDraw(line2, x * 0.5f, y + 1);
	mapdraw.TextDraw(line3, x * 0.5f, y + 2);
	mapdraw.TextDraw(line4, x * 0.5f, y + 3);
}


void Player::Levelup()
{
	int Num;
	if (m_iexp >= m_imaxexp)
	{
		Num = (rand() % UPATTACKSTAT) + 1;
		m_idamage += Num;
		Num = (rand() % UPATTACKSTAT) + 1;
		m_imaxhealth += Num;
		m_imaxexp += m_imaxexp * 0.3;
		m_icurhealth = m_imaxhealth;
		m_iexp = 0;
		m_iLv++;
	}
}
void Player::GetWinner(int exp, int gold)
{
	m_iexp += exp;
	m_igold += gold;
	Levelup();
}

void Player::WeaponBuy(Weapon* weaponwear) 
{ 
	m_igold -= weaponwear->Price();
	if (weapon != NULL)
		weapon = NULL;
	weapon = weaponwear;
};


Player::~Player() {
	if (NULL != weapon)
	{
		delete weapon;
		weapon = NULL;
	}
}