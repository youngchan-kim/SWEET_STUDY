#pragma once
#include <Windows.h>

class BitMap
{
private:
	HDC MemDC;

	HANDLE m_BitMap;
	SIZE m_Size;

public:

	void Init(HDC hdc, char* FileName);
	void Draw(HDC hdc, int x, int y, int Sx, int Sy);
	BitMap() {}
	HANDLE BITMAPIMAGE(){return m_BitMap;}
	~BitMap();
};

