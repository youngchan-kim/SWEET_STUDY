#pragma once
#include"Mecro.h"
#include"MapDraw.h"
class Character
{
private:
	int m_imapcharacterx;
	int m_imapcharactery;
	string m_strcharacter;
	MapDraw m_MapDraw;
public:
	void Create(int mapx, int mapy, int Width, int Height);
	void Print();
	void Move(int mapx, int mapy, int Width, int Height);
	Character();
	~Character();
};

