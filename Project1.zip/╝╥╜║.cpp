#include "Mecro.h"
#include "GameManager.h"

void main()
{
	GameManager g;
	g.Playing();
}