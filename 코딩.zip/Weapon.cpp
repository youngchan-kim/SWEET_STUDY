#include "Weapon.h"

Weapon::Weapon() {}

void Weapon::Load(ifstream& load)
{
	load >> m_strname;
	load >> m_idamage;
	load >> m_iprice;
}

void Weapon::WeaponInfo(int x, int y)
{
	string line1 = "���� : " + to_string(m_iprice) + " ���� Ÿ�� : " + m_strweapon;
	string line2 = "�����̸� : " + m_strname + " ���ݷ� : " + to_string(m_idamage);
	mapdraw.DrawMidText(line1, x, y);
	mapdraw.DrawMidText(line2, x, y+1);
}
//float Weapon::Atteck()
//{
//	int x, y;
//	string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
//	mapdraw.DrawMidText(line1, x, y);
//	return m_idamage;
//}
Weapon::~Weapon() {}


Bow::Bow() {}
float Bow::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 11)
	{
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 10) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage * 10;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}

Bow::~Bow() {}


Dagger::Dagger() {}
float Dagger::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 21)
	{
		string line1 = "ũ��Ƽ�ü�!!(Damage : " + to_string(m_idamage * 5) + ")";
		mapdraw.DrawMidText(line1, x, y);
		mapdraw.DrawMidText(line1, x, y + 1);
		return m_idamage * 10;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}
Dagger::~Dagger() {}


Gun::Gun() {}
float Gun::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 51)
	{
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 2) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage * 2;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}
Gun::~Gun() {}


Sword::Sword() {}
float Sword::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 31)
	{
		string line1 = "�˱�!!(Damage : " + to_string(m_idamage * 1.5) + ")";
		mapdraw.DrawMidText(line1, x, y);
		mapdraw.DrawMidText(line1, x, y + 1);
		mapdraw.DrawMidText(line1, x, y + 2);
		return m_idamage * 1.5 * 3;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}
Sword::~Sword() {}


Wand::Wand() {}
float Wand::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance < 6)
	{
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 1000) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage * 1000;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}
Wand::~Wand() {}


Hammer::Hammer() {}
float Hammer::Atteck()
{
	int x, y;
	srand((unsigned)time(NULL));
	int Chance = ((rand() % 100) + 1);
	if (Chance > 51)
	{
		string line1 = "��弦!!(Damage : " + to_string(m_idamage * 1.2) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage * 1.2;
	}
	else
	{
		string line1 = "����!!(Damage : " + to_string(m_idamage) + ")";
		mapdraw.DrawMidText(line1, x, y);
		return m_idamage;
	}
}
Hammer::~Hammer() {}
