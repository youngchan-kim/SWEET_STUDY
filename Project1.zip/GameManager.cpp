#include "GameManager.h"

GameManager::GameManager() 
{
	Start_x = 0;
	Start_y = 0;
	m_iWidth = 30;
	m_iHeight = 34;
}

void GameManager::MainMenu()
{
	mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
	mapdraw.DrawMidText("�١� DonGeonRPG �ڡ�", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("New Game", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Load Game", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Game Exit", m_iWidth, m_iHeight * 0.7f);

}
void GameManager::GameMenu()
{
	system("cls");
	mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
	mapdraw.DrawMidText("�١� Menu �ڡ�", m_iWidth, m_iHeight * 0.4f);
	mapdraw.DrawMidText("Dongeon", m_iWidth, m_iHeight * 0.45f);
	mapdraw.DrawMidText("Player Info", m_iWidth, m_iHeight * 0.5f);
	mapdraw.DrawMidText("Monster Info", m_iWidth, m_iHeight * 0.55f);
	mapdraw.DrawMidText("Weapon Shop", m_iWidth, m_iHeight * 0.6f);
	mapdraw.DrawMidText("Save", m_iWidth, m_iHeight * 0.65f);
	mapdraw.DrawMidText("Exit", m_iWidth, m_iHeight * 0.7f);

}

void GameManager::Playing()
{
	string name;
	MainMenu();
	//int playing = mapdraw.MenuSelectCursor(3, 3, m_iWidth * 0.35f, m_iHeight * 0.5f);
	switch (mapdraw.MenuSelectCursor(3, 3, m_iWidth * 0.35f, m_iHeight * 0.5f))
	{
	case 1:
		system("cls");
		mapdraw.BoxDraw(Start_x, Start_y, m_iWidth, m_iHeight);
		mapdraw.DrawMidText("Player �̸� �Է� : ", m_iWidth, m_iHeight * 0.5f);
		cin >> name;
		player.NewPlayer(name);
		GameMenu();
		break;
	case 2:
		GameMenu();
		break;
	case 3:
		break;
	default:
		break;
	}

}
GameManager::~GameManager() {}